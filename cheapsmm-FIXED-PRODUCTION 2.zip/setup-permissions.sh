#!/bin/bash

##############################################################
# CheapSMM Panel - Permissions Setup Script
# Run this ONLY if you have SSH access to cPanel
##############################################################

echo "================================================"
echo "  CheapSMM Panel - Permissions Setup"
echo "================================================"
echo ""

# Get the application directory
APP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "Application directory: $APP_DIR"
echo ""

# Set ownership (if needed - usually not on shared hosting)
# chown -R username:username $APP_DIR

# Set directory permissions
echo "Setting directory permissions..."
find $APP_DIR -type d -exec chmod 755 {} \;

# Set file permissions
echo "Setting file permissions..."
find $APP_DIR -type f -exec chmod 644 {} \;

# Set writable directories
echo "Setting writable directories..."
chmod -R 775 $APP_DIR/storage
chmod -R 775 $APP_DIR/bootstrap/cache

# Make artisan executable
echo "Making artisan executable..."
chmod +x $APP_DIR/artisan

# Verify critical directories
echo ""
echo "Verifying permissions..."
echo "------------------------"

check_permission() {
    local dir=$1
    local perm=$(stat -c "%a" "$dir" 2>/dev/null || stat -f "%OLp" "$dir" 2>/dev/null)
    echo "$dir: $perm"
}

check_permission "$APP_DIR/storage"
check_permission "$APP_DIR/storage/framework"
check_permission "$APP_DIR/storage/logs"
check_permission "$APP_DIR/bootstrap/cache"

echo ""
echo "================================================"
echo "  ✅ Permissions setup complete!"
echo "================================================"
echo ""
echo "Next steps:"
echo "1. Verify .env configuration"
echo "2. Run: php artisan config:cache"
echo "3. Run: php artisan route:cache"
echo "4. Run: php artisan view:cache"
echo ""
