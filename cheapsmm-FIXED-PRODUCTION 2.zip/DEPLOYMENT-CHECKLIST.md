# ✅ CPANEL DEPLOYMENT CHECKLIST

Print this page and check off each step as you complete it.

---

## PRE-DEPLOYMENT (Local Computer)

- [ ] PHP 8.2+ installed on local machine
- [ ] Composer installed
- [ ] Project extracted from ZIP
- [ ] Run: `composer install --no-dev --optimize-autoloader`
- [ ] Verify `vendor/` folder created (~50-70MB)
- [ ] Create deployment ZIP with vendor included

---

## CPANEL UPLOAD

- [ ] Login to cPanel
- [ ] Navigate to File Manager
- [ ] Upload ZIP to `/home/username/` (NOT public_html)
- [ ] Extract to `/home/username/cheapsmm/`
- [ ] Verify extraction successful
- [ ] Delete ZIP file after extraction

---

## PUBLIC FILES SETUP

- [ ] Navigate to `/home/username/cheapsmm/public/`
- [ ] Copy ALL files to `/home/username/public_html/`
- [ ] Delete `index.php` in public_html
- [ ] Copy `index-cpanel.php` to public_html
- [ ] Rename to `index.php`
- [ ] Verify `.htaccess` present in public_html

---

## FILE PERMISSIONS

Set these permissions (Right-click → Change Permissions):

- [ ] `/home/username/cheapsmm/storage/` → 755
- [ ] `/home/username/cheapsmm/storage/framework/` → 755
- [ ] `/home/username/cheapsmm/storage/logs/` → 755
- [ ] `/home/username/cheapsmm/bootstrap/cache/` → 755

If 755 doesn't work, try 775 for each.

---

## DATABASE SETUP

- [ ] Go to: cPanel → MySQL Databases
- [ ] Create database: `username_cheapsmm`
- [ ] Create user: `username_cheapsmm_user`
- [ ] Set strong password (save it!)
- [ ] Add user to database with ALL PRIVILEGES
- [ ] Go to phpMyAdmin
- [ ] Select your database
- [ ] Import: `COMPLETE-DATABASE-SCHEMA.sql`
- [ ] Verify import successful (check table count)

---

## ENVIRONMENT CONFIGURATION

- [ ] Navigate to `/home/username/cheapsmm/`
- [ ] Copy `.env.example` to `.env`
- [ ] Edit `.env` file
- [ ] Set `APP_NAME=CheapSMM`
- [ ] Set `APP_ENV=production`
- [ ] Set `APP_DEBUG=false`
- [ ] Set `APP_URL=https://yourdomain.com`
- [ ] Set database credentials:
  - [ ] `DB_DATABASE=username_cheapsmm`
  - [ ] `DB_USERNAME=username_cheapsmm_user`
  - [ ] `DB_PASSWORD=your_password`
- [ ] Generate and set `APP_KEY=base64:xxxxx`
- [ ] Configure mail settings (optional)
- [ ] Save `.env` file

---

## CRON JOB SETUP

- [ ] Go to: cPanel → Cron Jobs
- [ ] Set: Common Setting → Every 5 minutes
- [ ] Command: `cd /home/username/cheapsmm && php artisan schedule:run >> /dev/null 2>&1`
- [ ] Click "Add New Cron Job"
- [ ] Verify cron job appears in list

---

## SSL CERTIFICATE

- [ ] Go to: cPanel → SSL/TLS Status
- [ ] Enable AutoSSL for your domain
- [ ] Verify SSL certificate issued
- [ ] Test: https://yourdomain.com (should show padlock)

---

## TESTING

- [ ] Visit: https://yourdomain.com
- [ ] Verify site loads (no 500 error)
- [ ] Check: No database connection errors
- [ ] Check: CSS/JS loads correctly
- [ ] Try to access login page
- [ ] Check: No "Class not found" errors
- [ ] Review: `/storage/logs/laravel.log` for errors

---

## POST-DEPLOYMENT

- [ ] Test user registration
- [ ] Test user login
- [ ] Test admin login (if default exists)
- [ ] Test order creation
- [ ] Verify email sending works
- [ ] Test payment gateway (sandbox mode)
- [ ] Configure payment gateway live credentials
- [ ] Update terms/privacy pages
- [ ] Update logo/branding

---

## SECURITY VERIFICATION

- [ ] `APP_DEBUG=false` in .env
- [ ] `.env` file NOT accessible via browser
- [ ] `vendor/` folder NOT accessible via browser
- [ ] Strong database password set
- [ ] Admin password changed from default
- [ ] SSL certificate active
- [ ] File permissions correct (not 777)

---

## BACKUP PLAN

- [ ] Download fresh copy of working .env
- [ ] Export database backup
- [ ] Download entire `/cheapsmm/` folder backup
- [ ] Store backups in safe location
- [ ] Document database credentials
- [ ] Document admin credentials

---

## OPTIONAL OPTIMIZATIONS (If SSH available)

- [ ] Run: `php artisan config:cache`
- [ ] Run: `php artisan route:cache`
- [ ] Run: `php artisan view:cache`
- [ ] Run: `php artisan storage:link`

---

## 🎉 DEPLOYMENT COMPLETE!

Date Deployed: _________________

Domain: _______________________

Admin Email: __________________

Database Name: ________________

---

## 📞 EMERGENCY CONTACTS

Hosting Provider: __________________

Support Email: ____________________

Support Phone: ____________________

---

**Keep this checklist for future reference and updates!**
