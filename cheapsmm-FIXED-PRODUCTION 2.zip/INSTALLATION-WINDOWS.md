# 🪟 WINDOWS 10 INSTALLATION GUIDE

## Prerequisites Installed:
- ✅ XAMPP (PHP 8.2, MySQL, Apache)
- ✅ Composer

## Installation Steps:

### 1. Extract Files
Extract this folder to: `C:\xampp\htdocs\cheapsmm`

### 2. Install Dependencies
Open Command Prompt as Administrator:
```cmd
cd C:\xampp\htdocs\cheapsmm
composer install
```

### 3. Create Environment File
```cmd
copy .env.example .env
```

### 4. Generate Application Key
```cmd
php artisan key:generate
```

### 5. Set Permissions
```cmd
icacls storage /grant Everyone:(OI)(CI)F /T
icacls bootstrap\cache /grant Everyone:(OI)(CI)F /T
```

### 6. Create Database
- Open http://localhost/phpmyadmin
- Create database: `cheapsmm`
- Collation: `utf8mb4_general_ci`

### 7. Run Web Installer
Open browser: http://localhost/cheapsmm/public/install

Follow the 6-step wizard!

### Database Credentials:
- Host: localhost
- Port: 3306
- Database: cheapsmm
- Username: root
- Password: (leave blank)

### Admin Credentials (default):
- Email: admin@cheapsmm.fun
- Password: admin123

## Troubleshooting:

### "composer: command not found"
- Restart Command Prompt
- Make sure Composer is in PATH

### "vendor folder not found"
- Run: `composer install`

### "Permission denied"
- Run Command Prompt as Administrator
- Re-run permission commands

### "Database connection failed"
- Make sure MySQL is running in XAMPP
- Check .env database credentials

## Support Files:
- Complete guide: INSTALLATION-GUIDE.md
- Cron setup: CRON_SETUP_GUIDE.md
- Build summary: FINAL-COMPLETE-BUILD-SUMMARY.md
