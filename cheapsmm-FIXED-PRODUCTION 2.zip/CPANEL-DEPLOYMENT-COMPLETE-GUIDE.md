# 🚀 CPANEL DEPLOYMENT GUIDE - CheapSMM Panel

## 📁 CORRECT FOLDER STRUCTURE FOR CPANEL

```
/home/username/               ← Your cPanel home directory
│
├── public_html/              ← Web-accessible directory (DOMAIN ROOT)
│   ├── index.php            ← Laravel entry point (modified)
│   ├── .htaccess            ← Apache rules
│   ├── css/
│   ├── js/
│   ├── images/
│   ├── manifest.json
│   └── sw.js
│
├── cheapsmm/                 ← Laravel application (SECURE - NOT WEB ACCESSIBLE)
│   ├── app/
│   ├── bootstrap/
│   ├── config/
│   ├── database/
│   ├── resources/
│   ├── routes/
│   ├── storage/             ← Must be WRITABLE (755 or 775)
│   ├── vendor/              ← Composer dependencies
│   ├── .env                 ← Environment configuration
│   ├── artisan
│   └── composer.json
│
└── logs/                     ← Optional: custom log directory
```

---

## 🔧 STEP-BY-STEP DEPLOYMENT

### STEP 1: PREPARE PROJECT LOCALLY

**On your local computer with PHP 8.2+:**

```bash
# 1. Navigate to project folder
cd cheapsmm-panel-PRODUCTION-READY

# 2. Install dependencies
composer install --optimize-autoloader --no-dev

# 3. This creates vendor/ folder (~50-70MB)
# Verify vendor exists:
ls -la vendor/
```

---

### STEP 2: CREATE DEPLOYMENT ZIP

**Create two separate uploads:**

#### Option A: Single ZIP (Recommended for small hosting)
```bash
# Zip entire project with vendor
zip -r cheapsmm-deploy.zip . -x "*.git*" -x "node_modules/*" -x "tests/*"
```

#### Option B: Split Upload (For upload size limits)
```bash
# Zip application WITHOUT vendor
zip -r cheapsmm-app.zip . -x "vendor/*" -x "*.git*" -x "node_modules/*" -x "tests/*"

# Zip vendor separately
cd vendor && zip -r ../cheapsmm-vendor.zip . && cd ..
```

---

### STEP 3: UPLOAD TO CPANEL

**Using cPanel File Manager:**

1. **Login to cPanel**
   - URL: https://yourdomain.com:2083 (or your hosting cPanel URL)

2. **Navigate to File Manager**
   - Go to: Files → File Manager

3. **Upload Application Files**
   - Navigate to `/home/username/` (home directory, NOT public_html)
   - Click "Upload"
   - Upload `cheapsmm-deploy.zip` (or `cheapsmm-app.zip`)
   - Wait for upload to complete

4. **Extract Application**
   - Right-click `cheapsmm-deploy.zip`
   - Select "Extract"
   - Extract to: `/home/username/cheapsmm/`
   - Delete ZIP after extraction

5. **Upload Vendor (if using split method)**
   - Upload `cheapsmm-vendor.zip` to `/home/username/cheapsmm/`
   - Extract inside `/home/username/cheapsmm/vendor/`

---

### STEP 4: SETUP PUBLIC FILES

**Move public folder contents to public_html:**

1. **Navigate to** `/home/username/cheapsmm/public/`

2. **Select ALL files** in public/ folder:
   - index.php
   - .htaccess
   - css/
   - js/
   - images/
   - manifest.json
   - sw.js

3. **Copy** (or Move) to `/home/username/public_html/`

4. **CRITICAL: Replace index.php**
   - Delete the index.php you just copied
   - Copy `/home/username/cheapsmm/public/index-cpanel.php`
   - Rename it to `index.php` in public_html
   - OR manually edit index.php paths (see STEP 5)

---

### STEP 5: MODIFY INDEX.PHP PATHS

**Edit `/home/username/public_html/index.php`:**

Change these lines:

**FROM:**
```php
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
```

**TO:**
```php
require __DIR__.'/../cheapsmm/vendor/autoload.php';
$app = require_once __DIR__.'/../cheapsmm/bootstrap/app.php';
if (file_exists($maintenance = __DIR__.'/../cheapsmm/storage/framework/maintenance.php')) {
```

---

### STEP 6: SET FILE PERMISSIONS

**Using cPanel File Manager:**

Set the following permissions (Right-click → Change Permissions):

```
/home/username/cheapsmm/storage/               → 755 or 775
/home/username/cheapsmm/storage/framework/     → 755 or 775
/home/username/cheapsmm/storage/logs/          → 755 or 775
/home/username/cheapsmm/bootstrap/cache/       → 755 or 775
```

**Permission Numbers:**
- 755 = Owner: Read/Write/Execute, Group & Others: Read/Execute
- 775 = Owner & Group: Read/Write/Execute, Others: Read/Execute

**If 755 doesn't work, try 775. Some hosts require 775.**

---

### STEP 7: CREATE DATABASE

**In cPanel:**

1. **Go to:** MySQL Databases

2. **Create New Database:**
   - Name: `username_cheapsmm` (cPanel adds prefix automatically)
   - Click "Create Database"

3. **Create Database User:**
   - Username: `username_cheapsmm_user`
   - Password: Generate strong password (save it!)
   - Click "Create User"

4. **Add User to Database:**
   - Select user and database
   - Grant ALL PRIVILEGES
   - Click "Add"

5. **Import Database:**
   - Go to phpMyAdmin
   - Select your database
   - Click "Import"
   - Upload: `/home/username/cheapsmm/database/COMPLETE-DATABASE-SCHEMA.sql`
   - Click "Go"

---

### STEP 8: CONFIGURE ENVIRONMENT (.env)

**Edit `/home/username/cheapsmm/.env`:**

If .env doesn't exist, copy from .env.example:
```bash
# In cPanel File Manager, navigate to /home/username/cheapsmm/
# Right-click .env.example → Copy → Rename to .env
```

**Edit .env file:**

```env
APP_NAME=CheapSMM
APP_ENV=production
APP_KEY=base64:YOUR_KEY_HERE
APP_DEBUG=false
APP_URL=https://yourdomain.com

LOG_CHANNEL=stack

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=username_cheapsmm
DB_USERNAME=username_cheapsmm_user
DB_PASSWORD=your_database_password

QUEUE_CONNECTION=database
SESSION_DRIVER=database
CACHE_DRIVER=file

# Mail Configuration (use your cPanel email settings)
MAIL_MAILER=smtp
MAIL_HOST=mail.yourdomain.com
MAIL_PORT=587
MAIL_USERNAME=noreply@yourdomain.com
MAIL_PASSWORD=your_email_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@yourdomain.com
MAIL_FROM_NAME="${APP_NAME}"

# Payment Gateways (add your keys)
STRIPE_KEY=pk_live_xxxxxxxxxxxxx
STRIPE_SECRET=sk_live_xxxxxxxxxxxxx

# Currency
BASE_CURRENCY=USD
DEFAULT_CURRENCY=USD
```

---

### STEP 9: GENERATE APP_KEY

**Option A: Via SSH (if available):**
```bash
cd /home/username/cheapsmm
php artisan key:generate
```

**Option B: Manual Generation (No SSH):**

1. Go to: https://generate-random.org/laravel-key-generator
2. Copy the generated key (format: base64:xxxxxxxxxxxxx)
3. Paste into .env file at APP_KEY=

**Option C: Use Online Tool:**
```
Visit: https://www.tools4noobs.com/online_tools/string_to_base64/
Input: Random 32 characters string
Output: Copy base64 result and add "base64:" prefix
```

---

### STEP 10: VERIFY DEPLOYMENT

**Test your installation:**

1. **Visit:** https://yourdomain.com

2. **Expected:** Laravel welcome page or login page

3. **If you see errors:**
   - Check: `/home/username/cheapsmm/storage/logs/laravel.log`
   - Common issues:
     - Wrong paths in index.php
     - Database connection failed
     - Missing APP_KEY
     - Permission errors

---

### STEP 11: SETUP CRON JOBS (IMPORTANT)

**For background tasks (order processing, etc.):**

1. **Go to:** cPanel → Cron Jobs

2. **Add New Cron Job:**
   - Minute: */5 (every 5 minutes)
   - Command:
     ```
     cd /home/username/cheapsmm && php artisan schedule:run >> /dev/null 2>&1
     ```

3. **Click "Add New Cron Job"**

This runs Laravel's task scheduler every 5 minutes.

---

### STEP 12: DOMAIN CONFIGURATION

**If using subdomain or addon domain:**

1. **In cPanel → Domains**

2. **For Subdomain:**
   - Create subdomain: `panel.yourdomain.com`
   - Document Root: `/home/username/public_html`
   - (The same root as main domain)

3. **For Addon Domain:**
   - Add domain: `panel-domain.com`
   - Document Root: `/home/username/public_html`

4. **SSL Certificate:**
   - Go to: SSL/TLS Status
   - Enable AutoSSL for your domain

---

## ✅ POST-DEPLOYMENT CHECKLIST

- [ ] Application accessible via URL
- [ ] Database connected (no errors)
- [ ] Can login to admin panel
- [ ] Storage directories writable
- [ ] Cron job configured
- [ ] SSL certificate installed
- [ ] Mail configuration tested
- [ ] Payment gateways configured

---

## 🔒 SECURITY CHECKLIST

- [ ] APP_DEBUG=false in .env
- [ ] Strong database password
- [ ] APP_KEY generated
- [ ] .env file NOT in public_html
- [ ] vendor/ folder NOT in public_html
- [ ] Storage logs protected (not web accessible)

---

## 🚨 TROUBLESHOOTING

### "500 Internal Server Error"
- Check storage/logs/laravel.log
- Verify file permissions (755 or 775)
- Check index.php paths

### "Database connection failed"
- Verify DB_HOST (usually 'localhost')
- Check database name has cPanel prefix
- Verify user has privileges

### "Blank page / No styles"
- Check APP_URL in .env matches your domain
- Verify .htaccess exists in public_html
- Check CSS/JS files copied to public_html

### "Class not found"
- Verify vendor/ folder uploaded
- Check composer autoload files exist
- Ensure vendor/autoload.php exists

---

## 📞 SUPPORT

If deployment fails:
1. Check `/home/username/cheapsmm/storage/logs/laravel.log`
2. Verify all steps completed
3. Contact your hosting provider for:
   - PHP version confirmation (8.2+)
   - Required extensions enabled
   - Permission issues

---

**DEPLOYMENT COMPLETE! 🎉**

Access your panel at: **https://yourdomain.com**
