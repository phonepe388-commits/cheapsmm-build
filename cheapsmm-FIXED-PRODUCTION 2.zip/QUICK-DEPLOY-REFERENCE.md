# ⚡ QUICK DEPLOYMENT REFERENCE

## 📂 FOLDER STRUCTURE
```
/home/username/
  ├── public_html/          ← Domain root (public files only)
  │   ├── index.php        ← Modified Laravel entry
  │   ├── css/
  │   ├── js/
  │   └── images/
  └── cheapsmm/            ← Laravel app (SECURE)
      ├── app/
      ├── vendor/          ← Must be uploaded!
      ├── storage/         ← 755 permissions
      ├── bootstrap/cache/ ← 755 permissions
      └── .env             ← Configure this!
```

## ⚡ QUICK STEPS

1. **Upload & Extract**
   - Upload ZIP to `/home/username/`
   - Extract to `/home/username/cheapsmm/`

2. **Move Public Files**
   - Copy `/cheapsmm/public/*` to `/public_html/`
   - Replace index.php with index-cpanel.php

3. **Set Permissions**
   - storage/ → 755
   - bootstrap/cache/ → 755

4. **Create Database**
   - cPanel → MySQL Databases
   - Import: `database/COMPLETE-DATABASE-SCHEMA.sql`

5. **Configure .env**
   - Copy .env.example to .env
   - Set DB credentials
   - Generate APP_KEY

6. **Setup Cron**
   - */5 * * * * cd /home/username/cheapsmm && php artisan schedule:run

7. **Test**
   - Visit: https://yourdomain.com

## 🔑 CRITICAL FILES

- `/public_html/index.php` - Entry point (MUST modify paths)
- `/cheapsmm/.env` - Configuration
- `/cheapsmm/vendor/` - Dependencies (MUST upload)

## 🚨 COMMON ERRORS

| Error | Fix |
|-------|-----|
| 500 Error | Check storage permissions (755) |
| DB Connection Failed | Verify .env DB_* settings |
| Class not found | Ensure vendor/ uploaded |
| Blank page | Check APP_URL in .env |

## 📱 SUPPORT CHECKLIST

Before asking for help, verify:
- [ ] PHP 8.2+ enabled
- [ ] vendor/ folder uploaded (~50MB)
- [ ] storage/ writable (755)
- [ ] .env configured
- [ ] Database imported
- [ ] APP_KEY generated
- [ ] Paths in index.php correct
