<?php

return [
    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'stripe' => [
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
    ],

    'paypal' => [
        'mode' => env('PAYPAL_MODE', 'sandbox'),
        'client_id' => env('PAYPAL_CLIENT_ID'),
        'secret' => env('PAYPAL_SECRET'),
    ],

    'razorpay' => [
        'key' => env('RAZORPAY_KEY'),
        'secret' => env('RAZORPAY_SECRET'),
    ],

    'coinbase' => [
        'api_key' => env('COINBASE_API_KEY'),
        'webhook_secret' => env('COINBASE_WEBHOOK_SECRET'),
    ],

    'skrill' => [
        'merchant_email' => env('SKRILL_MERCHANT_EMAIL'),
        'secret_word' => env('SKRILL_SECRET_WORD'),
    ],

    'perfectmoney' => [
        'account_id' => env('PERFECTMONEY_ACCOUNT_ID'),
        'passphrase' => env('PERFECTMONEY_PASSPHRASE'),
        'alternate_passphrase' => env('PERFECTMONEY_ALT_PASSPHRASE'),
    ],

    'payeer' => [
        'merchant_id' => env('PAYEER_MERCHANT_ID'),
        'secret_key' => env('PAYEER_SECRET_KEY'),
    ],

    'flutterwave' => [
        'public_key' => env('FLUTTERWAVE_PUBLIC_KEY'),
        'secret_key' => env('FLUTTERWAVE_SECRET_KEY'),
    ],
];
