<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Available Languages
    |--------------------------------------------------------------------------
    |
    | List of all supported languages in the application
    |
    */
    'supported' => [
        'en' => [
            'name' => 'English',
            'native' => 'English',
            'flag' => '🇬🇧',
            'direction' => 'ltr'
        ],
        'es' => [
            'name' => 'Spanish',
            'native' => 'Español',
            'flag' => '🇪🇸',
            'direction' => 'ltr'
        ],
        'fr' => [
            'name' => 'French',
            'native' => 'Français',
            'flag' => '🇫🇷',
            'direction' => 'ltr'
        ],
        'de' => [
            'name' => 'German',
            'native' => 'Deutsch',
            'flag' => '🇩🇪',
            'direction' => 'ltr'
        ],
        'pt' => [
            'name' => 'Portuguese',
            'native' => 'Português',
            'flag' => '🇵🇹',
            'direction' => 'ltr'
        ],
        'ar' => [
            'name' => 'Arabic',
            'native' => 'العربية',
            'flag' => '🇸🇦',
            'direction' => 'rtl'
        ],
        'hi' => [
            'name' => 'Hindi',
            'native' => 'हिन्दी',
            'flag' => '🇮🇳',
            'direction' => 'ltr'
        ],
        'zh' => [
            'name' => 'Chinese',
            'native' => '中文',
            'flag' => '🇨🇳',
            'direction' => 'ltr'
        ],
        'ja' => [
            'name' => 'Japanese',
            'native' => '日本語',
            'flag' => '🇯🇵',
            'direction' => 'ltr'
        ],
        'ru' => [
            'name' => 'Russian',
            'native' => 'Русский',
            'flag' => '🇷🇺',
            'direction' => 'ltr'
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Language
    |--------------------------------------------------------------------------
    */
    'default' => 'en',

    /*
    |--------------------------------------------------------------------------
    | Fallback Language
    |--------------------------------------------------------------------------
    */
    'fallback' => 'en',
];
