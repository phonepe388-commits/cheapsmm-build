@extends('layouts.app')
@section('title', 'Pricing')
@section('content')
<div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
    <div class="max-w-7xl mx-auto px-4 text-center">
        <h1 class="text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
        <p class="text-xl">Only pay for what you use. No monthly fees, no commitments.</p>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 py-16">
    <!-- Payment Bonuses -->
    <div class="mb-16">
        <h2 class="text-3xl font-bold text-center mb-8">Add Funds & Get Bonus!</h2>
        <div class="grid md:grid-cols-3 gap-6">
            <div class="border-2 border-green-500 rounded-lg p-6 text-center">
                <div class="text-4xl font-bold text-green-600 mb-2">5%</div>
                <div class="text-gray-600 mb-4">Bonus on $50 - $99</div>
                <div class="text-sm">Deposit $50, Get $52.50</div>
            </div>
            <div class="border-2 border-blue-500 rounded-lg p-6 text-center transform scale-105">
                <div class="text-4xl font-bold text-blue-600 mb-2">10%</div>
                <div class="text-gray-600 mb-4">Bonus on $100 - $499</div>
                <div class="text-sm">Deposit $100, Get $110</div>
            </div>
            <div class="border-2 border-purple-500 rounded-lg p-6 text-center">
                <div class="text-4xl font-bold text-purple-600 mb-2">15%</div>
                <div class="text-gray-600 mb-4">Bonus on $500+</div>
                <div class="text-sm">Deposit $500, Get $575</div>
            </div>
        </div>
    </div>

    <!-- Sample Services -->
    <div>
        <h2 class="text-3xl font-bold text-center mb-8">Sample Service Pricing</h2>
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="min-w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Service</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Price</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Min/Max</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Speed</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <tr>
                        <td class="px-6 py-4">Instagram Followers</td>
                        <td class="px-6 py-4 font-semibold">$2.50 / 1000</td>
                        <td class="px-6 py-4">100 - 50,000</td>
                        <td class="px-6 py-4"><span class="text-green-600">●</span> Fast</td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4">Instagram Likes</td>
                        <td class="px-6 py-4 font-semibold">$1.00 / 1000</td>
                        <td class="px-6 py-4">50 - 10,000</td>
                        <td class="px-6 py-4"><span class="text-green-600">●</span> Instant</td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4">YouTube Views</td>
                        <td class="px-6 py-4 font-semibold">$3.00 / 1000</td>
                        <td class="px-6 py-4">1,000 - 100,000</td>
                        <td class="px-6 py-4"><span class="text-blue-600">●</span> Medium</td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4">TikTok Followers</td>
                        <td class="px-6 py-4 font-semibold">$4.50 / 1000</td>
                        <td class="px-6 py-4">100 - 20,000</td>
                        <td class="px-6 py-4"><span class="text-green-600">●</span> Fast</td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4">Facebook Page Likes</td>
                        <td class="px-6 py-4 font-semibold">$5.00 / 1000</td>
                        <td class="px-6 py-4">100 - 10,000</td>
                        <td class="px-6 py-4"><span class="text-blue-600">●</span> Medium</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <p class="text-center text-gray-600 mt-6">
            *Prices are examples. Actual pricing may vary. <a href="{{ route('register') }}" class="text-blue-600">Login to see full pricing</a>
        </p>
    </div>

    <!-- Reseller Program -->
    <div class="mt-16 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-8">
        <h2 class="text-3xl font-bold text-center mb-4">Reseller Program</h2>
        <p class="text-center text-gray-600 mb-8">Create your own SMM panel and earn profits!</p>
        <div class="grid md:grid-cols-3 gap-6">
            <div class="bg-white rounded-lg p-6 text-center">
                <div class="text-3xl mb-2">🏷️</div>
                <h3 class="font-bold mb-2">Custom Pricing</h3>
                <p class="text-sm text-gray-600">Set your own markup and pricing</p>
            </div>
            <div class="bg-white rounded-lg p-6 text-center">
                <div class="text-3xl mb-2">🎨</div>
                <h3 class="font-bold mb-2">White Label</h3>
                <p class="text-sm text-gray-600">Your brand, your domain</p>
            </div>
            <div class="bg-white rounded-lg p-6 text-center">
                <div class="text-3xl mb-2">💰</div>
                <h3 class="font-bold mb-2">Unlimited Profit</h3>
                <p class="text-sm text-gray-600">No limits on your earnings</p>
            </div>
        </div>
    </div>

    <div class="text-center mt-12">
        <a href="{{ route('register') }}" class="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg inline-block hover:bg-blue-700">Get Started Free</a>
    </div>
</div>
@endsection
