@extends('layouts.app')
@section('title', 'Refund Policy')
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-8">Refund Policy</h1>
    
    <div class="prose max-w-none space-y-6">
        <p class="text-sm text-gray-600">Last Updated: {{ date('F d, Y') }}</p>
        
        <div class="bg-blue-50 border-l-4 border-blue-600 p-4 my-6">
            <p class="font-semibold">Important: Please read our refund policy carefully before making a purchase.</p>
        </div>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">1. General Policy</h2>
            <p>Due to the digital nature of our services, all sales are final and non-refundable once the service has been initiated. However, we understand that issues may arise, and we handle them on a case-by-case basis.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">2. Eligible for Refund</h2>
            <p>Refunds may be issued in the following situations:</p>
            <ul class="list-disc pl-6">
                <li><strong>Service Not Delivered:</strong> If your order has not started within the specified delivery time and you have not received any portion of the service</li>
                <li><strong>Wrong Service Delivered:</strong> If you received a different service than what you ordered</li>
                <li><strong>Duplicate Orders:</strong> If you accidentally placed duplicate orders</li>
                <li><strong>Technical Issues:</strong> If there was a technical error on our part that prevented service delivery</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">3. Not Eligible for Refund</h2>
            <p>Refunds will NOT be issued in the following cases:</p>
            <ul class="list-disc pl-6">
                <li>Change of mind after order placement</li>
                <li>Incorrect link or username provided by customer</li>
                <li>Account privacy settings preventing delivery</li>
                <li>Natural drop in followers/likes (refill is available where indicated)</li>
                <li>Orders that are in progress or partially delivered</li>
                <li>Added funds to account balance</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">4. Partial Refunds</h2>
            <p>For partially completed orders:</p>
            <ul class="list-disc pl-6">
                <li>You will only be charged for the portion delivered</li>
                <li>The undelivered portion will be automatically refunded to your account balance</li>
                <li>This credit can be used for future orders</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">5. Account Balance</h2>
            <p>Funds added to your account balance are non-refundable. They can only be used for services on our platform.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">6. Refill Guarantee</h2>
            <p>For services marked with "Refill", we will refill your order if the count drops within the guarantee period at no additional cost. This is not a refund but a service guarantee.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">7. How to Request a Refund</h2>
            <p>To request a refund:</p>
            <ol class="list-decimal pl-6">
                <li>Open a support ticket from your account dashboard</li>
                <li>Provide your order ID and reason for refund request</li>
                <li>Our team will review and respond within 24-48 hours</li>
                <li>If approved, refund will be credited to your account balance</li>
            </ol>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">8. Processing Time</h2>
            <p>Approved refunds are processed within 24-48 hours and credited to your account balance. Cash refunds to payment method are not available.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">9. Dispute Resolution</h2>
            <p>If you have a dispute, please contact our support team first. We are committed to finding a fair solution for all parties.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">Contact</h2>
            <p>For refund-related questions, contact support@cheapsmm.fun or open a ticket in your account dashboard.</p>
        </section>
    </div>
</div>
@endsection
