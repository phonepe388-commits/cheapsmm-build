@extends('layouts.app')
@section('title', 'Privacy Policy')
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-8">Privacy Policy</h1>
    
    <div class="prose max-w-none space-y-6">
        <p class="text-sm text-gray-600">Last Updated: {{ date('F d, Y') }}</p>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">1. Information We Collect</h2>
            <p>We collect information you provide directly to us, including:</p>
            <ul class="list-disc pl-6">
                <li>Name and email address</li>
                <li>Payment information (processed securely through payment providers)</li>
                <li>Order history and service usage</li>
                <li>Communication history with our support team</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">2. How We Use Your Information</h2>
            <p>We use collected information to:</p>
            <ul class="list-disc pl-6">
                <li>Provide and improve our services</li>
                <li>Process transactions and send order confirmations</li>
                <li>Communicate with you about your account</li>
                <li>Respond to your inquiries and support requests</li>
                <li>Send promotional emails (you can opt-out anytime)</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">3. Information Sharing</h2>
            <p>We do not sell, trade, or share your personal information with third parties except:</p>
            <ul class="list-disc pl-6">
                <li>With service providers who assist in operating our platform</li>
                <li>When required by law or to protect our rights</li>
                <li>With payment processors to complete transactions</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">4. Data Security</h2>
            <p>We implement appropriate security measures to protect your information including SSL encryption and secure payment processing.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">5. Cookies</h2>
            <p>We use cookies to enhance your experience, analyze site usage, and personalize content. You can disable cookies in your browser settings.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">6. Your Rights</h2>
            <p>You have the right to:</p>
            <ul class="list-disc pl-6">
                <li>Access your personal information</li>
                <li>Request correction of inaccurate data</li>
                <li>Request deletion of your account</li>
                <li>Opt-out of marketing communications</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">7. Children's Privacy</h2>
            <p>Our services are not intended for users under 18. We do not knowingly collect information from children.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">8. Changes to Policy</h2>
            <p>We may update this privacy policy from time to time. We will notify you of significant changes by email or through our website.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">Contact Us</h2>
            <p>For privacy-related questions, contact us at support@cheapsmm.fun</p>
        </section>
    </div>
</div>
@endsection
