<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }} - #1 SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
            <div class="text-2xl font-bold">{{ config('app.name') }}</div>
            <div class="space-x-4">
                <a href="{{ route('login') }}" class="hover:text-blue-200">Login</a>
                <a href="{{ route('register') }}" class="bg-white text-blue-600 px-6 py-2 rounded-full font-semibold hover:bg-blue-50">Get Started</a>
            </div>
        </nav>
        
        <div class="container mx-auto px-6 py-20 text-center">
            <h1 class="text-5xl font-bold mb-6">Boost Your Social Media Presence</h1>
            <p class="text-xl mb-8">Fast, Affordable, and Reliable SMM Services</p>
            <div class="flex justify-center gap-4">
                <a href="{{ route('register') }}" class="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-50">Start Now - It's Free!</a>
                <a href="{{ route('public.pricing') }}" class="border-2 border-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-white hover:text-blue-600">View Pricing</a>
            </div>
            
            <div class="mt-16 grid md:grid-cols-3 gap-8">
                <div class="bg-white/10 backdrop-blur rounded-lg p-6">
                    <div class="text-4xl font-bold">10k+</div>
                    <div>Active Users</div>
                </div>
                <div class="bg-white/10 backdrop-blur rounded-lg p-6">
                    <div class="text-4xl font-bold">500k+</div>
                    <div>Orders Completed</div>
                </div>
                <div class="bg-white/10 backdrop-blur rounded-lg p-6">
                    <div class="text-4xl font-bold">24/7</div>
                    <div>Customer Support</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Features -->
    <div class="container mx-auto px-6 py-20">
        <h2 class="text-4xl font-bold text-center mb-12">Why Choose Us?</h2>
        <div class="grid md:grid-cols-3 gap-8">
            <div class="text-center">
                <div class="text-5xl mb-4">⚡</div>
                <h3 class="text-xl font-bold mb-2">Instant Delivery</h3>
                <p class="text-gray-600">Most orders start within minutes of placement</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">💰</div>
                <h3 class="text-xl font-bold mb-2">Lowest Prices</h3>
                <p class="text-gray-600">Competitive pricing with volume discounts</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🔒</div>
                <h3 class="text-xl font-bold mb-2">100% Secure</h3>
                <p class="text-gray-600">SSL encryption and secure payment processing</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">📊</div>
                <h3 class="text-xl font-bold mb-2">Real-Time Tracking</h3>
                <p class="text-gray-600">Monitor your orders in real-time</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🎯</div>
                <h3 class="text-xl font-bold mb-2">High Quality</h3>
                <p class="text-gray-600">Real engagement from active users</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">💬</div>
                <h3 class="text-xl font-bold mb-2">24/7 Support</h3>
                <p class="text-gray-600">Always here to help you succeed</p>
            </div>
        </div>
    </div>

    <!-- Services -->
    <div class="bg-gray-100 py-20">
        <div class="container mx-auto px-6">
            <h2 class="text-4xl font-bold text-center mb-12">Our Services</h2>
            <div class="grid md:grid-cols-4 gap-6">
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">📸</div>
                    <h3 class="font-bold mb-2">Instagram</h3>
                    <p class="text-sm text-gray-600">Followers, Likes, Views, Comments</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">🎥</div>
                    <h3 class="font-bold mb-2">YouTube</h3>
                    <p class="text-sm text-gray-600">Subscribers, Views, Likes</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">👥</div>
                    <h3 class="font-bold mb-2">Facebook</h3>
                    <p class="text-sm text-gray-600">Page Likes, Post Engagement</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">🐦</div>
                    <h3 class="font-bold mb-2">Twitter</h3>
                    <p class="text-sm text-gray-600">Followers, Retweets, Likes</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">🎵</div>
                    <h3 class="font-bold mb-2">TikTok</h3>
                    <p class="text-sm text-gray-600">Followers, Likes, Views</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">🎮</div>
                    <h3 class="font-bold mb-2">Twitch</h3>
                    <p class="text-sm text-gray-600">Followers, Views, Engagement</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">🔗</div>
                    <h3 class="font-bold mb-2">LinkedIn</h3>
                    <p class="text-sm text-gray-600">Connections, Page Followers</p>
                </div>
                <div class="bg-white rounded-lg p-6 text-center">
                    <div class="text-4xl mb-3">📱</div>
                    <h3 class="font-bold mb-2">Telegram</h3>
                    <p class="text-sm text-gray-600">Members, Views, Reactions</p>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA -->
    <div class="bg-blue-600 text-white py-20">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-4">Ready to Grow Your Social Media?</h2>
            <p class="text-xl mb-8">Join thousands of satisfied customers today!</p>
            <a href="{{ route('register') }}" class="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold text-lg inline-block hover:bg-blue-50">Create Free Account</a>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-12">
        <div class="container mx-auto px-6">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-white font-bold mb-4">{{ config('app.name') }}</h3>
                    <p class="text-sm">Your trusted SMM panel for social media growth.</p>
                </div>
                <div>
                    <h3 class="text-white font-bold mb-4">Quick Links</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ route('public.about') }}" class="hover:text-white">About Us</a></li>
                        <li><a href="{{ route('public.pricing') }}" class="hover:text-white">Pricing</a></li>
                        <li><a href="{{ route('blog.index') }}" class="hover:text-white">Blog</a></li>
                        <li><a href="{{ route('faqs') }}" class="hover:text-white">FAQs</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white font-bold mb-4">Legal</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ route('public.terms') }}" class="hover:text-white">Terms of Service</a></li>
                        <li><a href="{{ route('public.privacy') }}" class="hover:text-white">Privacy Policy</a></li>
                        <li><a href="{{ route('public.refund') }}" class="hover:text-white">Refund Policy</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white font-bold mb-4">Contact</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ route('public.contact') }}" class="hover:text-white">Contact Us</a></li>
                        <li><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="5c2f292c2c332e281c3f34393d2c2f3131723a2932">[email&#160;protected]</a></li>
                        <li>24/7 Support Available</li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
                <p>&copy; {{ date(