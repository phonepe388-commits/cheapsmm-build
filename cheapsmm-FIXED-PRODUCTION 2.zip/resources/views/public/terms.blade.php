@extends('layouts.app')
@section('title', 'Terms of Service')
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-8">Terms of Service</h1>
    
    <div class="prose max-w-none space-y-6">
        <p class="text-sm text-gray-600">Last Updated: {{ date('F d, Y') }}</p>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">1. Acceptance of Terms</h2>
            <p>By accessing and using {{ config('app.name') }}, you accept and agree to be bound by the terms and provision of this agreement.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">2. Service Description</h2>
            <p>{{ config('app.name') }} provides social media marketing services. We reserve the right to refuse service to anyone for any reason at any time.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">3. Account Registration</h2>
            <p>You must provide accurate, complete, and current information when creating an account. You are responsible for maintaining the security of your account credentials.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">4. Payment Terms</h2>
            <ul class="list-disc pl-6">
                <li>All payments are processed securely through our payment partners</li>
                <li>Once an order is placed and payment processed, it cannot be refunded unless the service is not delivered</li>
                <li>Added funds are non-refundable</li>
                <li>We reserve the right to modify pricing at any time</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">5. Service Delivery</h2>
            <ul class="list-disc pl-6">
                <li>Delivery times vary by service and are estimates only</li>
                <li>We are not responsible for delays caused by third-party providers</li>
                <li>Some services may experience drop rates - refill is available where indicated</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">6. Prohibited Activities</h2>
            <p>Users may not:</p>
            <ul class="list-disc pl-6">
                <li>Use the service for illegal activities</li>
                <li>Attempt to manipulate or exploit the system</li>
                <li>Share account credentials with others</li>
                <li>Submit false or fraudulent orders</li>
                <li>Use automated systems to place orders</li>
            </ul>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">7. Account Suspension</h2>
            <p>We reserve the right to suspend or terminate accounts that violate these terms without prior notice.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">8. Disclaimer</h2>
            <p>Services are provided "as is" without warranties. We are not responsible for any consequences resulting from the use of our services.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">9. Limitation of Liability</h2>
            <p>Our liability is limited to the amount paid for the specific service in question.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">10. Changes to Terms</h2>
            <p>We reserve the right to modify these terms at any time. Continued use of the service constitutes acceptance of modified terms.</p>
        </section>
        
        <section>
            <h2 class="text-2xl font-bold mt-6 mb-3">Contact</h2>
            <p>For questions about these terms, please contact us at support@cheapsmm.fun</p>
        </section>
    </div>
</div>
@endsection
