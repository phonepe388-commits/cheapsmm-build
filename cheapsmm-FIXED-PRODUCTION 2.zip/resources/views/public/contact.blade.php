@extends('layouts.app')
@section('title', 'Contact Us')
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-8">Contact Us</h1>
    
    <div class="grid md:grid-cols-2 gap-8">
        <div>
            <h2 class="text-2xl font-bold mb-4">Get in Touch</h2>
            <p class="mb-6">Have questions? We're here to help! Fill out the form and we'll get back to you as soon as possible.</p>
            
            <div class="space-y-4">
                <div class="flex items-start">
                    <div class="text-2xl mr-4">📧</div>
                    <div>
                        <div class="font-semibold">Email</div>
                        <div>support@cheapsmm.fun</div>
                    </div>
                </div>
                <div class="flex items-start">
                    <div class="text-2xl mr-4">💬</div>
                    <div>
                        <div class="font-semibold">Support Hours</div>
                        <div>24/7 Available</div>
                    </div>
                </div>
                <div class="flex items-start">
                    <div class="text-2xl mr-4">⏱️</div>
                    <div>
                        <div class="font-semibold">Response Time</div>
                        <div>Usually within 24 hours</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow-lg p-6">
            <form action="{{ route('public.contact.submit') }}" method="POST">
                @csrf
                <div class="mb-4">
                    <label class="block mb-2 font-semibold">Name</label>
                    <input type="text" name="name" required class="w-full border rounded px-3 py-2">
                </div>
                <div class="mb-4">
                    <label class="block mb-2 font-semibold">Email</label>
                    <input type="email" name="email" required class="w-full border rounded px-3 py-2">
                </div>
                <div class="mb-4">
                    <label class="block mb-2 font-semibold">Subject</label>
                    <input type="text" name="subject" required class="w-full border rounded px-3 py-2">
                </div>
                <div class="mb-4">
                    <label class="block mb-2 font-semibold">Message</label>
                    <textarea name="message" rows="5" required class="w-full border rounded px-3 py-2"></textarea>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded font-semibold hover:bg-blue-700">
                    Send Message
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
