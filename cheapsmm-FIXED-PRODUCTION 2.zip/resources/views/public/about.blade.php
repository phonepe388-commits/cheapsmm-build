@extends('layouts.app')
@section('title', 'About Us')
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-8">About {{ config('app.name') }}</h1>
    
    <div class="prose max-w-none">
        <p class="text-lg mb-6">Welcome to {{ config('app.name') }}, your premier destination for high-quality social media marketing services. We've been helping individuals, businesses, and influencers grow their social media presence since our inception.</p>
        
        <h2 class="text-2xl font-bold mt-8 mb-4">Our Mission</h2>
        <p>To provide affordable, reliable, and high-quality social media marketing services that help our clients achieve their goals and grow their online presence.</p>
        
        <h2 class="text-2xl font-bold mt-8 mb-4">Why Choose Us?</h2>
        <ul class="list-disc pl-6 space-y-2">
            <li><strong>Experience:</strong> Years of expertise in SMM industry</li>
            <li><strong>Quality:</strong> Real engagement from genuine accounts</li>
            <li><strong>Speed:</strong> Fast delivery on most services</li>
            <li><strong>Support:</strong> 24/7 customer support team</li>
            <li><strong>Security:</strong> SSL encrypted and secure payment processing</li>
            <li><strong>Pricing:</strong> Competitive rates with volume discounts</li>
        </ul>
        
        <h2 class="text-2xl font-bold mt-8 mb-4">Our Services</h2>
        <p>We offer a comprehensive range of social media marketing services across all major platforms including Instagram, YouTube, Facebook, Twitter, TikTok, and more. Whether you need followers, likes, views, or engagement, we've got you covered.</p>
        
        <h2 class="text-2xl font-bold mt-8 mb-4">Our Commitment</h2>
        <p>We are committed to providing exceptional service, maintaining the highest standards of quality, and ensuring customer satisfaction. Your success is our success.</p>
    </div>
    
    <div class="mt-12 bg-blue-50 rounded-lg p-8 text-center">
        <h3 class="text-2xl font-bold mb-4">Ready to Get Started?</h3>
        <p class="mb-6">Join thousands of satisfied customers today!</p>
        <a href="{{ route('register') }}" class="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold inline-block hover:bg-blue-700">Create Free Account</a>
    </div>
</div>
@endsection
