@php
$languages = [
    'en' => ['name' => 'English', 'native' => 'English', 'flag' => '🇬🇧'],
    'es' => ['name' => 'Spanish', 'native' => 'Español', 'flag' => '🇪🇸'],
    'fr' => ['name' => 'French', 'native' => 'Français', 'flag' => '🇫🇷'],
    'de' => ['name' => 'German', 'native' => 'Deutsch', 'flag' => '🇩🇪'],
    'pt' => ['name' => 'Portuguese', 'native' => 'Português', 'flag' => '🇵🇹'],
    'ar' => ['name' => 'Arabic', 'native' => 'العربية', 'flag' => '🇸🇦'],
    'hi' => ['name' => 'Hindi', 'native' => 'हिन्दी', 'flag' => '🇮🇳'],
    'zh' => ['name' => 'Chinese', 'native' => '中文', 'flag' => '🇨🇳'],
    'ja' => ['name' => 'Japanese', 'native' => '日本語', 'flag' => '🇯🇵'],
    'ru' => ['name' => 'Russian', 'native' => 'Русский', 'flag' => '🇷🇺'],
];
$currentLocale = app()->getLocale();
$currentLanguage = $languages[$currentLocale] ?? $languages['en'];
@endphp

<div class="relative" x-data="{ open: false }">
    <button @click="open = !open" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100">
        <span class="text-xl">{{ $currentLanguage['flag'] }}</span>
        <span class="text-sm font-medium">{{ $currentLanguage['native'] }}</span>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
    </button>

    <div x-show="open" 
         @click.away="open = false"
         x-transition:enter="transition ease-out duration-100"
         x-transition:enter-start="transform opacity-0 scale-95"
         x-transition:enter-end="transform opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-75"
         x-transition:leave-start="transform opacity-100 scale-100"
         x-transition:leave-end="transform opacity-0 scale-95"
         class="absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50"
         style="display: none;">
        <div class="py-1 max-h-96 overflow-y-auto">
            @foreach($languages as $code => $language)
                <form method="POST" action="{{ route('language.switch') }}" class="inline w-full">
                    @csrf
                    <input type="hidden" name="locale" value="{{ $code }}">
                    <button type="submit" 
                            class="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 flex items-center gap-3
                                   {{ $currentLocale === $code ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-gray-700' }}">
                        <span class="text-xl">{{ $language['flag'] }}</span>
                        <span class="flex-1">{{ $language['native'] }}</span>
                        @if($currentLocale === $code)
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                            </svg>
                        @endif
                    </button>
                </form>
            @endforeach
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
@endpush
