<div class="relative" x-data="{ open: false }">
    <button @click="open = !open" 
        class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100 transition">
        <span class="font-semibold">{{ currency_symbol() }}</span>
        <span class="text-sm">{{ user_currency() }}</span>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
    </button>

    <div x-show="open" 
        @click.away="open = false"
        x-transition
        class="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border z-50 max-h-96 overflow-y-auto">
        
        <div class="p-3 border-b bg-gray-50">
            <h3 class="font-semibold text-sm">Select Currency</h3>
        </div>

        @foreach(active_currencies() as $curr)
            <form method="POST" action="{{ route('user.currency.set') }}">
                @csrf
                <input type="hidden" name="currency" value="{{ $curr->code }}">
                <button type="submit" 
                    class="w-full px-4 py-2 hover:bg-gray-50 flex items-center justify-between text-left
                        {{ user_currency() === $curr->code ? 'bg-blue-50 text-blue-600' : '' }}">
                    <div class="flex items-center gap-3">
                        <span class="font-semibold text-lg">{{ $curr->symbol }}</span>
                        <div>
                            <div class="font-medium">{{ $curr->code }}</div>
                            <div class="text-xs text-gray-500">{{ $curr->name }}</div>
                        </div>
                    </div>
                    @if(user_currency() === $curr->code)
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    @endif
                </button>
            </form>
        @endforeach

        <div class="p-3 border-t bg-gray-50 text-xs text-gray-500">
            <p>Prices converted from USD</p>
            <p>Rates updated: {{ active_currencies()->first()?->last_updated?->diffForHumans() ?? 'Recently' }}</p>
        </div>
    </div>
</div>
