@props(['service'])

<div class="text-right">
    <div class="text-2xl font-bold text-blue-600">
        {!! price($service->price_per_1000 / 1000) !!}
    </div>
    <div class="text-xs text-gray-500">per 1000</div>
    
    @if(user_currency() !== 'USD')
        <div class="text-xs text-gray-400 mt-1">
            ${{ number_format($service->price_per_1000 / 1000, 2) }} USD
        </div>
    @endif

    <div class="text-xs text-gray-600 mt-2">
        Min: {{ number_format($service->min_quantity) }} | 
        Max: {{ number_format($service->max_quantity) }}
    </div>
</div>
