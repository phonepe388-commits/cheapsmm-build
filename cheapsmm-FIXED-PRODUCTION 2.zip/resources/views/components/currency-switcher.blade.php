<div class="relative inline-block" x-data="{ open: false }">
    <button @click="open = !open" class="flex items-center gap-2 px-3 py-2 bg-white border rounded-lg hover:bg-gray-50">
        <span class="font-semibold">{{ current_currency_symbol() }}</span>
        <span class="text-sm text-gray-600">{{ current_currency() }}</span>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
        </svg>
    </button>

    <div x-show="open" @click.away="open = false" x-cloak
         class="absolute right-0 mt-2 w-56 bg-white border rounded-lg shadow-lg z-50">
        <div class="p-2">
            <div class="text-xs font-semibold text-gray-500 px-3 py-2">SELECT CURRENCY</div>
            
            @php
                $popularCurrencies = currency()->getPopularCurrencies();
                $currentCode = current_currency();
            @endphp

            @foreach($popularCurrencies as $curr)
                <form method="POST" action="{{ route('currency.switch') }}" class="currency-switch-form">
                    @csrf
                    <input type="hidden" name="currency" value="{{ $curr->code }}">
                    <button type="submit" 
                        class="w-full text-left px-3 py-2 rounded hover:bg-gray-100 flex items-center justify-between
                               {{ $curr->code === $currentCode ? 'bg-blue-50 text-blue-600' : '' }}">
                        <span class="flex items-center gap-2">
                            <span class="font-semibold">{{ $curr->symbol }}</span>
                            <span class="text-sm">{{ $curr->name }}</span>
                        </span>
                        <span class="text-xs text-gray-500">{{ $curr->code }}</span>
                    </button>
                </form>
            @endforeach
        </div>
    </div>
</div>

@push('scripts')
<script>
// Submit currency switch via AJAX
document.querySelectorAll('.currency-switch-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch(this.action, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reload page to show new currency
                window.location.reload();
            }
        })
        .catch(error => console.error('Error:', error));
    });
});
</script>
@endpush

<style>
[x-cloak] { display: none !important; }
</style>
