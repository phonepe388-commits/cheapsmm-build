<div x-data="priceCalculator()" class="bg-blue-50 border border-blue-200 rounded-lg p-4">
    <h4 class="font-semibold mb-3">💰 Price Calculator</h4>
    
    <div class="space-y-2">
        <div class="flex justify-between">
            <span class="text-gray-700">Quantity:</span>
            <span class="font-semibold" x-text="quantity.toLocaleString()">0</span>
        </div>
        <div class="flex justify-between">
            <span class="text-gray-700">Price per 1000:</span>
            <span class="font-semibold">
                <span x-text="formatPrice(pricePerThousand)"></span>
                @if(user_currency() !== 'USD')
                    <span class="text-xs text-gray-500">($<span x-text="pricePerThousandUSD.toFixed(2)"></span>)</span>
                @endif
            </span>
        </div>
        <div class="border-t pt-2 flex justify-between">
            <span class="font-bold">Total Cost:</span>
            <span class="font-bold text-blue-600 text-lg">
                <span x-text="formatPrice(totalCost)"></span>
                @if(user_currency() !== 'USD')
                    <span class="text-sm text-gray-500">($<span x-text="totalCostUSD.toFixed(2)"></span>)</span>
                @endif
            </span>
        </div>
        
        <div x-show="insufficientBalance" class="bg-red-100 border border-red-300 rounded p-2 text-sm text-red-700">
            ⚠️ Insufficient balance. Add funds to continue.
        </div>
    </div>
</div>

@push('scripts')
<script>
function priceCalculator() {
    return {
        quantity: 0,
        pricePerThousandUSD: 0,
        pricePerThousand: 0,
        exchangeRate: {{ exchange_rate(user_currency()) }},
        currencySymbol: '{{ currency_symbol() }}',
        userBalance: {{ auth()->user()->balance ?? 0 }},
        
        get totalCost() {
            return (this.quantity / 1000) * this.pricePerThousand;
        },
        
        get totalCostUSD() {
            return (this.quantity / 1000) * this.pricePerThousandUSD;
        },
        
        get insufficientBalance() {
            return this.userBalance < this.totalCostUSD;
        },
        
        formatPrice(amount) {
            return this.currencySymbol + amount.toFixed(2);
        },
        
        updateService(servicePriceUSD) {
            this.pricePerThousandUSD = servicePriceUSD;
            this.pricePerThousand = servicePriceUSD * this.exchangeRate;
        }
    }
}
</script>
@endpush
