@extends('layouts.admin')

@section('title', 'Create Service')
@section('page-title', 'Create New Service')

@section('content')
<div class="max-w-3xl">
    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('admin.services.store') }}" class="bg-white rounded shadow p-6">
        @csrf

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-2">Category *</label>
            <select name="category_id" required class="w-full border rounded px-3 py-2">
                <option value="">Select Category</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-2">Service Name *</label>
            <input type="text" name="name" value="{{ old('name') }}" required
                class="w-full border rounded px-3 py-2" placeholder="e.g., Instagram Followers - Real">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-2">Description</label>
            <textarea name="description" rows="3" class="w-full border rounded px-3 py-2">{{ old('description') }}</textarea>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-4">
            <div>
                <label class="block text-gray-700 font-semibold mb-2">Price per 1000 *</label>
                <input type="number" name="price_per_1000" step="0.01" min="0" value="{{ old('price_per_1000') }}" required
                    class="w-full border rounded px-3 py-2">
            </div>
            <div>
                <label class="block text-gray-700 font-semibold mb-2">Min Quantity *</label>
                <input type="number" name="min_quantity" min="1" value="{{ old('min_quantity', 100) }}" required
                    class="w-full border rounded px-3 py-2">
            </div>
            <div>
                <label class="block text-gray-700 font-semibold mb-2">Max Quantity *</label>
                <input type="number" name="max_quantity" min="1" value="{{ old('max_quantity', 100000) }}" required
                    class="w-full border rounded px-3 py-2">
            </div>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-2">Status *</label>
            <select name="status" required class="w-full border rounded px-3 py-2">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="flex items-center">
                <input type="checkbox" name="dripfeed_enabled" value="1" class="mr-2">
                <span>Enable Dripfeed</span>
            </label>
        </div>

        <div class="mb-4">
            <label class="flex items-center">
                <input type="checkbox" name="refill_enabled" value="1" class="mr-2">
                <span>Enable Refill</span>
            </label>
        </div>

        <div class="flex gap-4">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                Create Service
            </button>
            <a href="{{ route('admin.services.index') }}" class="bg-gray-200 px-6 py-2 rounded hover:bg-gray-300">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection
