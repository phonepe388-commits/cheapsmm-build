@extends('layouts.admin')

@section('title', 'Services')
@section('page-title', 'Service Management')

@section('content')
<div class="flex justify-between items-center mb-6">
    <div class="grid grid-cols-3 gap-4 flex-1 mr-4">
        <div class="bg-white p-4 rounded shadow">
            <div class="text-gray-500 text-sm">Total Services</div>
            <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
        </div>
        <div class="bg-white p-4 rounded shadow">
            <div class="text-gray-500 text-sm">Active</div>
            <div class="text-2xl font-bold text-green-600">{{ $stats['active'] }}</div>
        </div>
        <div class="bg-white p-4 rounded shadow">
            <div class="text-gray-500 text-sm">Inactive</div>
            <div class="text-2xl font-bold text-gray-600">{{ $stats['inactive'] }}</div>
        </div>
    </div>
    <a href="{{ route('admin.services.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        <i class="fas fa-plus mr-2"></i>Add Service
    </a>
</div>

<!-- Filters -->
<div class="bg-white rounded shadow mb-4 p-4">
    <form method="GET" class="flex gap-4">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search services..." 
            class="border rounded px-3 py-2 flex-1">
        <select name="category" class="border rounded px-3 py-2">
            <option value="">All Categories</option>
            @foreach($categories as $category)
                <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                    {{ $category->name }}
                </option>
            @endforeach
        </select>
        <select name="status" class="border rounded px-3 py-2">
            <option value="">All Status</option>
            <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Active</option>
            <option value="inactive" {{ request('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>
    </form>
</div>

<!-- Services Table -->
<div class="bg-white rounded shadow overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price/1000</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Min/Max</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach($services as $service)
            <tr>
                <td class="px-6 py-4">#{{ $service->id }}</td>
                <td class="px-6 py-4">{{ Str::limit($service->name, 40) }}</td>
                <td class="px-6 py-4">{{ $service->category->name }}</td>
                <td class="px-6 py-4 font-semibold">${{ number_format($service->price_per_1000, 2) }}</td>
                <td class="px-6 py-4 text-sm">{{ number_format($service->min_quantity) }} / {{ number_format($service->max_quantity) }}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 text-xs rounded
                        {{ $service->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ ucfirst($service->status) }}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="{{ route('admin.services.edit', $service) }}" class="text-blue-600 hover:underline text-sm">Edit</a>
                        <form method="POST" action="{{ route('admin.services.destroy', $service) }}" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="return confirm('Are you sure?')" class="text-red-600 hover:underline text-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="mt-4">
    {{ $services->links() }}
</div>
@endsection
