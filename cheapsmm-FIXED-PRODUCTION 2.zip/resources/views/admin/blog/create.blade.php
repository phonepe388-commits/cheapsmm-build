@extends('layouts.admin')
@section('title', 'Create Post')
@section('page-title', 'Create Blog Post')
@section('content')
<div class="bg-white rounded-lg shadow p-6">
    <form method="POST" action="{{ route('admin.blog.store') }}">
        @csrf
        <div class="mb-4">
            <label class="block mb-2">Title</label>
            <input type="text" name="title" required class="w-full border rounded px-3 py-2">
        </div>
        <div class="mb-4">
            <label class="block mb-2">Excerpt</label>
            <textarea name="excerpt" rows="2" class="w-full border rounded px-3 py-2"></textarea>
        </div>
        <div class="mb-4">
            <label class="block mb-2">Content</label>
            <textarea name="content" rows="10" required class="w-full border rounded px-3 py-2"></textarea>
        </div>
        <div class="mb-4">
            <label class="block mb-2">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
            </select>
        </div>
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded">Create Post</button>
    </form>
</div>
@endsection
