@extends('layouts.admin')
@section('title', 'Blog Posts')
@section('page-title', 'Blog Management')
@section('content')
<div class="mb-6">
    <a href="{{ route('admin.blog.create') }}" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
        + New Post
    </a>
</div>

<div class="bg-white rounded-lg shadow">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Title</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($posts as $post)
            <tr>
                <td class="px-6 py-4 font-semibold">{{ $post->title }}</td>
                <td class="px-6 py-4">
                    @if($post->status === 'published')
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Published</span>
                    @else
                        <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">Draft</span>
                    @endif
                </td>
                <td class="px-6 py-4 text-sm">{{ $post->created_at->format('M d, Y') }}</td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="{{ route('admin.blog.edit', $post) }}" class="text-blue-600 text-sm">Edit</a>
                        <form method="POST" action="{{ route('admin.blog.destroy', $post) }}" class="inline" onsubmit="return confirm('Delete this post?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 text-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4" class="px-6 py-12 text-center text-gray-500">No blog posts yet</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
