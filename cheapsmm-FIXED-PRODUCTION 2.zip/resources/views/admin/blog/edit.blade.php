@extends('layouts.admin')
@section('title', 'Edit Blog Post')
@section('page-title', 'Edit Post')
@section('content')
<div class="bg-white rounded-lg shadow p-6">
    <form method="POST" action="{{ route('admin.blog.update', $blog) }}">
        @csrf
        @method('PUT')
        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Title</label>
            <input type="text" name="title" value="{{ $blog->title }}" class="w-full border rounded px-4 py-2" required>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Excerpt</label>
            <textarea name="excerpt" class="w-full border rounded px-4 py-2" rows="3">{{ $blog->excerpt }}</textarea>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Content</label>
            <textarea name="content" class="w-full border rounded px-4 py-2" rows="10" required>{{ $blog->content }}</textarea>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Featured Image URL</label>
            <input type="text" name="featured_image" value="{{ $blog->featured_image }}" class="w-full border rounded px-4 py-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Status</label>
            <select name="status" class="w-full border rounded px-4 py-2">
                <option value="draft" {{ $blog->status === 'draft' ? 'selected' : '' }}>Draft</option>
                <option value="published" {{ $blog->status === 'published' ? 'selected' : '' }}>Published</option>
            </select>
        </div>
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            Update Post
        </button>
    </form>
</div>
@endsection
