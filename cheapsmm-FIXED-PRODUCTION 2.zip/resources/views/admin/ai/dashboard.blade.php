@extends('layouts.admin')
@section('title', 'AI Dashboard')
@section('page-title', 'AI & Fraud Detection')
@section('content')
<div class="grid md:grid-cols-2 gap-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b bg-red-50">
            <h3 class="font-semibold text-red-800">🚨 Users At Risk of Churn</h3>
        </div>
        <div class="divide-y max-h-96 overflow-y-auto">
            @forelse($usersAtRisk ?? [] as $item)
            <div class="p-4">
                <div class="flex justify-between items-start">
                    <div>
                        <div class="font-semibold">{{ $item['user']->name }}</div>
                        <div class="text-sm text-gray-600">{{ $item['user']->email }}</div>
                    </div>
                </div>
            </div>
            @empty
            <div class="p-8 text-center text-gray-500">No users at risk</div>
            @endforelse
        </div>
    </div>

    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b bg-yellow-50">
            <h3 class="font-semibold text-yellow-800">⚠️ Suspicious Activity</h3>
        </div>
        <div class="divide-y max-h-96 overflow-y-auto">
            <div class="p-8 text-center text-gray-500">No suspicious activity detected</div>
        </div>
    </div>
</div>
@endsection
