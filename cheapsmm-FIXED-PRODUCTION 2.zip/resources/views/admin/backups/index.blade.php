@extends('layouts.admin')
@section('title', 'Backups')
@section('page-title', 'Backup & Recovery')
@section('content')

<div class="mb-6 flex gap-3">
    <form method="POST" action="{{ route('admin.backups.create-database') }}">
        @csrf
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            🗄️ Create Database Backup
        </button>
    </form>
    <form method="POST" action="{{ route('admin.backups.create-files') }}">
        @csrf
        <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">
            📁 Create Files Backup
        </button>
    </form>
</div>

@if(session('success'))
<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
    {{ session('success') }}
</div>
@endif

<div class="bg-white rounded-lg shadow">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Filename</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($backups as $backup)
            <tr>
                <td class="px-6 py-4">
                    @if($backup->type === 'database')
                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">Database</span>
                    @else
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Files</span>
                    @endif
                </td>
                <td class="px-6 py-4 text-sm font-mono">{{ $backup->filename }}</td>
                <td class="px-6 py-4 text-sm">{{ number_format($backup->size / 1024 / 1024, 2) }} MB</td>
                <td class="px-6 py-4 text-sm">{{ $backup->created_at->format('M d, Y H:i') }}</td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="{{ route('admin.backups.download', $backup) }}" class="text-blue-600 text-sm">Download</a>
                        @if($backup->type === 'database')
                        <form method="POST" action="{{ route('admin.backups.restore', $backup) }}" class="inline" onsubmit="return confirm('Restore this backup? This will overwrite current data!')">
                            @csrf
                            <button type="submit" class="text-green-600 text-sm">Restore</button>
                        </form>
                        @endif
                        <form method="POST" action="{{ route('admin.backups.destroy', $backup) }}" class="inline" onsubmit="return confirm('Delete this backup?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 text-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="px-6 py-12 text-center text-gray-500">No backups yet. Create your first backup!</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
