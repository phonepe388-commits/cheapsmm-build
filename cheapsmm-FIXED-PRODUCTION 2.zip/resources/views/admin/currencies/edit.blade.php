@extends('layouts.admin')

@section('title', 'Edit Currency')
@section('page-title', 'Edit Currency - ' . $currency->name)

@section('content')
<div class="max-w-2xl">
    <div class="bg-white rounded-lg shadow p-6">
        @if($errors->any())
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('admin.currencies.update', $currency) }}">
            @csrf
            @method('PUT')

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Currency Code</label>
                <input type="text" value="{{ $currency->code }}" disabled
                    class="w-full border rounded px-3 py-2 bg-gray-100">
                <p class="text-sm text-gray-500 mt-1">Currency code cannot be changed</p>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Currency Name *</label>
                <input type="text" name="name" value="{{ old('name', $currency->name) }}" required
                    class="w-full border rounded px-3 py-2">
            </div>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Symbol *</label>
                    <input type="text" name="symbol" value="{{ old('symbol', $currency->symbol) }}" required
                        class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Symbol Position *</label>
                    <select name="symbol_position" required class="w-full border rounded px-3 py-2">
                        <option value="before" {{ $currency->symbol_position === 'before' ? 'selected' : '' }}>Before (e.g., $100)</option>
                        <option value="after" {{ $currency->symbol_position === 'after' ? 'selected' : '' }}>After (e.g., 100€)</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Exchange Rate *</label>
                    <input type="number" name="exchange_rate" step="0.000001" 
                           value="{{ old('exchange_rate', $currency->exchange_rate) }}" required
                           class="w-full border rounded px-3 py-2">
                    <p class="text-sm text-gray-500 mt-1">Rate vs USD</p>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Decimal Places *</label>
                    <input type="number" name="decimal_places" min="0" max="4"
                           value="{{ old('decimal_places', $currency->decimal_places) }}" required
                           class="w-full border rounded px-3 py-2">
                </div>
            </div>

            <div class="mb-4">
                <label class="flex items-center gap-2">
                    <input type="checkbox" name="is_popular" value="1" 
                           {{ old('is_popular', $currency->is_popular) ? 'checked' : '' }}>
                    <span class="text-gray-700">Mark as popular (show in currency switcher)</span>
                </label>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Status *</label>
                <select name="status" required class="w-full border rounded px-3 py-2">
                    <option value="active" {{ $currency->status === 'active' ? 'selected' : '' }}>Active</option>
                    <option value="inactive" {{ $currency->status === 'inactive' ? 'selected' : '' }}>Inactive</option>
                </select>
            </div>

            <div class="flex gap-4">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                    Update Currency
                </button>
                <a href="{{ route('admin.currencies.index') }}" 
                   class="bg-gray-200 px-6 py-2 rounded hover:bg-gray-300">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>
@endsection
