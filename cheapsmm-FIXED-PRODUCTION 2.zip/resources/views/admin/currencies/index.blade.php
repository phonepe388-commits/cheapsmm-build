@extends('layouts.admin')

@section('title', 'Manage Currencies')
@section('page-title', 'Currency Management')

@section('content')
<div class="mb-6 flex justify-between items-center">
    <div class="flex gap-4">
        <div class="bg-blue-100 px-4 py-3 rounded-lg">
            <div class="text-sm text-blue-600">Total Currencies</div>
            <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
        </div>
        <div class="bg-green-100 px-4 py-3 rounded-lg">
            <div class="text-sm text-green-600">Active</div>
            <div class="text-2xl font-bold">{{ $stats['active'] }}</div>
        </div>
        <div class="bg-gray-100 px-4 py-3 rounded-lg">
            <div class="text-sm text-gray-600">Last Updated</div>
            <div class="text-sm font-semibold">{{ $stats['last_update'] ? $stats['last_update']->diffForHumans() : 'Never' }}</div>
        </div>
    </div>

    <div class="flex gap-2">
        <form method="POST" action="{{ route('admin.currencies.update-rates') }}">
            @csrf
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                🔄 Update Exchange Rates
            </button>
        </form>
        <a href="{{ route('admin.currencies.create') }}" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            + Add Currency
        </a>
    </div>
</div>

@if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
        {{ session('success') }}
    </div>
@endif

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Currency</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Exchange Rate</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Popular</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Updated</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            @foreach($currencies as $currency)
            <tr>
                <td class="px-6 py-4">
                    <div class="font-semibold">{{ $currency->code }}</div>
                    <div class="text-sm text-gray-600">{{ $currency->name }}</div>
                </td>
                <td class="px-6 py-4">
                    <span class="font-semibold text-lg">{{ $currency->symbol }}</span>
                </td>
                <td class="px-6 py-4">
                    <div class="font-mono">{{ number_format($currency->exchange_rate, 4) }}</div>
                    <div class="text-xs text-gray-600">vs USD</div>
                </td>
                <td class="px-6 py-4">
                    @if($currency->is_popular)
                        <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">★ Popular</span>
                    @else
                        <span class="text-gray-400">-</span>
                    @endif
                </td>
                <td class="px-6 py-4">
                    @if($currency->status === 'active')
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                    @else
                        <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">Inactive</span>
                    @endif
                </td>
                <td class="px-6 py-4 text-sm text-gray-600">
                    {{ $currency->last_updated ? $currency->last_updated->diffForHumans() : 'Never' }}
                </td>
                <td class="px-6 py-4 text-right">
                    <div class="flex gap-2 justify-end">
                        <a href="{{ route('admin.currencies.edit', $currency) }}" 
                           class="text-blue-600 hover:underline text-sm">Edit</a>
                        @if($currency->code !== 'USD')
                            <form method="POST" action="{{ route('admin.currencies.destroy', $currency) }}" 
                                  onsubmit="return confirm('Delete this currency?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline text-sm">Delete</button>
                            </form>
                        @endif
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="mt-4">
    {{ $currencies->links() }}
</div>
@endsection
