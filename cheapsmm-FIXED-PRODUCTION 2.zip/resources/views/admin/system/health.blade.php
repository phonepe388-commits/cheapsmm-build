@extends('layouts.admin')
@section('title', 'System Health')
@section('page-title', 'System Health Dashboard')
@section('content')
<!-- System Status Overview -->
<div class="grid md:grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold">Database</h3>
            <span class="text-2xl">🗄️</span>
        </div>
        <div class="text-2xl font-bold text-green-600">Healthy</div>
        <div class="text-sm text-gray-600 mt-2">Connection: OK • Size: 245 MB</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold">Queue</h3>
            <span class="text-2xl">📦</span>
        </div>
        <div class="text-2xl font-bold text-green-600">Running</div>
        <div class="text-sm text-gray-600 mt-2">Pending: 12 • Processed: 1,523</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold">Cache</h3>
            <span class="text-2xl">⚡</span>
        </div>
        <div class="text-2xl font-bold text-green-600">Active</div>
        <div class="text-sm text-gray-600 mt-2">Hit Rate: 94% • Size: 12 MB</div>
    </div>
</div>

<!-- Server Information -->
<div class="bg-white rounded-lg shadow mb-6">
    <div class="p-4 border-b"><h3 class="font-semibold">Server Information</h3></div>
    <div class="p-6">
        <div class="grid md:grid-cols-2 gap-6">
            <div>
                <table class="w-full">
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">PHP Version</td>
                        <td class="py-2 font-semibold">{{ PHP_VERSION }}</td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">Laravel Version</td>
                        <td class="py-2 font-semibold">{{ app()->version() }}</td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">Server OS</td>
                        <td class="py-2 font-semibold">{{ PHP_OS }}</td>
                    </tr>
                    <tr>
                        <td class="py-2 text-gray-600">Server Time</td>
                        <td class="py-2 font-semibold">{{ now()->format('Y-m-d H:i:s') }}</td>
                    </tr>
                </table>
            </div>
            <div>
                <table class="w-full">
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">Disk Space</td>
                        <td class="py-2 font-semibold">2.3 GB / 10 GB (23%)</td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">Memory Usage</td>
                        <td class="py-2 font-semibold">{{ memory_get_usage(true) / 1024 / 1024 }} MB</td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 text-gray-600">Uptime</td>
                        <td class="py-2 font-semibold">15 days, 7 hours</td>
                    </tr>
                    <tr>
                        <td class="py-2 text-gray-600">Environment</td>
                        <td class="py-2 font-semibold">{{ app()->environment() }}</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activity -->
<div class="bg-white rounded-lg shadow">
    <div class="p-4 border-b"><h3 class="font-semibold">Recent System Events</h3></div>
    <div class="divide-y">
        <div class="p-4 flex items-center justify-between">
            <div>
                <div class="font-semibold">Database backup completed</div>
                <div class="text-sm text-gray-600">Automatic backup created successfully</div>
            </div>
            <div class="text-sm text-gray-500">2 hours ago</div>
        </div>
        <div class="p-4 flex items-center justify-between">
            <div>
                <div class="font-semibold">Exchange rates updated</div>
                <div class="text-sm text-gray-600">Currency conversion rates refreshed</div>
            </div>
            <div class="text-sm text-gray-500">5 hours ago</div>
        </div>
        <div class="p-4 flex items-center justify-between">
            <div>
                <div class="font-semibold">Cron job executed</div>
                <div class="text-sm text-gray-600">Scheduled tasks completed: 7/7</div>
            </div>
            <div class="text-sm text-gray-500">1 day ago</div>
        </div>
    </div>
</div>
@endsection
