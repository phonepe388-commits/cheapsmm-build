@extends('layouts.admin')

@section('title', 'Automation & Scheduled Jobs')
@section('page-title', 'Automation & Scheduled Jobs')

@section('content')

@if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        {{ session('success') }}
    </div>
@endif

@if($errors->any())
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
        @foreach($errors->all() as $error)
            <div>{{ $error }}</div>
        @endforeach
    </div>
@endif

<!-- Cron Status -->
<div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
    <h3 class="text-lg font-semibold mb-3">⚙️ Cron Job Status</h3>
    <p class="text-sm mb-3">
        For automated scheduling, add this line to your server's crontab:
    </p>
    <div class="bg-gray-900 text-gray-100 p-4 rounded font-mono text-sm mb-3">
        * * * * * cd /path/to/your/project && php artisan schedule:run >> /dev/null 2>&1
    </div>
    <p class="text-xs text-gray-600">
        Replace <code>/path/to/your/project</code> with your actual project path.
    </p>
</div>

<!-- Scheduled Jobs Table -->
<div class="bg-white rounded-lg shadow mb-6">
    <div class="p-4 border-b">
        <h3 class="text-lg font-semibold">📋 Scheduled Jobs</h3>
    </div>
    
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Job Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Schedule</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Run</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @foreach($jobs as $job)
                <tr>
                    <td class="px-6 py-4">
                        <span class="font-semibold">{{ $job['name'] }}</span>
                    </td>
                    <td class="px-6 py-4 text-sm">
                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                            {{ $job['schedule'] }}
                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-600">
                        {{ $job['description'] }}
                    </td>
                    <td class="px-6 py-4 text-sm">
                        @if($job['last_run'])
                            {{ $job['last_run']->diffForHumans() }}
                        @else
                            <span class="text-gray-400">Never</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <form method="POST" action="{{ route('admin.automation.run') }}" class="inline">
                            @csrf
                            <input type="hidden" name="job" value="{{ $job['job'] }}">
                            <button type="submit" 
                                class="text-blue-600 hover:underline text-sm"
                                onclick="return confirm('Run this job now?')">
                                ▶ Run Now
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<!-- Recent Logs -->
<div class="bg-white rounded-lg shadow">
    <div class="p-4 border-b">
        <h3 class="text-lg font-semibold">📝 Recent Job Executions</h3>
    </div>
    
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Job</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Message</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Executed At</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @forelse($logs as $log)
                <tr>
                    <td class="px-6 py-4 text-sm font-semibold">
                        {{ $log['job'] }}
                    </td>
                    <td class="px-6 py-4">
                        @if($log['status'] === 'success')
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Success</span>
                        @else
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">Failed</span>
                        @endif
                    </td>
                    <td class="px-6 py-4 text-sm">
                        {{ $log['message'] }}
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-600">
                        {{ $log['executed_at']->format('M d, Y H:i:s') }}
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="4" class="px-6 py-8 text-center text-gray-500">
                        No recent job executions
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- Setup Guide -->
<div class="mt-6 bg-gray-50 rounded-lg p-6">
    <h3 class="font-semibold text-lg mb-3">📚 Setup Guide</h3>
    
    <div class="space-y-4 text-sm">
        <div>
            <h4 class="font-semibold mb-1">1. Server Cron Setup (Linux/cPanel)</h4>
            <p class="text-gray-600 mb-2">Add to crontab:</p>
            <code class="bg-gray-900 text-gray-100 p-2 rounded block">
                * * * * * cd /home/username/public_html && php artisan schedule:run >> /dev/null 2>&1
            </code>
        </div>

        <div>
            <h4 class="font-semibold mb-1">2. Verify Setup</h4>
            <p class="text-gray-600">
                Run manually to test: <code>php artisan schedule:run-all</code>
            </p>
        </div>

        <div>
            <h4 class="font-semibold mb-1">3. Monitor Logs</h4>
            <p class="text-gray-600">
                Check <code>storage/logs/laravel.log</code> for job execution logs
            </p>
        </div>
    </div>
</div>

@endsection
