@extends('layouts.admin')

@section('title', 'Child Panels')
@section('page-title', 'Child Panels Management')

@section('content')

<!-- Stats Cards -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Total Panels</div>
        <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
    </div>
    <div class="bg-green-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Active Panels</div>
        <div class="text-2xl font-bold text-green-600">{{ $stats['active'] }}</div>
    </div>
    <div class="bg-blue-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Total Panel Users</div>
        <div class="text-2xl font-bold text-blue-600">{{ $stats['total_users'] }}</div>
    </div>
    <div class="bg-purple-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Total Balance</div>
        <div class="text-2xl font-bold text-purple-600">${{ number_format($stats['total_revenue'], 2) }}</div>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-lg shadow p-4 mb-6">
    <form method="GET" class="flex gap-3">
        <input type="text" name="search" placeholder="Search panels..." 
            value="{{ request('search') }}"
            class="flex-1 border rounded px-3 py-2">
        <select name="status" class="border rounded px-3 py-2">
            <option value="">All Status</option>
            <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option>
            <option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Inactive</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            Filter
        </button>
    </form>
</div>

<!-- Panels Table -->
<div class="bg-white rounded-lg shadow">
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Panel</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Owner</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Balance</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Users</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Orders</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @forelse($panels as $panel)
                <tr>
                    <td class="px-6 py-4">
                        <div class="font-semibold">{{ $panel->name }}</div>
                        <div class="text-xs text-gray-500">{{ $panel->domain ?: $panel->subdomain }}</div>
                    </td>
                    <td class="px-6 py-4 text-sm">{{ $panel->user->name }}</td>
                    <td class="px-6 py-4 text-sm font-semibold">${{ number_format($panel->balance, 2) }}</td>
                    <td class="px-6 py-4 text-sm">{{ $panel->child_users_count }}</td>
                    <td class="px-6 py-4 text-sm">{{ $panel->orders_count }}</td>
                    <td class="px-6 py-4">
                        @if($panel->status === 'active')
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                        @else
                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">Inactive</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <a href="{{ route('admin.child-panels.show', $panel) }}" 
                           class="text-blue-600 hover:underline text-sm">
                            View
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                        No child panels found
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($panels->hasPages())
        <div class="p-4 border-t">
            {{ $panels->links() }}
        </div>
    @endif
</div>
@endsection
