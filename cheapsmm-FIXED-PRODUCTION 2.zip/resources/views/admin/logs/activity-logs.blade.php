@extends('layouts.admin')
@section('title', 'Activity Logs')
@section('page-title', 'User Activity Logs')
@section('content')
<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">IP</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($activities ?? [] as $activity)
            <tr>
                <td class="px-6 py-4 text-sm">{{ $activity->created_at->format('Y-m-d H:i:s') }}</td>
                <td class="px-6 py-4">{{ $activity->user->name ?? 'System' }}</td>
                <td class="px-6 py-4"><span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">{{ $activity->action }}</span></td>
                <td class="px-6 py-4 text-sm">{{ Str::limit($activity->details, 50) }}</td>
                <td class="px-6 py-4 text-sm">{{ $activity->ip_address }}</td>
            </tr>
            @empty
            <tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No activity logs found</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
