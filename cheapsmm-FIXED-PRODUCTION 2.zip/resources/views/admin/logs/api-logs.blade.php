@extends('layouts.admin')
@section('title', 'API Logs')
@section('page-title', 'API Request Logs')
@section('content')
<div class="mb-4 bg-white rounded-lg shadow p-4">
    <input type="text" placeholder="Search logs..." class="w-full border rounded px-3 py-2">
</div>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Endpoint</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Duration</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($logs ?? [] as $log)
            <tr>
                <td class="px-6 py-4 text-sm">{{ $log->created_at->format('Y-m-d H:i:s') }}</td>
                <td class="px-6 py-4 text-sm">{{ $log->user->name ?? 'N/A' }}</td>
                <td class="px-6 py-4 font-mono text-xs">{{ $log->endpoint }}</td>
                <td class="px-6 py-4"><span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">{{ $log->method }}</span></td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded text-xs {{ $log->status_code == 200 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                        {{ $log->status_code }}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm">{{ $log->duration_ms }}ms</td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-6 py-8 text-center text-gray-500">No API logs found</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
