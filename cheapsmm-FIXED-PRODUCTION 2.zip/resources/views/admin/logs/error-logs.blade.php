@extends('layouts.admin')
@section('title', 'Error Logs')
@section('page-title', 'System Error Logs')
@section('content')
<div class="mb-4 bg-yellow-50 border-l-4 border-yellow-600 p-4">
    <strong>⚠️ Warning:</strong> This page shows system errors. Regular errors are expected; investigate patterns of repeated errors.
</div>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Level</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Message</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">File</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Count</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($errors ?? [] as $error)
            <tr>
                <td class="px-6 py-4 text-sm">{{ $error->created_at->format('Y-m-d H:i:s') }}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded text-xs {{ $error->level == 'error' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800' }}">
                        {{ strtoupper($error->level) }}
                    </span>
                </td>
                <td class="px-6 py-4 font-mono text-xs">{{ Str::limit($error->message, 80) }}</td>
                <td class="px-6 py-4 text-xs">{{ Str::limit($error->file, 30) }}</td>
                <td class="px-6 py-4">{{ $error->count }}x</td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="px-6 py-8 text-center">
                    <div class="text-4xl mb-2">✅</div>
                    <div class="text-gray-500">No errors logged - System is healthy!</div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
