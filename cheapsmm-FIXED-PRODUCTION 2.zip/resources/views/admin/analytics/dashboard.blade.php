@extends('layouts.admin')
@section('title', 'Advanced Analytics')
@section('page-title', 'Advanced Analytics & Reports')
@section('content')
<!-- Key Metrics -->
<div class="grid md:grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Total Revenue</div>
        <div class="text-3xl font-bold text-blue-600">${{ number_format($metrics['revenue'] ?? 12500, 2) }}</div>
        <div class="text-xs text-green-600 mt-1">↑ +12.5% from last period</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Orders Completed</div>
        <div class="text-3xl font-bold text-green-600">{{ number_format($metrics['orders_completed'] ?? 523) }}</div>
        <div class="text-xs text-green-600 mt-1">↑ +8.3% from last period</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">New Users</div>
        <div class="text-3xl font-bold text-purple-600">{{ number_format($metrics['new_users'] ?? 89) }}</div>
        <div class="text-xs text-green-600 mt-1">↑ +15.2% from last period</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Avg Order Value</div>
        <div class="text-3xl font-bold text-orange-600">${{ number_format($metrics['avg_order_value'] ?? 23.89, 2) }}</div>
        <div class="text-xs text-red-600 mt-1">↓ -2.1% from last period</div>
    </div>
</div>

<!-- Charts -->
<div class="grid md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Revenue Trend</h3></div>
        <div class="p-4">
            <canvas id="revenueChart" height="250"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Order Status</h3></div>
        <div class="p-4">
            <canvas id="statusChart" height="250"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Revenue',
            data: [1200, 1900, 1500, 2500, 2200, 3000],
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: ['Completed', 'Processing', 'Pending', 'Failed'],
        datasets: [{ data: [65, 20, 10, 5], backgroundColor: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'] }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>
@endsection
