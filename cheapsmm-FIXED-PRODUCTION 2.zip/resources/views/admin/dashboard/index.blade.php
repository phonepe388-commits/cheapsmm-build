@extends('layouts.admin')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
    <!-- Stats Cards -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Users</p>
                <p class="text-2xl font-bold">{{ number_format($stats['total_users']) }}</p>
                <p class="text-sm text-green-600">+{{ $stats['new_users_today'] }} today</p>
            </div>
            <div class="bg-blue-100 rounded-full p-3">
                <i class="fas fa-users text-blue-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Orders</p>
                <p class="text-2xl font-bold">{{ number_format($stats['total_orders']) }}</p>
                <p class="text-sm text-blue-600">{{ $stats['pending_orders'] }} pending</p>
            </div>
            <div class="bg-green-100 rounded-full p-3">
                <i class="fas fa-shopping-cart text-green-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Revenue Today</p>
                <p class="text-2xl font-bold">${{ number_format($stats['revenue_today'], 2) }}</p>
                <p class="text-sm text-gray-600">${{ number_format($stats['revenue_month'], 2) }} this month</p>
            </div>
            <div class="bg-yellow-100 rounded-full p-3">
                <i class="fas fa-dollar-sign text-yellow-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Open Tickets</p>
                <p class="text-2xl font-bold">{{ $stats['open_tickets'] }}</p>
                <p class="text-sm text-red-600">Need attention</p>
            </div>
            <div class="bg-red-100 rounded-full p-3">
                <i class="fas fa-ticket text-red-600 text-xl"></i>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    <!-- Recent Orders -->
    <div class="bg-white rounded-lg shadow">
        <div class="p-6 border-b">
            <h3 class="font-semibold text-lg">Recent Orders</h3>
        </div>
        <div class="p-6">
            <table class="w-full">
                <thead>
                    <tr class="text-left text-gray-600 text-sm">
                        <th class="pb-2">ID</th>
                        <th class="pb-2">User</th>
                        <th class="pb-2">Service</th>
                        <th class="pb-2">Status</th>
                        <th class="pb-2">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($recentOrders as $order)
                    <tr class="border-t">
                        <td class="py-2">#{{ $order->id }}</td>
                        <td>{{ $order->user->name }}</td>
                        <td>{{ Str::limit($order->service->name, 20) }}</td>
                        <td>
                            <span class="px-2 py-1 text-xs rounded 
                                @if($order->status === 'completed') bg-green-100 text-green-800
                                @elseif($order->status === 'pending') bg-yellow-100 text-yellow-800
                                @else bg-gray-100 text-gray-800
                                @endif">
                                {{ ucfirst($order->status) }}
                            </span>
                        </td>
                        <td>${{ number_format($order->charge, 2) }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Users -->
    <div class="bg-white rounded-lg shadow">
        <div class="p-6 border-b">
            <h3 class="font-semibold text-lg">Recent Users</h3>
        </div>
        <div class="p-6">
            <table class="w-full">
                <thead>
                    <tr class="text-left text-gray-600 text-sm">
                        <th class="pb-2">Name</th>
                        <th class="pb-2">Email</th>
                        <th class="pb-2">Balance</th>
                        <th class="pb-2">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($recentUsers as $user)
                    <tr class="border-t">
                        <td class="py-2">{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>${{ number_format($user->balance, 2) }}</td>
                        <td>
                            <span class="px-2 py-1 text-xs rounded 
                                @if($user->status === 'active') bg-green-100 text-green-800
                                @else bg-red-100 text-red-800
                                @endif">
                                {{ ucfirst($user->status) }}
                            </span>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="bg-white rounded-lg shadow p-6">
    <h3 class="font-semibold text-lg mb-4">Revenue Chart (Last 30 Days)</h3>
    <canvas id="revenueChart"></canvas>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: @json($revenueChart->pluck('date')),
        datasets: [{
            label: 'Revenue',
            data: @json($revenueChart->pluck('total')),
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    }
});
</script>
@endpush
@endsection
