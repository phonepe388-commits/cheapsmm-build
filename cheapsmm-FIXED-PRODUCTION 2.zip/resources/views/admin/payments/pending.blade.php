@extends('layouts.admin')

@section('title', 'Pending Payments')
@section('page-title', 'Pending Manual Payments')

@section('content')
<div class="mb-6">
    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p class="text-yellow-800">
            <strong>{{ $payments->count() }}</strong> payment(s) waiting for your review
        </p>
    </div>
</div>

@if($payments->isEmpty())
    <div class="bg-white rounded-lg shadow p-8 text-center">
        <div class="text-gray-400 text-4xl mb-4">✓</div>
        <p class="text-gray-600">No pending payments to review</p>
    </div>
@else
    <div class="space-y-4">
        @foreach($payments as $payment)
        <div class="bg-white rounded-lg shadow">
            <div class="p-6">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h3 class="font-semibold text-lg">Payment #{{ $payment->id }}</h3>
                        <p class="text-gray-600 text-sm">{{ $payment->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="text-right">
                        <div class="text-2xl font-bold text-green-600">${{ number_format($payment->amount, 2) }}</div>
                        <div class="text-sm text-gray-600">{{ $payment->paymentMethod->name }}</div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4 p-4 bg-gray-50 rounded">
                    <div>
                        <div class="text-sm text-gray-600">User</div>
                        <div class="font-semibold">{{ $payment->user->name }}</div>
                        <div class="text-sm text-gray-600">{{ $payment->user->email }}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-600">Transaction Reference</div>
                        <div class="font-semibold">{{ $payment->metadata['payment_details']['transaction_ref'] ?? 'N/A' }}</div>
                    </div>
                </div>

                @if(isset($payment->metadata['payment_details']))
                <div class="mb-4 p-4 bg-blue-50 rounded">
                    <h4 class="font-semibold mb-2">Payment Details:</h4>
                    <div class="grid grid-cols-2 gap-2 text-sm">
                        <div>
                            <span class="text-gray-600">Sender:</span>
                            <span class="font-semibold ml-2">{{ $payment->metadata['payment_details']['sender_name'] ?? 'N/A' }}</span>
                        </div>
                        <div>
                            <span class="text-gray-600">Transfer Date:</span>
                            <span class="font-semibold ml-2">{{ $payment->metadata['payment_details']['transfer_date'] ?? 'N/A' }}</span>
                        </div>
                        @if(isset($payment->metadata['payment_details']['receipt_file']))
                        <div class="col-span-2">
                            <a href="{{ Storage::url($payment->metadata['payment_details']['receipt_file']) }}" target="_blank" 
                                class="text-blue-600 hover:underline">
                                <i class="fas fa-file-pdf mr-1"></i> View Receipt
                            </a>
                        </div>
                        @endif
                        @if(isset($payment->metadata['payment_details']['notes']))
                        <div class="col-span-2">
                            <span class="text-gray-600">Notes:</span>
                            <p class="mt-1">{{ $payment->metadata['payment_details']['notes'] }}</p>
                        </div>
                        @endif
                    </div>
                </div>
                @endif

                <div class="flex gap-4">
                    <!-- Approve Form -->
                    <form method="POST" action="{{ route('admin.payments.approve', $payment) }}" class="flex-1">
                        @csrf
                        <input type="text" name="notes" placeholder="Admin notes (optional)" 
                            class="w-full border rounded px-3 py-2 mb-2 text-sm">
                        <button type="submit" 
                            class="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700">
                            ✓ Approve Payment
                        </button>
                    </form>

                    <!-- Reject Button -->
                    <button onclick="showRejectForm({{ $payment->id }})" 
                        class="flex-1 bg-red-600 text-white py-2 rounded hover:bg-red-700">
                        ✗ Reject Payment
                    </button>
                </div>

                <!-- Reject Form (Hidden) -->
                <div id="reject-form-{{ $payment->id }}" class="hidden mt-4 p-4 bg-red-50 rounded">
                    <form method="POST" action="{{ route('admin.payments.reject', $payment) }}">
                        @csrf
                        <label class="block text-sm font-semibold mb-2">Rejection Reason *</label>
                        <textarea name="reason" rows="3" required 
                            class="w-full border rounded px-3 py-2 mb-2"></textarea>
                        <div class="flex gap-2">
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
                                Confirm Rejection
                            </button>
                            <button type="button" onclick="hideRejectForm({{ $payment->id }})" 
                                class="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </div>
@endif

@push('scripts')
<script>
function showRejectForm(id) {
    document.getElementById('reject-form-' + id).classList.remove('hidden');
}
function hideRejectForm(id) {
    document.getElementById('reject-form-' + id).classList.add('hidden');
}
</script>
@endpush
@endsection
