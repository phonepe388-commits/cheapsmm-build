@extends('layouts.admin')

@section('title', 'User Details')
@section('page-title', 'User #' . $user->id)

@section('content')
<div class="mb-4">
    <a href="{{ route('admin.users.index') }}" class="text-blue-600 hover:underline">
        <i class="fas fa-arrow-left mr-2"></i>Back to Users
    </a>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- User Info -->
    <div class="lg:col-span-1">
        <div class="bg-white rounded shadow p-6">
            <div class="text-center mb-4">
                <div class="w-20 h-20 rounded-full bg-gray-200 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-3xl text-gray-400"></i>
                </div>
                <h3 class="font-semibold text-lg">{{ $user->name }}</h3>
                <p class="text-sm text-gray-500">{{ $user->email }}</p>
            </div>

            <div class="space-y-3 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-500">Status:</span>
                    <span class="font-semibold 
                        @if($user->status === 'active') text-green-600
                        @elseif($user->status === 'suspended') text-yellow-600
                        @else text-red-600
                        @endif">
                        {{ ucfirst($user->status) }}
                    </span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Balance:</span>
                    <span class="font-semibold">${{ number_format($user->balance, 2) }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Member Since:</span>
                    <span class="font-semibold">{{ $user->created_at->format('M d, Y') }}</span>
                </div>
            </div>

            <div class="mt-6 space-y-2">
                <a href="{{ route('admin.users.edit', $user) }}" class="block w-full bg-blue-600 text-white text-center py-2 rounded hover:bg-blue-700">
                    Edit User
                </a>
                
                @if($user->status !== 'suspended')
                <button onclick="document.getElementById('suspend-form').classList.remove('hidden')" 
                    class="block w-full bg-yellow-600 text-white text-center py-2 rounded hover:bg-yellow-700">
                    Suspend User
                </button>
                @else
                <form method="POST" action="{{ route('admin.users.unsuspend', $user) }}">
                    @csrf
                    <button type="submit" class="block w-full bg-green-600 text-white text-center py-2 rounded hover:bg-green-700">
                        Unsuspend User
                    </button>
                </form>
                @endif

                <form method="POST" action="{{ route('admin.users.login-as', $user) }}">
                    @csrf
                    <button type="submit" class="block w-full bg-purple-600 text-white text-center py-2 rounded hover:bg-purple-700">
                        Login As User
                    </button>
                </form>
            </div>
        </div>

        <!-- Suspend Form (Hidden) -->
        <div id="suspend-form" class="hidden bg-white rounded shadow p-6 mt-4">
            <h4 class="font-semibold mb-4">Suspend User</h4>
            <form method="POST" action="{{ route('admin.users.suspend', $user) }}">
                @csrf
                <div class="mb-4">
                    <label class="block text-sm mb-2">Reason</label>
                    <textarea name="reason" rows="3" required class="w-full border rounded px-3 py-2"></textarea>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700">Suspend</button>
                    <button type="button" onclick="document.getElementById('suspend-form').classList.add('hidden')" 
                        class="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Activity & Stats -->
    <div class="lg:col-span-2 space-y-6">
        <!-- Stats Cards -->
        <div class="grid grid-cols-3 gap-4">
            <div class="bg-white p-4 rounded shadow">
                <div class="text-gray-500 text-sm">Total Orders</div>
                <div class="text-2xl font-bold">{{ $stats['total_orders'] }}</div>
            </div>
            <div class="bg-white p-4 rounded shadow">
                <div class="text-gray-500 text-sm">Total Spent</div>
                <div class="text-2xl font-bold">${{ number_format($stats['total_spent'], 2) }}</div>
            </div>
            <div class="bg-white p-4 rounded shadow">
                <div class="text-gray-500 text-sm">Current Balance</div>
                <div class="text-2xl font-bold">${{ number_format($stats['current_balance'], 2) }}</div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="bg-white rounded shadow">
            <div class="p-4 border-b">
                <h3 class="font-semibold">Recent Orders</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 text-xs">
                        <tr>
                            <th class="px-4 py-2 text-left">ID</th>
                            <th class="px-4 py-2 text-left">Service</th>
                            <th class="px-4 py-2 text-left">Status</th>
                            <th class="px-4 py-2 text-left">Amount</th>
                            <th class="px-4 py-2 text-left">Date</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y">
                        @forelse($user->orders as $order)
                        <tr>
                            <td class="px-4 py-2">#{{ $order->id }}</td>
                            <td class="px-4 py-2">{{ Str::limit($order->service->name, 30) }}</td>
                            <td class="px-4 py-2">
                                <span class="px-2 py-1 text-xs rounded bg-gray-100">{{ $order->status }}</span>
                            </td>
                            <td class="px-4 py-2">${{ number_format($order->charge, 2) }}</td>
                            <td class="px-4 py-2">{{ $order->created_at->format('M d, Y') }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">No orders yet</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
