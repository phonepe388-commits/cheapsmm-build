@extends('layouts.admin')

@section('title', 'Users')
@section('page-title', 'User Management')

@section('content')
<!-- Stats -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Total Users</div>
        <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Active</div>
        <div class="text-2xl font-bold text-green-600">{{ $stats['active'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Suspended</div>
        <div class="text-2xl font-bold text-yellow-600">{{ $stats['suspended'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Banned</div>
        <div class="text-2xl font-bold text-red-600">{{ $stats['banned'] }}</div>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded shadow mb-4 p-4">
    <form method="GET" class="flex gap-4">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search users..." 
            class="border rounded px-3 py-2 flex-1">
        <select name="status" class="border rounded px-3 py-2">
            <option value="">All Status</option>
            <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Active</option>
            <option value="suspended" {{ request('status') == 'suspended' ? 'selected' : '' }}>Suspended</option>
            <option value="banned" {{ request('status') == 'banned' ? 'selected' : '' }}>Banned</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Filter</button>
        <a href="{{ route('admin.users.index') }}" class="bg-gray-200 px-4 py-2 rounded hover:bg-gray-300">Reset</a>
    </form>
</div>

<!-- Users Table -->
<div class="bg-white rounded shadow overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Balance</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Joined</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach($users as $user)
            <tr>
                <td class="px-6 py-4">#{{ $user->id }}</td>
                <td class="px-6 py-4">{{ $user->name }}</td>
                <td class="px-6 py-4">{{ $user->email }}</td>
                <td class="px-6 py-4 font-semibold">${{ number_format($user->balance, 2) }}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 text-xs rounded
                        @if($user->status === 'active') bg-green-100 text-green-800
                        @elseif($user->status === 'suspended') bg-yellow-100 text-yellow-800
                        @else bg-red-100 text-red-800
                        @endif">
                        {{ ucfirst($user->status) }}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm">{{ $user->created_at->format('M d, Y') }}</td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="{{ route('admin.users.show', $user) }}" class="text-blue-600 hover:underline text-sm">View</a>
                        <a href="{{ route('admin.users.edit', $user) }}" class="text-green-600 hover:underline text-sm">Edit</a>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="mt-4">
    {{ $users->links() }}
</div>
@endsection
