@extends('layouts.admin')
@section('title', 'API Documentation')
@section('content')
<div class="max-w-6xl mx-auto">
    <h1 class="text-2xl font-bold mb-6">API Documentation v2</h1>
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
        <h3 class="font-semibold text-lg mb-2">🔑 Authentication</h3>
        <p class="mb-2">Header: <code class="bg-white px-2 py-1 rounded">X-API-Key: your_key</code></p>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-bold">Available Endpoints:</h3>
        <ul class="mt-4 space-y-2 text-sm">
            <li>✓ GET /api/v2/balance</li>
            <li>✓ GET /api/v2/services</li>
            <li>✓ POST /api/v2/add</li>
            <li>✓ POST /api/v2/status</li>
            <li>✓ POST /api/v2/add-multi</li>
            <li>✓ POST /api/v2/refill</li>
            <li>✓ POST /api/v2/cancel</li>
        </ul>
    </div>
</div>
@endsection
