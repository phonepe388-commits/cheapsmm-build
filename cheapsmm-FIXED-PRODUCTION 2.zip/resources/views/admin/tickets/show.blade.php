@extends('layouts.admin')

@section('title', 'Ticket #' . $ticket->id)
@section('page-title', 'Ticket #' . $ticket->id)

@section('content')
<div class="mb-4">
    <a href="{{ route('admin.tickets.index') }}" class="text-blue-600 hover:underline">
        <i class="fas fa-arrow-left mr-2"></i>Back to Tickets
    </a>
</div>

<!-- Ticket Header -->
<div class="bg-white rounded shadow p-6 mb-6">
    <div class="flex justify-between items-start mb-4">
        <div>
            <h2 class="text-xl font-bold mb-2">{{ $ticket->subject }}</h2>
            <div class="flex gap-4 text-sm text-gray-600">
                <span><i class="fas fa-user mr-1"></i>{{ $ticket->user->name }}</span>
                <span><i class="fas fa-envelope mr-1"></i>{{ $ticket->user->email }}</span>
                <span><i class="fas fa-calendar mr-1"></i>{{ $ticket->created_at->format('M d, Y H:i') }}</span>
            </div>
        </div>
        <div class="text-right space-y-2">
            <span class="inline-block px-3 py-1 rounded text-sm
                @if($ticket->priority === 'high') bg-red-100 text-red-800
                @elseif($ticket->priority === 'medium') bg-yellow-100 text-yellow-800
                @else bg-green-100 text-green-800
                @endif">
                {{ ucfirst($ticket->priority) }} Priority
            </span>
            <br>
            <span class="inline-block px-3 py-1 rounded text-sm
                @if($ticket->status === 'open') bg-blue-100 text-blue-800
                @elseif($ticket->status === 'waiting_reply') bg-yellow-100 text-yellow-800
                @elseif($ticket->status === 'answered') bg-green-100 text-green-800
                @else bg-gray-100 text-gray-800
                @endif">
                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
            </span>
        </div>
    </div>

    @if($ticket->status !== 'closed')
    <form method="POST" action="{{ route('admin.tickets.close', $ticket) }}">
        @csrf
        <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 text-sm">
            Close Ticket
        </button>
    </form>
    @endif
</div>

<!-- Messages -->
<div class="space-y-4 mb-6">
    @foreach($ticket->messages as $message)
    <div class="bg-white rounded shadow p-6 {{ $message->is_admin ? 'border-l-4 border-blue-500' : '' }}">
        <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                @if($message->is_admin)
                    <i class="fas fa-user-shield text-blue-600"></i>
                @else
                    <i class="fas fa-user text-gray-600"></i>
                @endif
            </div>
            <div>
                <div class="font-semibold">{{ $message->is_admin ? ($message->admin->name ?? 'Admin') : $message->user->name }}</div>
                <div class="text-sm text-gray-500">{{ $message->created_at->format('M d, Y H:i') }}</div>
            </div>
        </div>
        <div class="prose max-w-none">
            {!! nl2br(e($message->message)) !!}
        </div>
    </div>
    @endforeach
</div>

<!-- Reply Form -->
@if($ticket->status !== 'closed')
<div class="bg-white rounded shadow p-6">
    <h3 class="font-semibold mb-4">Reply to Ticket</h3>
    <form method="POST" action="{{ route('admin.tickets.reply', $ticket) }}" enctype="multipart/form-data">
        @csrf
        <div class="mb-4">
            <textarea name="message" rows="5" required
                class="w-full border rounded px-4 py-2" placeholder="Type your reply..."></textarea>
        </div>
        <div class="mb-4">
            <input type="file" name="attachments[]" multiple accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                class="w-full border rounded px-4 py-2">
        </div>
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            Send Reply
        </button>
    </form>
</div>
@endif
@endsection
