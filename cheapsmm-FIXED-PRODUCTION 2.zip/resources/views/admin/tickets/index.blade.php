@extends('layouts.admin')

@section('title', 'Support Tickets')
@section('page-title', 'Support Tickets')

@section('content')
<!-- Stats -->
<div class="grid grid-cols-4 gap-4 mb-6">
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Total</div>
        <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Open</div>
        <div class="text-2xl font-bold text-blue-600">{{ $stats['open'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Waiting</div>
        <div class="text-2xl font-bold text-yellow-600">{{ $stats['waiting'] }}</div>
    </div>
    <div class="bg-white p-4 rounded shadow">
        <div class="text-gray-500 text-sm">Answered</div>
        <div class="text-2xl font-bold text-green-600">{{ $stats['answered'] }}</div>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded shadow mb-4 p-4">
    <form method="GET" class="flex gap-4">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search tickets..." 
            class="border rounded px-3 py-2 flex-1">
        <select name="status" class="border rounded px-3 py-2">
            <option value="">All Status</option>
            <option value="open" {{ request('status') == 'open' ? 'selected' : '' }}>Open</option>
            <option value="waiting_reply" {{ request('status') == 'waiting_reply' ? 'selected' : '' }}>Waiting Reply</option>
            <option value="answered" {{ request('status') == 'answered' ? 'selected' : '' }}>Answered</option>
            <option value="closed" {{ request('status') == 'closed' ? 'selected' : '' }}>Closed</option>
        </select>
        <select name="priority" class="border rounded px-3 py-2">
            <option value="">All Priorities</option>
            <option value="high" {{ request('priority') == 'high' ? 'selected' : '' }}>High</option>
            <option value="medium" {{ request('priority') == 'medium' ? 'selected' : '' }}>Medium</option>
            <option value="low" {{ request('priority') == 'low' ? 'selected' : '' }}>Low</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>
    </form>
</div>

<!-- Tickets Table -->
<div class="bg-white rounded shadow overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priority</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Updated</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach($tickets as $ticket)
            <tr>
                <td class="px-6 py-4">#{{ $ticket->id }}</td>
                <td class="px-6 py-4">{{ $ticket->user->name }}</td>
                <td class="px-6 py-4">
                    <a href="{{ route('admin.tickets.show', $ticket) }}" class="text-blue-600 hover:underline">
                        {{ Str::limit($ticket->subject, 40) }}
                    </a>
                </td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 text-xs rounded
                        @if($ticket->priority === 'high') bg-red-100 text-red-800
                        @elseif($ticket->priority === 'medium') bg-yellow-100 text-yellow-800
                        @else bg-green-100 text-green-800
                        @endif">
                        {{ ucfirst($ticket->priority) }}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 text-xs rounded
                        @if($ticket->status === 'open') bg-blue-100 text-blue-800
                        @elseif($ticket->status === 'waiting_reply') bg-yellow-100 text-yellow-800
                        @elseif($ticket->status === 'answered') bg-green-100 text-green-800
                        @else bg-gray-100 text-gray-800
                        @endif">
                        {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm">{{ $ticket->updated_at->diffForHumans() }}</td>
                <td class="px-6 py-4">
                    <a href="{{ route('admin.tickets.show', $ticket) }}" class="text-blue-600 hover:underline">Reply</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="mt-4">
    {{ $tickets->links() }}
</div>
@endsection
