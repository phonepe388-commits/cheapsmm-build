@extends('layouts.admin')
@section('title', 'Customer Segments')
@section('page-title', 'Customer Segments')
@section('content')
<div class="mb-6">
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" 
            class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
        + Create Segment
    </button>
</div>

<div class="bg-white rounded-lg shadow">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Users</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach($segments as $segment)
            <tr>
                <td class="px-6 py-4 font-semibold">{{ $segment->name }}</td>
                <td class="px-6 py-4">{{ $segment->users_count }}</td>
                <td class="px-6 py-4">{{ $segment->created_at->format('M d, Y') }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<!-- Create Modal -->
<div id="createModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
    <div class="bg-white rounded-lg p-8 max-w-md w-full">
        <h3 class="text-xl font-bold mb-4">Create Segment</h3>
        <form method="POST" action="{{ route('admin.crm.create-segment') }}">
            @csrf
            <div class="mb-4">
                <label class="block mb-2">Name</label>
                <input type="text" name="name" required class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label class="block mb-2">Minimum Spending</label>
                <input type="number" name="spending_min" step="0.01" class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label class="block mb-2">Minimum Orders</label>
                <input type="number" name="min_orders" class="w-full border rounded px-3 py-2">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Create</button>
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" 
                        class="bg-gray-300 px-4 py-2 rounded">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
