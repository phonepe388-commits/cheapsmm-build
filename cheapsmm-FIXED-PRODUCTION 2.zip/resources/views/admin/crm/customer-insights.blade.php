@extends('layouts.admin')
@section('title', 'Customer Insights')
@section('page-title', 'Customer: ' . $user->name)
@section('content')
<div class="grid md:grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Lifetime Value</div>
        <div class="text-2xl font-bold">${{ number_format($insights['lifetime_value'], 2) }}</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Total Orders</div>
        <div class="text-2xl font-bold">{{ $insights['total_orders'] }}</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Avg Order Value</div>
        <div class="text-2xl font-bold">${{ number_format($insights['average_order_value'], 2) }}</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Current Balance</div>
        <div class="text-2xl font-bold">${{ number_format($insights['current_balance'], 2) }}</div>
    </div>
</div>

<div class="bg-white rounded-lg shadow">
    <div class="p-4 border-b"><h3 class="font-semibold">Recent Orders</h3></div>
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Charge</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                @foreach($orders as $order)
                <tr>
                    <td class="px-6 py-4">{{ $order->id }}</td>
                    <td class="px-6 py-4">{{ $order->service->name }}</td>
                    <td class="px-6 py-4">${{ number_format($order->charge, 2) }}</td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded text-xs
                            {{ $order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                            {{ $order->status }}
                        </span>
                    </td>
                    <td class="px-6 py-4">{{ $order->created_at->format('M d, Y') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
