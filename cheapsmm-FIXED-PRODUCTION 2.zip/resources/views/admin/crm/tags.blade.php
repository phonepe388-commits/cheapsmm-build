@extends('layouts.admin')
@section('title', 'Customer Tags')
@section('page-title', 'Customer Tags')
@section('content')
<div class="grid md:grid-cols-2 gap-6">
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="font-bold mb-4">Create New Tag</h3>
        <form method="POST" action="{{ route('admin.crm.tag-user') }}">
            @csrf
            <div class="mb-4">
                <label class="block mb-2">Tag Name</label>
                <input type="text" name="tag_name" required class="w-full border rounded px-3 py-2">
            </div>
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded">Create Tag</button>
        </form>
    </div>

    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Existing Tags</h3></div>
        <div class="divide-y">
            @forelse($tags as $tag)
            <div class="p-4 flex justify-between items-center">
                <div>
                    <div class="font-semibold">{{ $tag->name }}</div>
                    <div class="text-sm text-gray-500">{{ $tag->users_count }} users</div>
                </div>
            </div>
            @empty
            <div class="p-8 text-center text-gray-500">No tags created yet</div>
            @endforelse
        </div>
    </div>
</div>
@endsection
