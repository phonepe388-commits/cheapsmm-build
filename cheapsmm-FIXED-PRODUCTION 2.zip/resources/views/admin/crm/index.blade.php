@extends('layouts.admin')
@section('title', 'CRM Dashboard')
@section('page-title', 'Customer Relationship Management')
@section('content')
<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Total Customers</div>
        <div class="text-2xl font-bold">{{ $stats['total_customers'] }}</div>
    </div>
    <div class="bg-green-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Active Customers</div>
        <div class="text-2xl font-bold text-green-600">{{ $stats['active_customers'] }}</div>
    </div>
    <div class="bg-purple-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">High Value (>$1000)</div>
        <div class="text-2xl font-bold text-purple-600">{{ $stats['high_value_customers'] }}</div>
    </div>
    <div class="bg-blue-50 rounded-lg shadow p-6">
        <div class="text-sm text-gray-600">Segments</div>
        <div class="text-2xl font-bold text-blue-600">{{ $stats['segments'] }}</div>
    </div>
</div>

<div class="grid md:grid-cols-2 gap-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Top Customers</h3></div>
        <div class="p-4">
            @foreach($topCustomers as $customer)
            <div class="flex justify-between py-2 border-b">
                <div>
                    <div class="font-semibold">{{ $customer->name }}</div>
                    <div class="text-xs text-gray-500">{{ $customer->email }}</div>
                </div>
                <div class="text-right">
                    <div class="font-bold text-green-600">${{ number_format($customer->orders_sum_charge, 2) }}</div>
                    <a href="{{ route('admin.crm.customer-insights', $customer) }}" class="text-xs text-blue-600">View →</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Recent Customers</h3></div>
        <div class="p-4">
            @foreach($recentCustomers as $customer)
            <div class="flex justify-between py-2 border-b">
                <div>
                    <div class="font-semibold">{{ $customer->name }}</div>
                    <div class="text-xs text-gray-500">{{ $customer->created_at->diffForHumans() }}</div>
                </div>
                <a href="{{ route('admin.crm.customer-insights', $customer) }}" class="text-blue-600 text-sm">View →</a>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
