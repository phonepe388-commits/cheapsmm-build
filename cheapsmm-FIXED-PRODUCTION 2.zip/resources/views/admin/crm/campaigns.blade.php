@extends('layouts.admin')
@section('title', 'Campaigns')
@section('page-title', 'Email Campaigns')
@section('content')
<div class="mb-6">
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" 
            class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
        + Create Campaign
    </button>
</div>

<div class="bg-white rounded-lg shadow">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Segment</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sent</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($campaigns as $campaign)
            <tr>
                <td class="px-6 py-4 font-semibold">{{ $campaign->name }}</td>
                <td class="px-6 py-4">{{ $campaign->segment->name ?? 'N/A' }}</td>
                <td class="px-6 py-4">{{ $campaign->sent_count }}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded text-xs {{ $campaign->status === 'sent' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ ucfirst($campaign->status) }}
                    </span>
                </td>
                <td class="px-6 py-4">
                    @if($campaign->status === 'draft')
                    <form method="POST" action="{{ route('admin.crm.send-campaign', $campaign) }}" class="inline">
                        @csrf
                        <button type="submit" class="text-blue-600 text-sm">Send</button>
                    </form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No campaigns yet</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div id="createModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
    <div class="bg-white rounded-lg p-8 max-w-lg w-full">
        <h3 class="text-xl font-bold mb-4">Create Campaign</h3>
        <form method="POST" action="{{ route('admin.crm.create-campaign') }}">
            @csrf
            <div class="mb-4">
                <label class="block mb-2">Name</label>
                <input type="text" name="name" required class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label class="block mb-2">Subject</label>
                <input type="text" name="subject" required class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label class="block mb-2">Message</label>
                <textarea name="message" rows="4" required class="w-full border rounded px-3 py-2"></textarea>
            </div>
            <div class="mb-4">
                <label class="block mb-2">Segment</label>
                <select name="segment_id" required class="w-full border rounded px-3 py-2">
                    @foreach($segments as $segment)
                    <option value="{{ $segment->id }}">{{ $segment->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Create</button>
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" class="bg-gray-300 px-4 py-2 rounded">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
