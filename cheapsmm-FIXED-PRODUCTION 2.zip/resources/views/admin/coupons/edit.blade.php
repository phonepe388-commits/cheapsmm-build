@extends('layouts.admin')

@section('title', 'Edit Coupon')
@section('page-title', 'Edit Coupon: ' . $coupon->code)

@section('content')
<div class="max-w-3xl">
    <form method="POST" action="{{ route('admin.coupons.update', $coupon) }}">
        @csrf
        @method('PUT')

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Basic Information</h3>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Coupon Code *</label>
                    <input type="text" name="code" required
                        value="{{ old('code', $coupon->code) }}"
                        class="w-full border rounded px-3 py-2 uppercase @error('code') border-red-500 @enderror">
                    @error('code')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Status *</label>
                    <select name="status" required class="w-full border rounded px-3 py-2">
                        <option value="active" {{ $coupon->status === 'active' ? 'selected' : '' }}>Active</option>
                        <option value="inactive" {{ $coupon->status === 'inactive' ? 'selected' : '' }}>Inactive</option>
                    </select>
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Description</label>
                <input type="text" name="description" 
                    value="{{ old('description', $coupon->description) }}"
                    class="w-full border rounded px-3 py-2">
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Discount Settings</h3>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Discount Type *</label>
                    <select name="type" required class="w-full border rounded px-3 py-2">
                        <option value="percentage" {{ $coupon->type === 'percentage' ? 'selected' : '' }}>Percentage (%)</option>
                        <option value="fixed" {{ $coupon->type === 'fixed' ? 'selected' : '' }}>Fixed Amount ($)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Discount Value *</label>
                    <input type="number" name="value" step="0.01" min="0" required
                        value="{{ old('value', $coupon->value) }}"
                        class="w-full border rounded px-3 py-2">
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Minimum Amount ($)</label>
                    <input type="number" name="min_amount" step="0.01" min="0"
                        value="{{ old('min_amount', $coupon->min_amount) }}"
                        class="w-full border rounded px-3 py-2">
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Maximum Discount ($)</label>
                    <input type="number" name="max_discount" step="0.01" min="0"
                        value="{{ old('max_discount', $coupon->max_discount) }}"
                        class="w-full border rounded px-3 py-2">
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Usage Limits</h3>

            <div class="mb-4 bg-blue-50 p-3 rounded text-sm">
                <strong>Current Usage:</strong> {{ $coupon->uses ?? 0 }} times
            </div>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Total Uses</label>
                    <input type="number" name="max_uses" min="1"
                        value="{{ old('max_uses', $coupon->max_uses) }}"
                        class="w-full border rounded px-3 py-2">
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Uses Per User</label>
                    <input type="number" name="max_uses_per_user" min="1"
                        value="{{ old('max_uses_per_user', $coupon->max_uses_per_user) }}"
                        class="w-full border rounded px-3 py-2">
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Expiry</h3>

            <div>
                <label class="block text-sm font-semibold mb-2">Expiration Date</label>
                <input type="datetime-local" name="expires_at"
                    value="{{ old('expires_at', $coupon->expires_at ? $coupon->expires_at->format('Y-m-d\TH:i') : '') }}"
                    class="w-full border rounded px-3 py-2">
            </div>
        </div>

        <div class="flex gap-3">
            <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded font-semibold hover:bg-blue-700">
                Update Coupon
            </button>
            <a href="{{ route('admin.coupons.index') }}" 
               class="bg-gray-200 px-6 py-3 rounded font-semibold hover:bg-gray-300">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection
