@extends('layouts.admin')

@section('title', 'Create Coupon')
@section('page-title', 'Create New Coupon')

@section('content')
<div class="max-w-3xl">
    <form method="POST" action="{{ route('admin.coupons.store') }}">
        @csrf

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Basic Information</h3>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Coupon Code *</label>
                    <div class="flex gap-2">
                        <input type="text" name="code" id="couponCode" required
                            value="{{ old('code') }}"
                            class="flex-1 border rounded px-3 py-2 uppercase @error('code') border-red-500 @enderror">
                        <button type="button" onclick="generateCode()" 
                            class="bg-gray-200 px-4 py-2 rounded hover:bg-gray-300">
                            Generate
                        </button>
                    </div>
                    @error('code')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Status *</label>
                    <select name="status" required class="w-full border rounded px-3 py-2">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Description</label>
                <input type="text" name="description" value="{{ old('description') }}"
                    class="w-full border rounded px-3 py-2" 
                    placeholder="e.g., Summer Sale 2026">
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Discount Settings</h3>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Discount Type *</label>
                    <select name="type" id="discountType" required 
                        class="w-full border rounded px-3 py-2" onchange="updateValueLabel()">
                        <option value="percentage">Percentage (%)</option>
                        <option value="fixed">Fixed Amount ($)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">
                        <span id="valueLabel">Discount Value (%) *</span>
                    </label>
                    <input type="number" name="value" step="0.01" min="0" required
                        value="{{ old('value') }}"
                        class="w-full border rounded px-3 py-2 @error('value') border-red-500 @enderror">
                    @error('value')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Minimum Amount ($)</label>
                    <input type="number" name="min_amount" step="0.01" min="0"
                        value="{{ old('min_amount') }}"
                        class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Minimum purchase amount required</p>
                </div>

                <div id="maxDiscountDiv">
                    <label class="block text-sm font-semibold mb-2">Maximum Discount ($)</label>
                    <input type="number" name="max_discount" step="0.01" min="0"
                        value="{{ old('max_discount') }}"
                        class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Cap for percentage discounts</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Usage Limits</h3>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Total Uses</label>
                    <input type="number" name="max_uses" min="1"
                        value="{{ old('max_uses') }}"
                        class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Leave empty for unlimited</p>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Uses Per User</label>
                    <input type="number" name="max_uses_per_user" min="1"
                        value="{{ old('max_uses_per_user') }}"
                        class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">How many times one user can use</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Expiry</h3>

            <div>
                <label class="block text-sm font-semibold mb-2">Expiration Date</label>
                <input type="datetime-local" name="expires_at"
                    value="{{ old('expires_at') }}"
                    class="w-full border rounded px-3 py-2">
                <p class="text-xs text-gray-500 mt-1">Leave empty for no expiration</p>
            </div>
        </div>

        <div class="flex gap-3">
            <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded font-semibold hover:bg-blue-700">
                Create Coupon
            </button>
            <a href="{{ route('admin.coupons.index') }}" 
               class="bg-gray-200 px-6 py-3 rounded font-semibold hover:bg-gray-300">
                Cancel
            </a>
        </div>
    </form>
</div>

@push('scripts')
<script>
async function generateCode() {
    const response = await fetch('{{ route("admin.coupons.generate") }}');
    const data = await response.json();
    document.getElementById('couponCode').value = data.code;
}

function updateValueLabel() {
    const type = document.getElementById('discountType').value;
    const label = type === 'percentage' ? 'Discount Value (%) *' : 'Discount Value ($) *';
    document.getElementById('valueLabel').textContent = label;
    
    const maxDiscountDiv = document.getElementById('maxDiscountDiv');
    maxDiscountDiv.style.display = type === 'percentage' ? 'block' : 'none';
}

updateValueLabel();
</script>
@endpush
@endsection
