@extends('layouts.admin')

@section('title', 'Coupons')
@section('page-title', 'Coupon Management')

@section('content')
<div class="mb-6">
    <a href="{{ route('admin.coupons.create') }}" 
       class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
        + Create Coupon
    </a>
</div>

@if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        {{ session('success') }}
    </div>
@endif

<div class="bg-white rounded-lg shadow">
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Code</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Value</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Usage</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expires</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @forelse($coupons as $coupon)
                <tr>
                    <td class="px-6 py-4">
                        <span class="font-mono font-bold text-blue-600">{{ $coupon->code }}</span>
                        @if($coupon->description)
                            <div class="text-xs text-gray-500">{{ $coupon->description }}</div>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm">
                            {{ ucfirst($coupon->type) }}
                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm font-semibold">
                            @if($coupon->type === 'percentage')
                                {{ $coupon->value }}%
                                @if($coupon->max_discount)
                                    <span class="text-xs text-gray-500">(max ${{ number_format($coupon->max_discount, 2) }})</span>
                                @endif
                            @else
                                ${{ number_format($coupon->value, 2) }}
                            @endif
                        </span>
                        @if($coupon->min_amount)
                            <div class="text-xs text-gray-500">Min: ${{ number_format($coupon->min_amount, 2) }}</div>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm">
                            {{ $coupon->uses ?? 0 }}
                            @if($coupon->max_uses)
                                / {{ $coupon->max_uses }}
                            @else
                                / ∞
                            @endif
                        </span>
                        @if($coupon->max_uses_per_user)
                            <div class="text-xs text-gray-500">{{ $coupon->max_uses_per_user }} per user</div>
                        @endif
                    </td>
                    <td class="px-6 py-4 text-sm">
                        @if($coupon->expires_at)
                            {{ $coupon->expires_at->format('M d, Y') }}
                            @if($coupon->expires_at->isPast())
                                <span class="text-red-500">(Expired)</span>
                            @endif
                        @else
                            <span class="text-gray-400">No expiry</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        @if($coupon->status === 'active')
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                        @else
                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">Inactive</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex gap-2">
                            <a href="{{ route('admin.coupons.edit', $coupon) }}" 
                               class="text-blue-600 hover:underline text-sm">Edit</a>
                            <form method="POST" action="{{ route('admin.coupons.destroy', $coupon) }}" 
                                  onsubmit="return confirm('Delete this coupon?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline text-sm">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                        <div class="text-4xl mb-2">🎟️</div>
                        No coupons created yet. Create your first coupon!
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($coupons->hasPages())
        <div class="p-4 border-t">
            {{ $coupons->links() }}
        </div>
    @endif
</div>
@endsection
