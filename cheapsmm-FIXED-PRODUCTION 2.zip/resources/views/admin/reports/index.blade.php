@extends('layouts.admin')

@section('title', 'Reports & Export')
@section('page-title', 'Reports & Export')

@section('content')
<div class="grid md:grid-cols-2 gap-6">
    <!-- Summary Report -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-4">📊 Summary Report</h3>
        <p class="text-gray-600 mb-4">Generate comprehensive summary with statistics</p>
        
        <form method="GET" action="{{ route('admin.reports.summary') }}">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Date From</label>
                <input type="date" name="date_from" value="{{ now()->subMonth()->format('Y-m-d') }}" 
                    class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Date To</label>
                <input type="date" name="date_to" value="{{ now()->format('Y-m-d') }}" 
                    class="w-full border rounded px-3 py-2">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    View Report
                </button>
                <button type="submit" name="export" value="csv" 
                    class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    📥 Export CSV
                </button>
            </div>
        </form>
    </div>

    <!-- Export Orders -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-4">📦 Export Orders</h3>
        <p class="text-gray-600 mb-4">Export all orders with filters</p>
        
        <form method="GET" action="{{ route('admin.orders.export') }}">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Status</label>
                <select name="status" class="w-full border rounded px-3 py-2">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="partial">Partial</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Date Range</label>
                <div class="grid grid-cols-2 gap-2">
                    <input type="date" name="date_from" class="border rounded px-3 py-2">
                    <input type="date" name="date_to" class="border rounded px-3 py-2">
                </div>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                📥 Export Orders
            </button>
        </form>
    </div>

    <!-- Export Payments -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-4">💰 Export Payments</h3>
        <p class="text-gray-600 mb-4">Export all payment transactions</p>
        
        <form method="GET" action="{{ route('admin.payments.export') }}">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Status</label>
                <select name="status" class="w-full border rounded px-3 py-2">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                    <option value="failed">Failed</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Date Range</label>
                <div class="grid grid-cols-2 gap-2">
                    <input type="date" name="date_from" class="border rounded px-3 py-2">
                    <input type="date" name="date_to" class="border rounded px-3 py-2">
                </div>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                📥 Export Payments
            </button>
        </form>
    </div>

    <!-- Export Users -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-4">👥 Export Users</h3>
        <p class="text-gray-600 mb-4">Export user database</p>
        
        <form method="GET" action="{{ route('admin.users.export') }}">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Status</label>
                <select name="status" class="w-full border rounded px-3 py-2">
                    <option value="">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="banned">Banned</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Registration Date</label>
                <div class="grid grid-cols-2 gap-2">
                    <input type="date" name="date_from" class="border rounded px-3 py-2">
                    <input type="date" name="date_to" class="border rounded px-3 py-2">
                </div>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                📥 Export Users
            </button>
        </form>
    </div>
</div>

<div class="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
    <h4 class="font-semibold mb-2">ℹ️ Export Information</h4>
    <ul class="text-sm space-y-1">
        <li>• All exports are in CSV format</li>
        <li>• Files are generated on-demand (not stored)</li>
        <li>• Use filters to limit export size</li>
        <li>• Large exports may take a few seconds</li>
    </ul>
</div>
@endsection
