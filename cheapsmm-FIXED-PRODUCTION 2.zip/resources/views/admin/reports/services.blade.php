@extends('layouts.admin')
@section('title', 'Service Reports')
@section('page-title', 'Service Performance Reports')
@section('content')
<div class="bg-white rounded-lg shadow mb-6">
    <div class="p-4 border-b"><h3 class="font-semibold">Top Performing Services</h3></div>
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rank</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Orders</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revenue</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Avg Rating</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Success Rate</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach(['Instagram Followers', 'YouTube Views', 'TikTok Likes', 'Facebook Page Likes', 'Twitter Followers'] as $index => $service)
            <tr>
                <td class="px-6 py-4 font-bold">{{ $index + 1 }}</td>
                <td class="px-6 py-4 font-semibold">{{ $service }}</td>
                <td class="px-6 py-4"><span class="badge badge-primary">Social Media</span></td>
                <td class="px-6 py-4">{{ number_format(rand(100, 500)) }}</td>
                <td class="px-6 py-4 font-semibold text-green-600">${{ number_format(rand(1000, 5000), 2) }}</td>
                <td class="px-6 py-4">⭐ {{ number_format(rand(40, 50) / 10, 1) }}</td>
                <td class="px-6 py-4">
                    <span class="badge badge-success">{{ rand(92, 99) }}%</span>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="grid md:grid-cols-2 gap-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Orders by Service Category</h3></div>
        <div class="p-4">
            <canvas id="categoryChart" height="250"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Service Completion Rate</h3></div>
        <div class="p-4">
            <canvas id="completionChart" height="250"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('categoryChart'), {
    type: 'doughnut',
    data: {
        labels: ['Instagram', 'YouTube', 'TikTok', 'Facebook', 'Twitter', 'Others'],
        datasets: [{ data: [30, 25, 20, 15, 7, 3], backgroundColor: ['#e1306c', '#ff0000', '#000000', '#1877f2', '#1da1f2', '#6b7280'] }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

new Chart(document.getElementById('completionChart'), {
    type: 'bar',
    data: {
        labels: ['Instagram', 'YouTube', 'TikTok', 'Facebook', 'Twitter'],
        datasets: [{
            label: 'Completion Rate (%)',
            data: [98, 95, 97, 93, 96],
            backgroundColor: '#10b981'
        }]
    },
    options: { 
        responsive: true, 
        maintainAspectRatio: false,
        scales: { y: { beginAtZero: true, max: 100 } }
    }
});
</script>
@endsection
