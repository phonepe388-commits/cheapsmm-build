@extends('layouts.admin')
@section('title', 'Financial Reports')
@section('page-title', 'Financial Reports & Analytics')
@section('content')
<div class="grid md:grid-cols-3 gap-6 mb-6">
    <div class="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg shadow p-6">
        <div class="text-sm opacity-90 mb-1">Total Revenue</div>
        <div class="text-4xl font-bold">${{ number_format(45000, 2) }}</div>
        <div class="text-sm mt-2">↑ +18.2% vs last month</div>
    </div>
    <div class="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg shadow p-6">
        <div class="text-sm opacity-90 mb-1">Net Profit</div>
        <div class="text-4xl font-bold">${{ number_format(32500, 2) }}</div>
        <div class="text-sm mt-2">Profit Margin: 72%</div>
    </div>
    <div class="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg shadow p-6">
        <div class="text-sm opacity-90 mb-1">Pending Withdrawals</div>
        <div class="text-4xl font-bold">${{ number_format(2300, 2) }}</div>
        <div class="text-sm mt-2">12 requests pending</div>
    </div>
</div>

<div class="grid md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Revenue by Payment Method</h3></div>
        <div class="p-4">
            <canvas id="paymentMethodChart" height="250"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">Monthly Revenue Trend</h3></div>
        <div class="p-4">
            <canvas id="monthlyRevenueChart" height="250"></canvas>
        </div>
    </div>
</div>

<div class="bg-white rounded-lg shadow">
    <div class="p-4 border-b flex justify-between items-center">
        <h3 class="font-semibold">Recent Transactions</h3>
        <button class="btn btn-primary btn-sm">Export Report</button>
    </div>
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @for($i = 0; $i < 10; $i++)
            <tr>
                <td class="px-6 py-4 text-sm">{{ now()->subDays($i)->format('Y-m-d H:i') }}</td>
                <td class="px-6 py-4">User {{ $i + 1 }}</td>
                <td class="px-6 py-4"><span class="badge badge-primary">Payment</span></td>
                <td class="px-6 py-4 font-semibold">${{ number_format(rand(10, 500), 2) }}</td>
                <td class="px-6 py-4">{{ ['Stripe', 'PayPal', 'Crypto'][rand(0, 2)] }}</td>
                <td class="px-6 py-4"><span class="badge badge-success">Completed</span></td>
            </tr>
            @endfor
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('paymentMethodChart'), {
    type: 'pie',
    data: {
        labels: ['Stripe', 'PayPal', 'Crypto', 'Razorpay', 'Other'],
        datasets: [{
            data: [35, 25, 20, 15, 5],
            backgroundColor: ['#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', '#6b7280']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

new Chart(document.getElementById('monthlyRevenueChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Revenue',
            data: [35000, 38000, 42000, 39000, 43000, 45000],
            backgroundColor: '#3b82f6'
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>
@endsection
