@extends('layouts.admin')
@section('title', 'User Analytics')
@section('page-title', 'User Analytics & Reports')
@section('content')
<div class="grid md:grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Total Users</div>
        <div class="text-3xl font-bold">1,234</div>
        <div class="text-xs text-green-600 mt-1">↑ +23 this week</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Active Users</div>
        <div class="text-3xl font-bold">856</div>
        <div class="text-xs text-gray-600 mt-1">69% of total</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Avg Lifetime Value</div>
        <div class="text-3xl font-bold">$245</div>
        <div class="text-xs text-green-600 mt-1">↑ +5.2%</div>
    </div>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-sm text-gray-600 mb-1">Churn Rate</div>
        <div class="text-3xl font-bold">3.2%</div>
        <div class="text-xs text-red-600 mt-1">↑ +0.4%</div>
    </div>
</div>

<div class="grid md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">User Growth</h3></div>
        <div class="p-4">
            <canvas id="userGrowthChart" height="250"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b"><h3 class="font-semibold">User Distribution by Country</h3></div>
        <div class="p-4">
            <div class="space-y-3">
                @foreach(['United States' => 45, 'India' => 22, 'United Kingdom' => 12, 'Canada' => 8, 'Australia' => 6, 'Others' => 7] as $country => $percent)
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span>{{ $country }}</span>
                        <span class="font-semibold">{{ $percent }}%</span>
                    </div>
                    <div class="bg-gray-200 rounded-full h-2">
                        <div class="bg-blue-600 h-2 rounded-full" style="width: {{ $percent }}%"></div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('userGrowthChart'), {
    type: 'line',
    data: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        datasets: [
            {
                label: 'New Users',
                data: [23, 31, 28, 35],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                fill: true
            },
            {
                label: 'Churned Users',
                data: [5, 7, 6, 4],
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                fill: true
            }
        ]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>
@endsection
