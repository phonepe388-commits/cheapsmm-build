@extends('layouts.admin')
@section('title', 'Webhooks')
@section('page-title', 'Webhook Management')
@section('content')
<div class="mb-6">
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="bg-blue-600 text-white px-6 py-2 rounded">+ Create Webhook</button>
</div>

<div class="bg-white rounded-lg shadow">
    <table class="min-w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">URL</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Event</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse($webhooks ?? [] as $webhook)
            <tr>
                <td class="px-6 py-4 font-semibold">{{ $webhook->name }}</td>
                <td class="px-6 py-4 text-sm font-mono">{{ Str::limit($webhook->url, 40) }}</td>
                <td class="px-6 py-4"><span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">{{ $webhook->event }}</span></td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded text-xs {{ $webhook->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ ucfirst($webhook->status) }}
                    </span>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" class="px-6 py-8 text-center text-gray-500">No webhooks configured</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
