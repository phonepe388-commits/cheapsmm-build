@extends('emails.layouts.app')
@section('content')
<h2>✅ Order Completed!</h2>
<p>Hello {{ $order->user->name }},</p>
<p>Great news! Your order has been completed successfully.</p>

<div class="highlight">
    <strong>Order Details:</strong><br>
    Order ID: #{{ $order->id }}<br>
    Service: {{ $order->service->name }}<br>
    Quantity: {{ number_format($order->quantity) }}<br>
    Link: {{ $order->link }}<br>
    Completed: {{ $order->completed_at->format('M d, Y H:i') }}
</div>

<p>Thank you for using our service!</p>

<a href="{{ route('user.orders.show', $order) }}" class="button">View Order</a>
@endsection
