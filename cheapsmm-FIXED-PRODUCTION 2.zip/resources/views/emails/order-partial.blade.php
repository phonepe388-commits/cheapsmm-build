@extends('emails.layouts.app')
@section('content')
<h2>⚠️ Order Partially Completed</h2>
<p>Hello {{ $order->user->name }},</p>
<p>Your order has been partially completed.</p>

<div class="highlight">
    <strong>Order Details:</strong><br>
    Order ID: #{{ $order->id }}<br>
    Service: {{ $order->service->name }}<br>
    Ordered: {{ number_format($order->quantity) }}<br>
    Completed: {{ number_format($order->quantity - $order->remain) }}<br>
    Remaining: {{ number_format($order->remain) }}<br>
    Link: {{ $order->link }}
</div>

<p>The remaining quantity could not be delivered due to the provider's limitations.</p>
<p>You have been refunded for the undelivered portion.</p>

@if($order->service->refill_enabled)
<p><strong>Refill Available:</strong> You can request a refill if the count drops.</p>
@endif

<a href="{{ route('user.orders.show', $order) }}" class="button">View Order</a>
@endsection
