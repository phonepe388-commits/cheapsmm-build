@extends('emails.layouts.app')
@section('content')
<h2>📊 Your Weekly Summary</h2>
<p>Hello {{ $user->name }},</p>
<p>Here's your activity summary for the past week:</p>

<table>
    <tr>
        <th>Metric</th>
        <th>Count</th>
        <th>Amount</th>
    </tr>
    <tr>
        <td>Orders Placed</td>
        <td>{{ $stats['orders_count'] }}</td>
        <td>${{ number_format($stats['orders_spent'], 2) }}</td>
    </tr>
    <tr>
        <td>Payments Made</td>
        <td>{{ $stats['payments_count'] }}</td>
        <td>${{ number_format($stats['payments_amount'], 2) }}</td>
    </tr>
    <tr>
        <td>Referral Earnings</td>
        <td>{{ $stats['referrals_count'] }}</td>
        <td>${{ number_format($stats['referrals_earned'], 2) }}</td>
    </tr>
</table>

<div class="highlight">
    <strong>Current Balance:</strong> ${{ number_format($user->balance, 2) }}
</div>

<p>Keep up the great work!</p>
@endsection
