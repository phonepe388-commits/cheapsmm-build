@extends('emails.layouts.app')
@section('content')
<h2>⚠️ Account Suspended</h2>
<p>Hello {{ $user->name }},</p>
<p>Your account has been temporarily suspended.</p>

<div class="highlight">
    <strong>Suspension Details:</strong><br>
    Reason: {{ $reason }}<br>
    Date: {{ now()->format('M d, Y H:i') }}<br>
    @if($until)
    Suspended Until: {{ $until->format('M d, Y') }}
    @endif
</div>

<p><strong>What this means:</strong></p>
<ul>
    <li>You cannot place new orders</li>
    <li>You cannot add funds</li>
    <li>Existing orders will continue processing</li>
</ul>

<p>If you believe this is an error, please contact our support team immediately.</p>

<a href="{{ config('app.url') }}/contact" class="button">Contact Support</a>
@endsection
