<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to {{ config('app.name') }}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 28px; }
        .content { padding: 40px 30px; }
        .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .button:hover { background: #5568d3; }
        .features { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .features ul { list-style: none; padding: 0; }
        .features li { padding: 8px 0; padding-left: 25px; position: relative; }
        .features li:before { content: "✓"; position: absolute; left: 0; color: #667eea; font-weight: bold; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
        .social { margin: 15px 0; }
        .social a { display: inline-block; margin: 0 10px; color: #667eea; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎉 Welcome to {{ config('app.name') }}!</h1>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}! 👋</h2>
            
            <p>Thank you for joining {{ config('app.name') }} - the fastest and most reliable SMM panel platform!</p>
            
            <p>Your account has been successfully created and you're now ready to start boosting your social media presence.</p>
            
            <div style="text-align: center;">
                <a href="{{ $dashboardUrl }}" class="button">Go to Dashboard</a>
            </div>
            
            <div class="features">
                <h3>What you can do now:</h3>
                <ul>
                    <li>Browse our wide range of social media services</li>
                    <li>Place your first order in seconds</li>
                    <li>Add funds using multiple payment methods</li>
                    <li>Track all your orders in real-time</li>
                    <li>Get 24/7 support from our team</li>
                </ul>
            </div>
            
            <h3>Getting Started:</h3>
            <p><strong>Step 1:</strong> Add funds to your account<br>
            <strong>Step 2:</strong> Browse our services<br>
            <strong>Step 3:</strong> Place your first order<br>
            <strong>Step 4:</strong> Watch your social media grow!</p>
            
            <p>If you have any questions, our support team is here to help. Just create a support ticket from your dashboard.</p>
            
            <p>Thank you for choosing {{ config('app.name') }}!</p>
            
            <p>Best regards,<br>
            <strong>The {{ config('app.name') }} Team</strong></p>
        </div>
        
        <div class="footer">
            <p>This email was sent to you because you registered at {{ config('app.name') }}</p>
            <p>If you didn't create this account, please ignore this email.</p>
            <div class="social">
                <a href="#">Facebook</a> | 
                <a href="#">Twitter</a> | 
                <a href="#">Instagram</a>
            </div>
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
            <p><small>Support: {{ $supportEmail }}</small></p>
        </div>
    </div>
</body>
</html>
