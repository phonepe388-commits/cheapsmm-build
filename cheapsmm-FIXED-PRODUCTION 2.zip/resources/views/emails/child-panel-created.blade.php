@extends('emails.layouts.app')
@section('content')
<h2>🎉 Child Panel Created!</h2>
<p>Hello {{ $user->name }},</p>
<p>Your child panel has been successfully created and is ready to use!</p>

<div class="highlight">
    <strong>Panel Details:</strong><br>
    Panel Name: {{ $panel->name }}<br>
    URL: <a href="{{ $panel->getUrl() }}">{{ $panel->getUrl() }}</a><br>
    Initial Balance: ${{ number_format($panel->balance, 2) }}<br>
    Markup: {{ $panel->markup_percentage }}%
</div>

<p><strong>What's Next?</strong></p>
<ul>
    <li>Add funds to your panel</li>
    <li>Customize service pricing</li>
    <li>Add your branding (logo, colors)</li>
    <li>Start adding users</li>
</ul>

<a href="{{ route('user.child-panels.show', $panel) }}" class="button">Manage Panel</a>
@endsection
