<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; }
        .alert { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; margin: 20px 0; text-align: center; }
        .balance { font-size: 36px; font-weight: bold; color: #d97706; margin: 10px 0; }
        .button { display: inline-block; padding: 12px 30px; background: #10b981; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚠️ Low Balance Alert</h1>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}!</h2>
            
            <p>This is a friendly reminder that your account balance is running low.</p>
            
            <div class="alert">
                <p>Current Balance:</p>
                <div class="balance">${{ number_format($currentBalance, 2) }}</div>
            </div>
            
            <p>To continue placing orders without interruption, we recommend adding funds to your account.</p>
            
            <div style="text-align: center;">
                <a href="{{ $addFundsUrl }}" class="button">Add Funds Now</a>
            </div>
            
            <p>Thank you for using {{ config('app.name') }}!</p>
            
            <p>Best regards,<br>
            <strong>{{ config('app.name') }} Team</strong></p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
