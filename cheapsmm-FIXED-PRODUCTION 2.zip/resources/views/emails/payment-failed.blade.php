@extends('emails.layouts.app')
@section('content')
<h2>Payment Failed</h2>
<p>Hello {{ $user->name }},</p>
<p>Unfortunately, your payment could not be processed.</p>

<div class="highlight">
    <strong>Payment Details:</strong><br>
    Amount: ${{ number_format($payment->amount, 2) }}<br>
    Method: {{ $payment->paymentMethod->name ?? 'Unknown' }}<br>
    Date: {{ $payment->created_at->format('M d, Y H:i') }}
</div>

<p><strong>Possible reasons:</strong></p>
<ul>
    <li>Insufficient funds</li>
    <li>Card declined by bank</li>
    <li>Invalid payment details</li>
    <li>Payment gateway error</li>
</ul>

<p>Please try again or contact support if the problem persists.</p>

<a href="{{ route('user.payments.add-funds') }}" class="button">Try Again</a>
@endsection
