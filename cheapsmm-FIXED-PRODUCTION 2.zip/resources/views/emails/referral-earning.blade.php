@extends('emails.layouts.app')
@section('content')
<h2>💰 New Referral Earning!</h2>
<p>Hello {{ $user->name }},</p>
<p>You've earned a commission from your referral!</p>

<div class="highlight">
    <strong>Earning Details:</strong><br>
    Referred User: {{ $referredUser->name }}<br>
    Order Amount: ${{ number_format($orderAmount, 2) }}<br>
    Your Commission ({{ $commissionRate }}%): <strong>${{ number_format($commission, 2) }}</strong><br>
    Total Earnings: ${{ number_format($user->referralEarnings()->sum('amount'), 2) }}
</div>

<p>Keep sharing your referral link to earn more!</p>

<p><strong>Your Referral Link:</strong></p>
<div class="highlight">
    <code>{{ config('app.url') }}/register?ref={{ $user->referral_code }}</code>
</div>

<a href="{{ route('user.referrals.index') }}" class="button">View Referrals</a>
@endsection
