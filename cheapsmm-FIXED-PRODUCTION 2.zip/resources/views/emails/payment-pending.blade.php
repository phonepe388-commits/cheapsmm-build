@extends('emails.layouts.app')
@section('content')
<h2>Payment Pending Verification</h2>
<p>Hello {{ $user->name }},</p>
<p>We have received your payment and it is currently pending verification.</p>

<div class="highlight">
    <strong>Payment Details:</strong><br>
    Amount: <strong>${{ number_format($payment->amount, 2) }}</strong><br>
    Method: {{ $payment->paymentMethod->name ?? 'Manual' }}<br>
    Date: {{ $payment->created_at->format('M d, Y H:i') }}
</div>

<p>Your payment will be verified within 24 hours. You will receive a confirmation email once approved.</p>

@if($payment->payment_method_id === null || $payment->paymentMethod->code === 'bank_transfer')
<p><strong>Note:</strong> For manual payments, please ensure you have uploaded the payment proof in your account.</p>
@endif

<p>Thank you for your patience!</p>
@endsection
