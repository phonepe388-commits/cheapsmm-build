@extends('emails.layouts.app')
@section('content')
<h2>🔄 Refill Completed</h2>
<p>Hello {{ $order->user->name }},</p>
<p>Your refill request has been completed successfully!</p>

<div class="highlight">
    <strong>Refill Details:</strong><br>
    Order ID: #{{ $order->id }}<br>
    Service: {{ $order->service->name }}<br>
    Original Quantity: {{ number_format($order->quantity) }}<br>
    Link: {{ $order->link }}<br>
    Refilled: {{ now()->format('M d, Y H:i') }}
</div>

<p>Your order has been refilled at no additional cost as per our service guarantee.</p>

<a href="{{ route('user.orders.show', $order) }}" class="button">View Order</a>
@endsection
