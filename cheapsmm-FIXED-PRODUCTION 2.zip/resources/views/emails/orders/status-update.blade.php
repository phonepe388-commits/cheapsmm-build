<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; }
        .status-change { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; text-align: center; }
        .status { display: inline-block; padding: 10px 20px; border-radius: 5px; margin: 10px; font-weight: bold; }
        .status-old { background: #e5e7eb; color: #6b7280; }
        .status-new { background: #10b981; color: white; }
        .button { display: inline-block; padding: 12px 30px; background: #8b5cf6; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Order Status Updated</h1>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}!</h2>
            
            <p>The status of your order #{{ $orderNumber }} has been updated.</p>
            
            <p><strong>Service:</strong> {{ $serviceName }}</p>
            
            <div class="status-change">
                <div class="status status-old">{{ $oldStatus }}</div>
                <div style="display: inline-block; margin: 0 10px;">→</div>
                <div class="status status-new">{{ $newStatus }}</div>
            </div>
            
            <p>You can view the full details of your order by clicking the button below.</p>
            
            <div style="text-align: center;">
                <a href="{{ $orderUrl }}" class="button">View Order Details</a>
            </div>
            
            <p>Thank you for choosing {{ config('app.name') }}!</p>
            
            <p>Best regards,<br>
            <strong>{{ config('app.name') }} Team</strong></p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
