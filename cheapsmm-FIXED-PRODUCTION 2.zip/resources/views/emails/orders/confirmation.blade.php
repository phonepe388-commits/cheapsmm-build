<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; }
        .order-details { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .order-details table { width: 100%; }
        .order-details td { padding: 8px 0; }
        .order-details td:first-child { font-weight: bold; color: #666; }
        .button { display: inline-block; padding: 12px 30px; background: #10b981; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✅ Order Confirmed!</h1>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}!</h2>
            
            <p>Your order has been received and is being processed.</p>
            
            <div class="order-details">
                <h3>Order Details:</h3>
                <table>
                    <tr>
                        <td>Order Number:</td>
                        <td>#{{ $orderNumber }}</td>
                    </tr>
                    <tr>
                        <td>Service:</td>
                        <td>{{ $serviceName }}</td>
                    </tr>
                    <tr>
                        <td>Quantity:</td>
                        <td>{{ number_format($quantity) }}</td>
                    </tr>
                    <tr>
                        <td>Link:</td>
                        <td>{{ $link }}</td>
                    </tr>
                    <tr>
                        <td>Status:</td>
                        <td><strong>{{ ucfirst($status) }}</strong></td>
                    </tr>
                    <tr>
                        <td>Charge:</td>
                        <td><strong>${{ number_format($charge, 2) }}</strong></td>
                    </tr>
                </table>
            </div>
            
            <p>You can track your order status anytime from your dashboard.</p>
            
            <div style="text-align: center;">
                <a href="{{ $orderUrl }}" class="button">View Order</a>
            </div>
            
            <p>Thank you for your order!</p>
            
            <p>Best regards,<br>
            <strong>{{ config('app.name') }} Team</strong></p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
