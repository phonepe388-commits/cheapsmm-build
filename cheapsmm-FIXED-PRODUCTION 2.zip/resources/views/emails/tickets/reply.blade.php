<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; }
        .ticket-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .message { background: #fff; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
        .button { display: inline-block; padding: 12px 30px; background: #f59e0b; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💬 New Reply to Your Ticket</h1>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}!</h2>
            
            <p><strong>{{ $senderName }}</strong> replied to your support ticket.</p>
            
            <div class="ticket-info">
                <strong>Ticket #{{ $ticketId }}:</strong> {{ $ticketSubject }}
            </div>
            
            <div class="message">
                <h4>Message:</h4>
                {!! nl2br(e($messageContent)) !!}
            </div>
            
            <div style="text-align: center;">
                <a href="{{ $ticketUrl }}" class="button">View Ticket & Reply</a>
            </div>
            
            <p>Thank you for contacting our support team!</p>
            
            <p>Best regards,<br>
            <strong>{{ config('app.name') }} Support Team</strong></p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
