@extends('emails.layouts.app')
@section('content')
<h2>🔑 API Key Generated</h2>
<p>Hello {{ $user->name }},</p>
<p>Your API key has been successfully generated.</p>

<div class="highlight">
    <strong>API Key:</strong> <code>{{ $apiKey }}</code>
</div>

<p><strong>⚠️ Important Security Notice:</strong></p>
<ul>
    <li>Keep your API key secret and secure</li>
    <li>Never share it publicly or commit to version control</li>
    <li>Regenerate immediately if compromised</li>
    <li>Use it only for authorized applications</li>
</ul>

<p><strong>Rate Limit:</strong> 1000 requests per hour</p>

<a href="{{ config('app.url') }}/api/documentation" class="button">View API Documentation</a>
@endsection
