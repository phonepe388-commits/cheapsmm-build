<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .amount { font-size: 48px; font-weight: bold; margin: 20px 0; }
        .content { padding: 30px; }
        .payment-details { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .payment-details table { width: 100%; }
        .payment-details td { padding: 8px 0; }
        .payment-details td:first-child { font-weight: bold; color: #666; }
        .button { display: inline-block; padding: 12px 30px; background: #3b82f6; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💰 Payment Successful!</h1>
            <div class="amount">${{ number_format($amount, 2) }}</div>
        </div>
        
        <div class="content">
            <h2>Hello {{ $userName }}!</h2>
            
            <p>Your payment has been processed successfully. The funds have been added to your account.</p>
            
            <div class="payment-details">
                <h3>Payment Details:</h3>
                <table>
                    <tr>
                        <td>Amount:</td>
                        <td><strong>${{ number_format($amount, 2) }}</strong></td>
                    </tr>
                    <tr>
                        <td>Transaction ID:</td>
                        <td>{{ $transactionId }}</td>
                    </tr>
                    <tr>
                        <td>Payment Method:</td>
                        <td>{{ $paymentMethod }}</td>
                    </tr>
                    <tr>
                        <td>Date:</td>
                        <td>{{ $date }}</td>
                    </tr>
                    <tr>
                        <td>New Balance:</td>
                        <td><strong style="color: #10b981;">${{ number_format($newBalance, 2) }}</strong></td>
                    </tr>
                </table>
            </div>
            
            <p>Your funds are now available and you can start placing orders!</p>
            
            <div style="text-align: center;">
                <a href="{{ route('user.orders.create') }}" class="button">Place New Order</a>
            </div>
            
            <p>Thank you for choosing {{ config('app.name') }}!</p>
            
            <p>Best regards,<br>
            <strong>{{ config('app.name') }} Team</strong></p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
