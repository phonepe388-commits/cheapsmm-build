@extends('layouts.app')
@section('title', 'Login')
@section('content')
<div class="max-w-md mx-auto bg-white rounded-lg shadow p-8">
    <h2 class="text-2xl font-bold mb-6">Login</h2>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Email</label>
            <input type="email" name="email" required class="w-full border rounded px-3 py-2" value="{{ old('email') }}">
            @error('email')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 mb-2">Password</label>
            <input type="password" name="password" required class="w-full border rounded px-3 py-2">
            @error('password')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
            Login
        </button>
        <div class="mt-4 text-center">
            <a href="{{ route('register') }}" class="text-blue-600">Don't have an account? Register</a>
        </div>
    </form>
</div>
@endsection
