@extends('layouts.app')
@section('title', 'Register')
@section('content')
<div class="max-w-md mx-auto bg-white rounded-lg shadow p-8">
    <h2 class="text-2xl font-bold mb-6">Register</h2>
    <form method="POST" action="{{ route('register') }}">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Name</label>
            <input type="text" name="name" required class="w-full border rounded px-3 py-2" value="{{ old('name') }}">
            @error('name')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Email</label>
            <input type="email" name="email" required class="w-full border rounded px-3 py-2" value="{{ old('email') }}">
            @error('email')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Password</label>
            <input type="password" name="password" required class="w-full border rounded px-3 py-2">
            @error('password')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 mb-2">Confirm Password</label>
            <input type="password" name="password_confirmation" required class="w-full border rounded px-3 py-2">
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
            Register
        </button>
        <div class="mt-4 text-center">
            <a href="{{ route('login') }}" class="text-blue-600">Already have an account? Login</a>
        </div>
    </form>
</div>
@endsection
