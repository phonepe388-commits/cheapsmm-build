@extends('layouts.app')

@section('title', 'API Documentation')

@section('content')
<div class="max-w-6xl mx-auto px-4">
    <div class="mb-6">
        <h1 class="text-3xl font-bold">API Documentation</h1>
        <p class="text-gray-600">Integrate our SMM services into your application</p>
    </div>

    <!-- API Keys Section -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">🔑 Your API Key</h2>
        
        @if($apiKey)
            <div class="bg-gray-50 p-4 rounded mb-4">
                <label class="block text-sm font-semibold mb-2">API Key:</label>
                <div class="flex gap-2">
                    <input type="text" value="{{ $apiKey->api_key }}" readonly 
                        class="flex-1 font-mono text-sm border rounded px-3 py-2">
                    <button onclick="copyToClipboard('{{ $apiKey->api_key }}')" 
                        class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                        Copy
                    </button>
                </div>
            </div>
            <div class="text-sm text-gray-600">
                <p>Rate Limit: {{ $apiKey->rate_limit ?? 1000 }} requests/hour</p>
                <p>Total Requests: {{ number_format($apiKey->requests_count ?? 0) }}</p>
                <p>Last Used: {{ $apiKey->last_used_at ? $apiKey->last_used_at->diffForHumans() : 'Never' }}</p>
            </div>
        @else
            <form method="POST" action="{{ route('user.api.generate') }}">
                @csrf
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                    Generate API Key
                </button>
            </form>
        @endif
    </div>

    <!-- Base URL -->
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <h3 class="font-semibold mb-2">Base URL</h3>
        <code class="text-sm">{{ url('/api/v2') }}</code>
    </div>

    <!-- Quick Start -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">🚀 Quick Start</h2>
        <div class="bg-gray-900 text-gray-100 p-4 rounded text-sm">
<pre>curl -X GET "{{ url('/api/v2/balance') }}" \
     -H "X-API-Key: your_api_key_here"</pre>
        </div>
    </div>

    <!-- Authentication -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">🔐 Authentication</h2>
        <p class="mb-4">Include your API key in every request:</p>
        
        <div class="space-y-2">
            <div class="bg-gray-900 text-gray-100 p-4 rounded">
                <code class="text-sm">X-API-Key: your_api_key_here</code>
            </div>
            <p class="text-sm text-gray-600">or as query parameter: <code>?api_key=your_api_key_here</code></p>
        </div>
    </div>

    <!-- API Endpoints -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">📋 API Endpoints</h2>
        
        <div class="space-y-6">
            <!-- Balance -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-bold">GET</span>
                    <code class="text-sm">/api/v2/balance</code>
                </div>
                <p class="text-sm text-gray-600">Get account balance</p>
            </div>

            <!-- Services -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-bold">GET</span>
                    <code class="text-sm">/api/v2/services</code>
                </div>
                <p class="text-sm text-gray-600">List all services</p>
            </div>

            <!-- Add Order -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold">POST</span>
                    <code class="text-sm">/api/v2/add</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">Create new order</p>
                <div class="text-xs text-gray-500">
                    Params: service, link, quantity, [runs], [interval]
                </div>
            </div>

            <!-- Order Status -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold">POST</span>
                    <code class="text-sm">/api/v2/status</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">Check order status</p>
                <div class="text-xs text-gray-500">
                    Params: order OR orders (comma-separated)
                </div>
            </div>

            <!-- Multi Order -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold">POST</span>
                    <code class="text-sm">/api/v2/add-multi</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">Create multiple orders (max 100)</p>
                <div class="text-xs text-gray-500">
                    Params: orders (array)
                </div>
            </div>

            <!-- Cancel -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold">POST</span>
                    <code class="text-sm">/api/v2/cancel</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">Cancel orders</p>
                <div class="text-xs text-gray-500">
                    Params: orders (comma-separated)
                </div>
            </div>

            <!-- Refill -->
            <div class="border-b pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold">POST</span>
                    <code class="text-sm">/api/v2/refill</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">Request refill</p>
                <div class="text-xs text-gray-500">
                    Params: order
                </div>
            </div>

            <!-- Get Orders -->
            <div class="pb-4">
                <div class="flex items-center gap-2 mb-2">
                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-bold">GET</span>
                    <code class="text-sm">/api/v2/orders</code>
                </div>
                <p class="text-sm text-gray-600 mb-2">List your orders</p>
                <div class="text-xs text-gray-500">
                    Query params: status, limit
                </div>
            </div>
        </div>
    </div>

    <!-- Error Codes -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold mb-4">❌ Error Codes</h2>
        <div class="grid md:grid-cols-2 gap-2 text-sm">
            <div><code class="text-red-600">AUTH_REQUIRED</code> - Missing API key</div>
            <div><code class="text-red-600">INVALID_KEY</code> - Invalid/inactive key</div>
            <div><code class="text-red-600">RATE_LIMIT</code> - Too many requests</div>
            <div><code class="text-red-600">INSUFFICIENT_BALANCE</code> - Low balance</div>
            <div><code class="text-red-600">ORDER_NOT_FOUND</code> - Order doesn't exist</div>
            <div><code class="text-red-600">MIN_QUANTITY</code> - Below minimum</div>
            <div><code class="text-red-600">MAX_QUANTITY</code> - Above maximum</div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Copied to clipboard!');
    });
}
</script>
@endpush
@endsection
