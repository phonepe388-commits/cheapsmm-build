@extends('layouts.app')

@section('title', 'Mass Order')

@section('content')
<div class="max-w-6xl mx-auto px-4">
    <div class="mb-6 flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold">Mass Order</h1>
            <p class="text-gray-600">Submit multiple orders at once</p>
        </div>
        <div class="text-sm text-gray-600">
            Balance: <strong class="text-green-600">{{ price(auth()->user()->balance) }}</strong>
        </div>
    </div>

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(session('parsing_errors'))
        <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
            <h3 class="font-semibold mb-2">Parsing Errors:</h3>
            <ul class="text-sm">
                @foreach(session('parsing_errors') as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white rounded-lg shadow">
        <!-- Tabs -->
        <div class="border-b">
            <div class="flex">
                <button onclick="switchTab('text')" id="tab-text"
                    class="px-6 py-3 font-semibold border-b-2 border-blue-600 text-blue-600">
                    Text Input
                </button>
                <button onclick="switchTab('csv')" id="tab-csv"
                    class="px-6 py-3 font-semibold text-gray-600 hover:text-blue-600">
                    CSV Upload
                </button>
            </div>
        </div>

        <div class="p-6">
            <form method="POST" action="{{ route('user.orders.mass.validate') }}" enctype="multipart/form-data">
                @csrf

                <!-- Text Input Tab -->
                <div id="content-text">
                    <input type="hidden" name="input_type" value="text">

                    <div class="mb-4">
                        <div class="flex justify-between mb-2">
                            <label class="block text-gray-700 font-semibold">
                                Enter Orders (One per line)
                            </label>
                            <a href="{{ route('user.orders.mass.template', ['format' => 'text']) }}" 
                               class="text-blue-600 hover:underline text-sm">
                                📥 Download Template
                            </a>
                        </div>
                        
                        <div class="bg-gray-50 p-3 rounded mb-2 text-sm">
                            <strong>Format:</strong> service_id|link|quantity<br>
                            <strong>Example:</strong> 1|https://instagram.com/username|1000
                        </div>

                        <textarea name="text_input" rows="15" 
                            class="w-full border rounded px-3 py-2 font-mono text-sm"
                            placeholder="{{ $textTemplate }}">{{ old('text_input') }}</textarea>
                        <p class="text-sm text-gray-600 mt-1">
                            Lines starting with # or // will be ignored (comments)
                        </p>
                    </div>
                </div>

                <!-- CSV Upload Tab -->
                <div id="content-csv" class="hidden">
                    <input type="hidden" name="input_type" value="csv" disabled>

                    <div class="mb-4">
                        <div class="flex justify-between mb-2">
                            <label class="block text-gray-700 font-semibold">
                                Upload CSV File
                            </label>
                            <a href="{{ route('user.orders.mass.template', ['format' => 'csv']) }}" 
                               class="text-blue-600 hover:underline text-sm">
                                📥 Download CSV Template
                            </a>
                        </div>

                        <div class="bg-gray-50 p-4 rounded mb-3">
                            <h4 class="font-semibold mb-2">CSV Format:</h4>
                            <table class="text-sm">
                                <thead>
                                    <tr class="border-b">
                                        <th class="text-left pr-4 py-1">service_id</th>
                                        <th class="text-left pr-4 py-1">link</th>
                                        <th class="text-left py-1">quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="pr-4">1</td>
                                        <td class="pr-4">https://instagram.com/username</td>
                                        <td>1000</td>
                                    </tr>
                                    <tr>
                                        <td class="pr-4">2</td>
                                        <td class="pr-4">https://facebook.com/page</td>
                                        <td>500</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <input type="file" name="csv_file" accept=".csv,.txt"
                            class="w-full border rounded px-3 py-2">
                        <p class="text-sm text-gray-600 mt-1">
                            Accepted formats: .csv, .txt (Max 2MB)
                        </p>
                    </div>
                </div>

                <div class="flex gap-4">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded font-semibold hover:bg-blue-700">
                        Validate Orders →
                    </button>
                    <a href="{{ route('user.orders.create') }}" 
                       class="bg-gray-200 px-6 py-3 rounded font-semibold hover:bg-gray-300">
                        Single Order Instead
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Help Section -->
    <div class="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 class="font-semibold text-lg mb-3">📚 How to Use Mass Orders</h3>
        <div class="grid md:grid-cols-2 gap-4 text-sm">
            <div>
                <h4 class="font-semibold mb-2">Step 1: Prepare Your Data</h4>
                <ul class="list-disc list-inside space-y-1">
                    <li>Get service IDs from service list</li>
                    <li>Prepare your target links</li>
                    <li>Download template for reference</li>
                </ul>
            </div>
            <div>
                <h4 class="font-semibold mb-2">Step 2: Submit Orders</h4>
                <ul class="list-disc list-inside space-y-1">
                    <li>Enter data (text or upload CSV)</li>
                    <li>Click "Validate Orders"</li>
                    <li>Review and confirm</li>
                </ul>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function switchTab(tab) {
    // Update tabs
    document.querySelectorAll('[id^="tab-"]').forEach(t => {
        t.classList.remove('border-blue-600', 'text-blue-600');
        t.classList.add('text-gray-600');
    });
    document.getElementById('tab-' + tab).classList.add('border-blue-600', 'text-blue-600');
    document.getElementById('tab-' + tab).classList.remove('text-gray-600');

    // Update content
    document.getElementById('content-text').classList.add('hidden');
    document.getElementById('content-csv').classList.add('hidden');
    document.getElementById('content-' + tab).classList.remove('hidden');

    // Enable/disable appropriate input
    if (tab === 'text') {
        document.querySelector('[name="text_input"]').removeAttribute('disabled');
        document.querySelector('[name="input_type"][value="text"]').disabled = false;
        document.querySelector('[name="input_type"][value="csv"]').disabled = true;
    } else {
        document.querySelector('[name="csv_file"]').removeAttribute('disabled');
        document.querySelector('[name="input_type"][value="csv"]').disabled = false;
        document.querySelector('[name="input_type"][value="text"]').disabled = true;
    }
}
</script>
@endpush
@endsection
