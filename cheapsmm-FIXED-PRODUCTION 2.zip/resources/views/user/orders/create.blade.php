@extends('layouts.app')

@section('title', 'New Order')

@section('content')
<div class="max-w-4xl mx-auto px-4">
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold">Place New Order</h1>
        <div class="text-sm text-gray-600">
            Balance: <strong class="text-green-600">{{ price(auth()->user()->balance) }}</strong>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        @if($errors->any())
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div id="success-message" class="hidden bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"></div>
        <div id="error-message" class="hidden bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"></div>

        <form id="order-form">
            @csrf

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Category *</label>
                <select id="category" required class="w-full border rounded px-3 py-2">
                    <option value="">Select Category</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }} ({{ $category->services_count }} services)</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Service *</label>
                <select id="service" name="service_id" required class="w-full border rounded px-3 py-2" disabled>
                    <option value="">Select a category first</option>
                </select>
                <div id="service-description" class="mt-2 p-3 bg-blue-50 rounded text-sm hidden"></div>
                <div id="service-pricing" class="mt-2 text-sm text-gray-600 hidden"></div>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Link *</label>
                <input type="url" name="link" id="link" required
                    class="w-full border rounded px-3 py-2"
                    placeholder="https://instagram.com/username">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Quantity *</label>
                <input type="number" name="quantity" id="quantity" required min="1"
                    class="w-full border rounded px-3 py-2"
                    placeholder="Enter quantity">
                <div id="quantity-limits" class="mt-1 text-sm text-gray-600 hidden"></div>
            </div>

            <div id="order-summary" class="mb-6 p-4 bg-gray-50 rounded hidden">
                <h3 class="font-semibold mb-2">Order Summary</h3>
                <div class="flex justify-between py-1">
                    <span>Service Price:</span>
                    <span id="summary-price" class="font-semibold"></span>
                </div>
                <div class="flex justify-between py-1">
                    <span>Quantity:</span>
                    <span id="summary-quantity" class="font-semibold"></span>
                </div>
                <div class="flex justify-between py-1 border-t mt-2 pt-2">
                    <span class="font-semibold">Total Charge:</span>
                    <span id="summary-total" class="font-semibold text-blue-600 text-lg"></span>
                </div>
            </div>

            <button type="submit" id="submit-btn"
                class="w-full bg-blue-600 text-white py-3 rounded font-semibold hover:bg-blue-700">
                Place Order
            </button>
        </form>
    </div>
</div>

@push('scripts')
<script>
let currentService = null;
const currencyCode = '{{ current_currency() }}';
const exchangeRate = {{ currency()->getExchangeRate(current_currency()) }};

// Load services when category changes
document.getElementById('category').addEventListener('change', function() {
    const categoryId = this.value;
    const serviceSelect = document.getElementById('service');
    
    if (!categoryId) {
        serviceSelect.disabled = true;
        serviceSelect.innerHTML = '<option value="">Select a category first</option>';
        return;
    }

    serviceSelect.disabled = true;
    serviceSelect.innerHTML = '<option value="">Loading...</option>';

    fetch(`/user/orders/services/${categoryId}`)
        .then(response => response.json())
        .then(services => {
            serviceSelect.innerHTML = '<option value="">Select Service</option>';
            services.forEach(service => {
                const priceConverted = service.price_per_1000 * exchangeRate;
                const priceFormatted = formatPrice(priceConverted);
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = `${service.name} - ${priceFormatted}/1000`;
                option.dataset.service = JSON.stringify(service);
                serviceSelect.appendChild(option);
            });
            serviceSelect.disabled = false;
        })
        .catch(error => {
            console.error('Error loading services:', error);
            serviceSelect.innerHTML = '<option value="">Error loading services</option>';
        });
});

// Update info when service changes
document.getElementById('service').addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    if (!option.dataset.service) {
        hideServiceInfo();
        return;
    }

    currentService = JSON.parse(option.dataset.service);
    showServiceInfo(currentService);
    updateOrderSummary();
});

// Update summary on quantity change
document.getElementById('quantity').addEventListener('input', updateOrderSummary);

function showServiceInfo(service) {
    const priceConverted = service.price_per_1000 * exchangeRate;
    
    document.getElementById('service-description').textContent = service.description || 'No description available';
    document.getElementById('service-description').classList.remove('hidden');
    
    const pricingHtml = `
        <div><strong>Price:</strong> ${formatPrice(priceConverted)} per 1000</div>
        <div><strong>Min:</strong> ${service.min_quantity.toLocaleString()} | <strong>Max:</strong> ${service.max_quantity.toLocaleString()}</div>
    `;
    document.getElementById('service-pricing').innerHTML = pricingHtml;
    document.getElementById('service-pricing').classList.remove('hidden');
    
    const quantityInput = document.getElementById('quantity');
    quantityInput.min = service.min_quantity;
    quantityInput.max = service.max_quantity;
    quantityInput.placeholder = `Min: ${service.min_quantity}, Max: ${service.max_quantity}`;
    
    document.getElementById('quantity-limits').textContent = 
        `Enter between ${service.min_quantity.toLocaleString()} and ${service.max_quantity.toLocaleString()}`;
    document.getElementById('quantity-limits').classList.remove('hidden');
}

function hideServiceInfo() {
    document.getElementById('service-description').classList.add('hidden');
    document.getElementById('service-pricing').classList.add('hidden');
    document.getElementById('quantity-limits').classList.add('hidden');
    document.getElementById('order-summary').classList.add('hidden');
    currentService = null;
}

function updateOrderSummary() {
    if (!currentService) return;

    const quantity = parseInt(document.getElementById('quantity').value) || 0;
    if (quantity < currentService.min_quantity || quantity > currentService.max_quantity) {
        document.getElementById('order-summary').classList.add('hidden');
        return;
    }

    const priceConverted = currentService.price_per_1000 * exchangeRate;
    const total = (priceConverted * quantity) / 1000;

    document.getElementById('summary-price').textContent = formatPrice(priceConverted) + '/1000';
    document.getElementById('summary-quantity').textContent = quantity.toLocaleString();
    document.getElementById('summary-total').textContent = formatPrice(total);
    document.getElementById('order-summary').classList.remove('hidden');
}

function formatPrice(amount) {
    return '{{ current_currency_symbol() }}' + amount.toFixed(2);
}

// Submit order
document.getElementById('order-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const submitBtn = document.getElementById('submit-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Processing...';

    const formData = new FormData(this);

    fetch('{{ route("user.orders.store") }}', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('success-message').textContent = data.message;
            document.getElementById('success-message').classList.remove('hidden');
            document.getElementById('error-message').classList.add('hidden');
            this.reset();
            hideServiceInfo();
            
            setTimeout(() => {
                window.location.href = '/user/orders/' + data.order.id;
            }, 2000);
        } else {
            document.getElementById('error-message').textContent = data.message;
            document.getElementById('error-message').classList.remove('hidden');
            document.getElementById('success-message').classList.add('hidden');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('error-message').textContent = 'An error occurred. Please try again.';
        document.getElementById('error-message').classList.remove('hidden');
    })
    .finally(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Place Order';
    });
});
</script>
@endpush
@endsection
