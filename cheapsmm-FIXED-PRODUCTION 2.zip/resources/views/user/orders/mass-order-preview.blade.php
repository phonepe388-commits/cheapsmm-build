@extends('layouts.app')

@section('title', 'Confirm Mass Order')

@section('content')
<div class="max-w-6xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Review Mass Order</h1>

    <!-- Summary Card -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <div class="grid md:grid-cols-4 gap-4">
            <div class="bg-blue-50 p-4 rounded">
                <div class="text-sm text-blue-600">Total Lines</div>
                <div class="text-2xl font-bold">{{ $parsed['total_lines'] }}</div>
            </div>
            <div class="bg-green-50 p-4 rounded">
                <div class="text-sm text-green-600">Valid Orders</div>
                <div class="text-2xl font-bold">{{ $validation['valid_count'] }}</div>
            </div>
            @if($validation['error_count'] > 0)
            <div class="bg-red-50 p-4 rounded">
                <div class="text-sm text-red-600">Errors</div>
                <div class="text-2xl font-bold">{{ $validation['error_count'] }}</div>
            </div>
            @endif
            <div class="bg-purple-50 p-4 rounded">
                <div class="text-sm text-purple-600">Total Cost</div>
                <div class="text-2xl font-bold">{{ price($validation['total_cost']) }}</div>
            </div>
        </div>
    </div>

    <!-- Balance Check -->
    <div class="mb-6">
        @if($validation['has_sufficient_balance'])
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                ✓ Sufficient balance. Your balance: <strong>{{ price($user->balance) }}</strong>
            </div>
        @else
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                ✗ Insufficient balance! Required: <strong>{{ price($validation['total_cost']) }}</strong>, 
                Your balance: <strong>{{ price($user->balance) }}</strong>
            </div>
        @endif
    </div>

    <!-- Errors -->
    @if(!empty($validation['errors']))
        <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-6">
            <h3 class="font-semibold mb-2">⚠️ Validation Errors ({{ count($validation['errors']) }}):</h3>
            <ul class="text-sm max-h-40 overflow-y-auto">
                @foreach($validation['errors'] as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Valid Orders Table -->
    @if(!empty($validation['validated_orders']))
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="p-4 border-b">
                <h3 class="font-semibold">Valid Orders ({{ $validation['valid_count'] }})</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Link</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Charge</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @foreach($validation['validated_orders'] as $order)
                        <tr>
                            <td class="px-4 py-3 text-sm">{{ $order['line'] }}</td>
                            <td class="px-4 py-3 text-sm">{{ $order['service_name'] }}</td>
                            <td class="px-4 py-3 text-sm truncate max-w-xs">{{ $order['link'] }}</td>
                            <td class="px-4 py-3 text-sm">{{ number_format($order['quantity']) }}</td>
                            <td class="px-4 py-3 text-sm font-semibold">{{ price($order['charge']) }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot class="bg-gray-50">
                        <tr>
                            <td colspan="4" class="px-4 py-3 text-right font-semibold">Total:</td>
                            <td class="px-4 py-3 font-bold text-lg">{{ price($validation['total_cost']) }}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex gap-4">
            @if($validation['has_sufficient_balance'])
                <form method="POST" action="{{ route('user.orders.mass.process') }}">
                    @csrf
                    <button type="submit" 
                        class="bg-green-600 text-white px-8 py-3 rounded font-semibold hover:bg-green-700">
                        ✓ Confirm & Place {{ $validation['valid_count'] }} Orders
                    </button>
                </form>
            @else
                <a href="{{ route('user.payments.create') }}" 
                   class="bg-blue-600 text-white px-8 py-3 rounded font-semibold hover:bg-blue-700">
                    Add Funds
                </a>
            @endif
            
            <form method="POST" action="{{ route('user.orders.mass.cancel') }}">
                @csrf
                <button type="submit" 
                    class="bg-gray-200 px-8 py-3 rounded font-semibold hover:bg-gray-300">
                    Cancel
                </button>
            </form>
        </div>
    @else
        <div class="bg-white rounded-lg shadow p-8 text-center">
            <div class="text-gray-400 text-4xl mb-4">⚠️</div>
            <p class="text-gray-600 mb-4">No valid orders found. Please fix the errors and try again.</p>
            <a href="{{ route('user.orders.mass.create') }}" 
               class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                Go Back
            </a>
        </div>
    @endif
</div>
@endsection
