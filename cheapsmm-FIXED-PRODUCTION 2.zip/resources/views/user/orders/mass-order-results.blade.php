@extends('layouts.app')

@section('title', 'Mass Order Results')

@section('content')
<div class="max-w-6xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Mass Order Results</h1>

    <!-- Success Summary -->
    <div class="bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg mb-6">
        <div class="flex items-center gap-3">
            <div class="text-3xl">✓</div>
            <div>
                <div class="font-semibold text-lg">Mass Order Completed!</div>
                <div>Successfully created {{ $results['created_count'] }} orders</div>
            </div>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="grid md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-lg shadow p-4">
            <div class="text-sm text-gray-600">Orders Created</div>
            <div class="text-2xl font-bold text-green-600">{{ $results['created_count'] }}</div>
        </div>
        @if($results['failed_count'] > 0)
        <div class="bg-white rounded-lg shadow p-4">
            <div class="text-sm text-gray-600">Failed</div>
            <div class="text-2xl font-bold text-red-600">{{ $results['failed_count'] }}</div>
        </div>
        @endif
        <div class="bg-white rounded-lg shadow p-4">
            <div class="text-sm text-gray-600">Total Cost</div>
            <div class="text-2xl font-bold">{{ price($results['total_cost']) }}</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4">
            <div class="text-sm text-gray-600">New Balance</div>
            <div class="text-2xl font-bold text-blue-600">{{ price($results['new_balance']) }}</div>
        </div>
    </div>

    <!-- Created Orders -->
    <div class="bg-white rounded-lg shadow mb-6">
        <div class="p-4 border-b flex justify-between items-center">
            <h3 class="font-semibold">Created Orders ({{ $results['created_count'] }})</h3>
            <a href="{{ route('user.orders.index') }}" class="text-blue-600 hover:underline text-sm">
                View All Orders →
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Charge</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach($results['created'] as $order)
                    <tr>
                        <td class="px-4 py-3 text-sm font-semibold">#{{ $order['order_id'] }}</td>
                        <td class="px-4 py-3 text-sm">{{ $order['service'] }}</td>
                        <td class="px-4 py-3 text-sm">{{ number_format($order['quantity']) }}</td>
                        <td class="px-4 py-3 text-sm font-semibold">{{ price($order['charge']) }}</td>
                        <td class="px-4 py-3 text-sm">
                            <a href="{{ route('user.orders.show', $order['order_id']) }}" 
                               class="text-blue-600 hover:underline">View</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Failed Orders (if any) -->
    @if($results['failed_count'] > 0)
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="p-4 border-b">
                <h3 class="font-semibold text-red-600">Failed Orders ({{ $results['failed_count'] }})</h3>
            </div>
            <div class="p-4">
                <ul class="space-y-2">
                    @foreach($results['failed'] as $failed)
                    <li class="text-sm text-red-600">
                        Line {{ $failed['line'] }}: {{ $failed['error'] }}
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    @endif

    <!-- Action Buttons -->
    <div class="flex gap-4">
        <a href="{{ route('user.orders.mass.create') }}" 
           class="bg-blue-600 text-white px-6 py-3 rounded font-semibold hover:bg-blue-700">
            Create Another Mass Order
        </a>
        <a href="{{ route('user.orders.index') }}" 
           class="bg-gray-200 px-6 py-3 rounded font-semibold hover:bg-gray-300">
            View All Orders
        </a>
    </div>
</div>
@endsection
