@extends('layouts.app')

@section('title', 'Ticket #' . $ticket->id)

@section('content')
<div class="max-w-4xl mx-auto px-4">
    <div class="mb-6">
        <a href="{{ route('user.tickets.index') }}" class="text-blue-600 hover:underline">
            <i class="fas fa-arrow-left mr-2"></i>Back to Tickets
        </a>
    </div>

    <!-- Ticket Header -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h1 class="text-2xl font-bold mb-2">{{ $ticket->subject }}</h1>
                <div class="flex gap-4 text-sm text-gray-600">
                    <span><i class="fas fa-hashtag"></i> {{ $ticket->id }}</span>
                    <span><i class="fas fa-calendar"></i> {{ $ticket->created_at->format('M d, Y H:i') }}</span>
                </div>
            </div>
            <div class="text-right">
                <span class="px-3 py-1 rounded text-sm
                    @if($ticket->status === 'open') bg-blue-100 text-blue-800
                    @elseif($ticket->status === 'waiting_reply') bg-yellow-100 text-yellow-800
                    @elseif($ticket->status === 'answered') bg-green-100 text-green-800
                    @else bg-gray-100 text-gray-800
                    @endif">
                    {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                </span>
                <div class="mt-2">
                    <span class="px-3 py-1 rounded text-sm
                        @if($ticket->priority === 'high') bg-red-100 text-red-800
                        @elseif($ticket->priority === 'medium') bg-yellow-100 text-yellow-800
                        @else bg-green-100 text-green-800
                        @endif">
                        {{ ucfirst($ticket->priority) }} Priority
                    </span>
                </div>
            </div>
        </div>

        @if($ticket->status !== 'closed')
        <div class="flex gap-2">
            <form method="POST" action="{{ route('user.tickets.close', $ticket) }}">
                @csrf
                <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 text-sm">
                    <i class="fas fa-times-circle mr-1"></i>Close Ticket
                </button>
            </form>
        </div>
        @endif
    </div>

    <!-- Messages -->
    <div class="space-y-4">
        @foreach($ticket->messages as $message)
        <div class="bg-white rounded-lg shadow p-6 {{ $message->is_admin ? 'border-l-4 border-blue-500' : '' }}">
            <div class="flex justify-between items-start mb-3">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                        @if($message->is_admin)
                            <i class="fas fa-user-shield text-blue-600"></i>
                        @else
                            <i class="fas fa-user text-gray-600"></i>
                        @endif
                    </div>
                    <div>
                        <div class="font-semibold">{{ $message->is_admin ? 'Support Team' : $message->user->name }}</div>
                        <div class="text-sm text-gray-500">{{ $message->created_at->format('M d, Y H:i') }}</div>
                    </div>
                </div>
            </div>

            <div class="prose max-w-none">
                {!! nl2br(e($message->message)) !!}
            </div>

            @if($message->attachments && count($message->attachments) > 0)
            <div class="mt-4">
                <div class="text-sm font-semibold mb-2">Attachments:</div>
                <div class="flex flex-wrap gap-2">
                    @foreach($message->attachments as $index => $attachment)
                    <a href="{{ route('user.tickets.download', [$ticket, $message, $index]) }}" 
                        class="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded hover:bg-gray-200 text-sm">
                        <i class="fas fa-paperclip"></i>
                        {{ $attachment['name'] }}
                    </a>
                    @endforeach
                </div>
            </div>
            @endif
        </div>
        @endforeach
    </div>

    <!-- Reply Form -->
    @if($ticket->status !== 'closed')
    <div class="bg-white rounded-lg shadow p-6 mt-6">
        <h3 class="font-semibold mb-4">Reply to Ticket</h3>
        <form method="POST" action="{{ route('user.tickets.reply', $ticket) }}" enctype="multipart/form-data">
            @csrf
            <div class="mb-4">
                <textarea name="message" rows="4" required
                    class="w-full border rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Type your reply..."></textarea>
            </div>

            <div class="mb-4">
                <input type="file" name="attachments[]" multiple accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                    class="w-full border rounded px-4 py-2">
            </div>

            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                Send Reply
            </button>
        </form>
    </div>
    @else
    <div class="bg-gray-100 rounded-lg p-6 mt-6 text-center">
        <p class="text-gray-600">This ticket is closed. To continue discussion, please open a new ticket.</p>
    </div>
    @endif
</div>
@endsection
