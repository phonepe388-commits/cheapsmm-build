@extends('layouts.app')

@section('title', 'Support Tickets')

@section('content')
<div class="max-w-7xl mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Support Tickets</h1>
        <a href="{{ route('user.tickets.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i>New Ticket
        </a>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white p-4 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Total</div>
            <div class="text-2xl font-bold">{{ $stats['total'] }}</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Open</div>
            <div class="text-2xl font-bold text-green-600">{{ $stats['open'] }}</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Waiting Reply</div>
            <div class="text-2xl font-bold text-yellow-600">{{ $stats['waiting'] }}</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
            <div class="text-gray-500 text-sm">Closed</div>
            <div class="text-2xl font-bold text-gray-600">{{ $stats['closed'] }}</div>
        </div>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow mb-6 p-4">
        <form method="GET" class="flex gap-4">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search tickets..." 
                class="border rounded px-3 py-2 flex-1">
            <select name="status" class="border rounded px-3 py-2">
                <option value="">All Status</option>
                <option value="open" {{ request('status') == 'open' ? 'selected' : '' }}>Open</option>
                <option value="waiting_reply" {{ request('status') == 'waiting_reply' ? 'selected' : '' }}>Waiting Reply</option>
                <option value="answered" {{ request('status') == 'answered' ? 'selected' : '' }}>Answered</option>
                <option value="closed" {{ request('status') == 'closed' ? 'selected' : '' }}>Closed</option>
            </select>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Filter</button>
        </form>
    </div>

    <!-- Tickets List -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priority</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Updated</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                @forelse($tickets as $ticket)
                <tr>
                    <td class="px-6 py-4">#{{ $ticket->id }}</td>
                    <td class="px-6 py-4">
                        <a href="{{ route('user.tickets.show', $ticket) }}" class="text-blue-600 hover:underline font-medium">
                            {{ $ticket->subject }}
                        </a>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs rounded
                            @if($ticket->priority === 'high') bg-red-100 text-red-800
                            @elseif($ticket->priority === 'medium') bg-yellow-100 text-yellow-800
                            @else bg-green-100 text-green-800
                            @endif">
                            {{ ucfirst($ticket->priority) }}
                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs rounded
                            @if($ticket->status === 'open') bg-blue-100 text-blue-800
                            @elseif($ticket->status === 'waiting_reply') bg-yellow-100 text-yellow-800
                            @elseif($ticket->status === 'answered') bg-green-100 text-green-800
                            @else bg-gray-100 text-gray-800
                            @endif">
                            {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm">{{ $ticket->updated_at->diffForHumans() }}</td>
                    <td class="px-6 py-4">
                        <a href="{{ route('user.tickets.show', $ticket) }}" class="text-blue-600 hover:underline">View</a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                        No tickets found. <a href="{{ route('user.tickets.create') }}" class="text-blue-600 hover:underline">Create one</a>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        {{ $tickets->links() }}
    </div>
</div>
@endsection
