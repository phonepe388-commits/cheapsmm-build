@extends('layouts.app')

@section('title', 'Create Ticket')

@section('content')
<div class="max-w-3xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Create Support Ticket</h1>

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('user.tickets.store') }}" enctype="multipart/form-data" class="bg-white rounded-lg shadow p-6">
        @csrf

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Subject *</label>
            <input type="text" name="subject" value="{{ old('subject') }}" required
                class="w-full border rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Brief description of your issue">
        </div>

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Priority *</label>
            <select name="priority" required class="w-full border rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="low" {{ old('priority') == 'low' ? 'selected' : '' }}>Low</option>
                <option value="medium" {{ old('priority') == 'medium' ? 'selected' : '' }} selected>Medium</option>
                <option value="high" {{ old('priority') == 'high' ? 'selected' : '' }}>High</option>
            </select>
        </div>

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Message *</label>
            <textarea name="message" rows="6" required
                class="w-full border rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Please describe your issue in detail...">{{ old('message') }}</textarea>
        </div>

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Attachments (Optional)</label>
            <input type="file" name="attachments[]" multiple accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                class="w-full border rounded px-4 py-2">
            <p class="text-sm text-gray-500 mt-1">Max 5 files, 5MB each. Allowed: JPG, PNG, PDF, DOC, DOCX</p>
        </div>

        <div class="flex gap-4">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                Submit Ticket
            </button>
            <a href="{{ route('user.tickets.index') }}" class="bg-gray-200 px-6 py-2 rounded hover:bg-gray-300">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection
