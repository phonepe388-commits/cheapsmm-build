@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold">Welcome back, {{ auth()->user()->name }}!</h1>
        <div class="text-right">
            <div class="text-sm text-gray-600">Current Balance</div>
            <div class="text-3xl font-bold text-green-600">${{ number_format(auth()->user()->balance, 2) }}</div>
            <a href="{{ route('user.payments.add-funds') }}" class="text-sm text-blue-600">Add Funds →</a>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <a href="{{ route('user.orders.create') }}" class="bg-blue-600 text-white p-6 rounded-lg text-center hover:bg-blue-700">
            <div class="text-3xl mb-2">📦</div>
            <div class="font-semibold">New Order</div>
        </a>
        <a href="{{ route('user.orders.mass-order') }}" class="bg-purple-600 text-white p-6 rounded-lg text-center hover:bg-purple-700">
            <div class="text-3xl mb-2">📊</div>
            <div class="font-semibold">Mass Order</div>
        </a>
        <a href="{{ route('user.payments.add-funds') }}" class="bg-green-600 text-white p-6 rounded-lg text-center hover:bg-green-700">
            <div class="text-3xl mb-2">💰</div>
            <div class="font-semibold">Add Funds</div>
        </a>
        <a href="{{ route('user.tickets.create') }}" class="bg-orange-600 text-white p-6 rounded-lg text-center hover:bg-orange-700">
            <div class="text-3xl mb-2">💬</div>
            <div class="font-semibold">Support</div>
        </a>
    </div>

    <!-- Statistics -->
    <div class="grid md:grid-cols-4 gap-6 mb-6">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Total Spent</div>
            <div class="text-2xl font-bold">${{ number_format($stats['total_spent'], 2) }}</div>
            <div class="text-xs text-gray-500 mt-1">All time</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Total Orders</div>
            <div class="text-2xl font-bold">{{ number_format($stats['total_orders']) }}</div>
            <div class="text-xs text-green-600 mt-1">{{ $stats['completed_orders'] }} completed</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Pending Orders</div>
            <div class="text-2xl font-bold">{{ $stats['pending_orders'] }}</div>
            <div class="text-xs text-gray-500 mt-1">In progress</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">This Month</div>
            <div class="text-2xl font-bold">${{ number_format($stats['month_spent'], 2) }}</div>
            <div class="text-xs text-gray-500 mt-1">{{ $stats['month_orders'] }} orders</div>
        </div>
    </div>

    <!-- Recent Orders & Activity -->
    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow">
            <div class="p-4 border-b flex justify-between items-center">
                <h3 class="font-semibold">Recent Orders</h3>
                <a href="{{ route('user.orders.index') }}" class="text-sm text-blue-600">View All →</a>
            </div>
            <div class="divide-y">
                @forelse($recentOrders as $order)
                <div class="p-4 hover:bg-gray-50">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="font-semibold text-sm">{{ $order->service->name }}</div>
                            <div class="text-xs text-gray-500">{{ number_format($order->quantity) }} - ${{ number_format($order->charge, 2) }}</div>
                        </div>
                        <div class="text-right">
                            <span class="px-2 py-1 rounded text-xs
                                {{ $order->status === 'completed' ? 'bg-green-100 text-green-800' : 
                                   ($order->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800') }}">
                                {{ ucfirst($order->status) }}
                            </span>
                            <div class="text-xs text-gray-500 mt-1">{{ $order->created_at->diffForHumans() }}</div>
                        </div>
                    </div>
                </div>
                @empty
                <div class="p-8 text-center text-gray-500">
                    <div class="text-4xl mb-2">📦</div>
                    <div>No orders yet</div>
                    <a href="{{ route('user.orders.create') }}" class="text-blue-600 text-sm">Place your first order →</a>
                </div>
                @endforelse
            </div>
        </div>

        <div class="bg-white rounded-lg shadow">
            <div class="p-4 border-b">
                <h3 class="font-semibold">Quick Stats</h3>
            </div>
            <div class="p-4 space-y-4">
                <div class="flex justify-between items-center">
                    <span class="text-gray-600">Account Age</span>
                    <span class="font-semibold">{{ auth()->user()->created_at->diffForHumans(null, true) }}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600">Referral Earnings</span>
                    <span class="font-semibold text-green-600">${{ number_format($stats['referral_earnings'], 2) }}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600">API Status</span>
                    <span class="font-semibold {{ auth()->user()->api_key ? 'text-green-600' : 'text-gray-400' }}">
                        {{ auth()->user()->api_key ? 'Active' : 'Not Enabled' }}
                    </span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600">Child Panels</span>
                    <span class="font-semibold">{{ $stats['child_panels'] }}</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
