@extends('layouts.app')

@section('title', 'Referral Program')

@section('content')
<div class="max-w-7xl mx-auto px-4">
    <div class="mb-6">
        <h1 class="text-3xl font-bold">💰 Referral Program</h1>
        <p class="text-gray-600">Earn money by referring new users</p>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <!-- Stats Overview -->
    <div class="grid md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Total Referrals</div>
            <div class="text-3xl font-bold text-blue-600">{{ $stats['total_referrals'] }}</div>
            <div class="text-xs text-gray-500 mt-1">
                {{ $stats['active_referrals'] }} active
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Total Earned</div>
            <div class="text-3xl font-bold text-green-600">{{ price($stats['total_earned']) }}</div>
            <div class="text-xs text-gray-500 mt-1">All time</div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Pending Earnings</div>
            <div class="text-3xl font-bold text-yellow-600">{{ price($stats['pending_earnings']) }}</div>
            <div class="text-xs text-gray-500 mt-1">Ready to withdraw</div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Withdrawn</div>
            <div class="text-3xl font-bold text-purple-600">{{ price($stats['paid_earnings']) }}</div>
            <div class="text-xs text-gray-500 mt-1">Transferred to balance</div>
        </div>
    </div>

    <!-- Referral Link -->
    <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg shadow p-6 mb-6 text-white">
        <h2 class="text-xl font-semibold mb-4">🔗 Your Referral Link</h2>
        
        <div class="bg-white/10 backdrop-blur rounded-lg p-4 mb-4">
            <label class="block text-sm mb-2 opacity-90">Share this link:</label>
            <div class="flex gap-2">
                <input type="text" 
                    value="{{ url('/register?ref=' . $user->referral_code) }}" 
                    id="referralLink"
                    readonly 
                    class="flex-1 bg-white text-gray-900 rounded px-4 py-3 font-mono text-sm">
                <button onclick="copyReferralLink()" 
                    class="bg-white text-blue-600 px-6 py-3 rounded font-semibold hover:bg-blue-50 transition">
                    📋 Copy
                </button>
            </div>
        </div>

        <div class="grid md:grid-cols-2 gap-4">
            <div class="bg-white/10 backdrop-blur rounded p-3">
                <div class="text-sm opacity-90">Referral Code</div>
                <div class="text-xl font-bold">{{ $user->referral_code }}</div>
            </div>
            <div class="bg-white/10 backdrop-blur rounded p-3">
                <div class="text-sm opacity-90">Commission Rate</div>
                <div class="text-xl font-bold">10%</div>
            </div>
        </div>
    </div>

    <!-- How It Works -->
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
        <h3 class="font-semibold text-lg mb-3">💡 How It Works</h3>
        <div class="grid md:grid-cols-3 gap-4">
            <div>
                <div class="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mb-2">1</div>
                <h4 class="font-semibold mb-1">Share Your Link</h4>
                <p class="text-sm text-gray-600">Send your referral link to friends and followers</p>
            </div>
            <div>
                <div class="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mb-2">2</div>
                <h4 class="font-semibold mb-1">They Sign Up</h4>
                <p class="text-sm text-gray-600">New users register using your link</p>
            </div>
            <div>
                <div class="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mb-2">3</div>
                <h4 class="font-semibold mb-1">You Earn 10%</h4>
                <p class="text-sm text-gray-600">Get 10% of all their orders forever!</p>
            </div>
        </div>
    </div>

    <!-- Withdraw Earnings -->
    @if($stats['pending_earnings'] >= 10)
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">💸 Withdraw Earnings</h3>
            <p class="text-gray-600 mb-4">
                You have <strong class="text-green-600">{{ price($stats['pending_earnings']) }}</strong> available to withdraw.
            </p>
            
            <form method="POST" action="{{ route('user.referrals.withdraw') }}" class="flex gap-3 items-end">
                @csrf
                <div class="flex-1 max-w-md">
                    <label class="block text-sm font-semibold mb-2">Amount to Withdraw</label>
                    <input type="number" name="amount" step="0.01" min="10" 
                        value="{{ $stats['pending_earnings'] }}"
                        max="{{ $stats['pending_earnings'] }}"
                        class="w-full border rounded px-4 py-2">
                    <p class="text-xs text-gray-500 mt-1">Minimum: $10.00</p>
                </div>
                <button type="submit" 
                    class="bg-green-600 text-white px-6 py-2 rounded font-semibold hover:bg-green-700">
                    Transfer to Balance
                </button>
            </form>
        </div>
    @elseif($stats['pending_earnings'] > 0)
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p class="text-yellow-800">
                💰 You have <strong>{{ price($stats['pending_earnings']) }}</strong> in pending earnings. 
                You need at least <strong>$10.00</strong> to withdraw.
            </p>
        </div>
    @endif

    <!-- Tabs -->
    <div class="bg-white rounded-lg shadow mb-6">
        <div class="border-b">
            <div class="flex">
                <button onclick="switchTab('referrals')" id="tab-referrals"
                    class="px-6 py-3 font-semibold border-b-2 border-blue-600 text-blue-600">
                    My Referrals ({{ $stats['total_referrals'] }})
                </button>
                <button onclick="switchTab('earnings')" id="tab-earnings"
                    class="px-6 py-3 font-semibold text-gray-600 hover:text-blue-600">
                    Earnings History
                </button>
            </div>
        </div>

        <!-- Referrals Tab -->
        <div id="content-referrals" class="p-6">
            @if($referrals->count() > 0)
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Joined</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Orders</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Spent</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Your Earnings</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @foreach($referrals as $referral)
                                <tr>
                                    <td class="px-4 py-3 text-sm">{{ $referral->name }}</td>
                                    <td class="px-4 py-3 text-sm">{{ $referral->email }}</td>
                                    <td class="px-4 py-3 text-sm">{{ $referral->created_at->format('M d, Y') }}</td>
                                    <td class="px-4 py-3 text-sm">{{ $referral->orders()->count() }}</td>
                                    <td class="px-4 py-3 text-sm font-semibold">
                                        {{ price($referral->orders()->sum('charge')) }}
                                    </td>
                                    <td class="px-4 py-3 text-sm font-semibold text-green-600">
                                        {{ price($referral->referralEarnings()->sum('amount')) }}
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        @if($referral->status === 'active')
                                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                                        @else
                                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">{{ ucfirst($referral->status) }}</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    {{ $referrals->links() }}
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-gray-400 text-5xl mb-4">👥</div>
                    <h3 class="text-lg font-semibold text-gray-700 mb-2">No Referrals Yet</h3>
                    <p class="text-gray-600 mb-4">Start sharing your referral link to earn commissions!</p>
                    <button onclick="copyReferralLink()" 
                        class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                        Copy Referral Link
                    </button>
                </div>
            @endif
        </div>

        <!-- Earnings Tab -->
        <div id="content-earnings" class="p-6 hidden">
            @if($earnings->count() > 0)
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">From User</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order Amount</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Commission</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @foreach($earnings as $earning)
                                <tr>
                                    <td class="px-4 py-3 text-sm">
                                        {{ $earning->created_at->format('M d, Y H:i') }}
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        {{ $earning->order->user->name ?? 'N/A' }}
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        #{{ $earning->order_id }}
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        {{ price($earning->order->charge ?? 0) }}
                                    </td>
                                    <td class="px-4 py-3 text-sm font-semibold text-green-600">
                                        {{ price($earning->amount) }}
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        @if($earning->status === 'pending')
                                            <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">Pending</span>
                                        @elseif($earning->status === 'paid')
                                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Paid</span>
                                        @else
                                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">{{ ucfirst($earning->status) }}</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    {{ $earnings->links() }}
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-gray-400 text-5xl mb-4">💵</div>
                    <h3 class="text-lg font-semibold text-gray-700 mb-2">No Earnings Yet</h3>
                    <p class="text-gray-600">Your commission earnings will appear here</p>
                </div>
            @endif
        </div>
    </div>

    <!-- Social Share Buttons -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-4">📢 Share on Social Media</h3>
        <div class="flex gap-3 flex-wrap">
            <a href="https://twitter.com/intent/tweet?text=Join%20this%20amazing%20SMM%20panel!&url={{ urlencode(url('/register?ref=' . $user->referral_code)) }}" 
               target="_blank"
               class="bg-blue-400 text-white px-6 py-2 rounded hover:bg-blue-500 flex items-center gap-2">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path></svg>
                Twitter
            </a>
            
            <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url('/register?ref=' . $user->referral_code)) }}" 
               target="_blank"
               class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 flex items-center gap-2">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path></svg>
                Facebook
            </a>
            
            <a href="https://wa.me/?text={{ urlencode('Join this amazing SMM panel! ' . url('/register?ref=' . $user->referral_code)) }}" 
               target="_blank"
               class="bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600 flex items-center gap-2">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"></path></svg>
                WhatsApp
            </a>
        </div>
    </div>
</div>

@push('scripts')
<script>
function copyReferralLink() {
    const input = document.getElementById('referralLink');
    input.select();
    document.execCommand('copy');
    alert('Referral link copied to clipboard!');
}

function switchTab(tab) {
    // Update tabs
    document.querySelectorAll('[id^="tab-"]').forEach(t => {
        t.classList.remove('border-blue-600', 'text-blue-600');
        t.classList.add('text-gray-600');
    });
    document.getElementById('tab-' + tab).classList.add('border-blue-600', 'text-blue-600');
    document.getElementById('tab-' + tab).classList.remove('text-gray-600');

    // Update content
    document.getElementById('content-referrals').classList.add('hidden');
    document.getElementById('content-earnings').classList.add('hidden');
    document.getElementById('content-' + tab).classList.remove('hidden');
}
</script>
@endpush
@endsection
