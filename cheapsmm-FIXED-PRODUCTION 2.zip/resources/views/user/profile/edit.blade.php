@extends('layouts.app')

@section('title', 'Edit Profile')

@section('content')
<div class="max-w-4xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Profile Settings</h1>

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Sidebar -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="text-center mb-6">
                    @if($user->avatar)
                        <img src="{{ Storage::url($user->avatar) }}" class="w-24 h-24 rounded-full mx-auto mb-4">
                    @else
                        <div class="w-24 h-24 rounded-full bg-gray-200 mx-auto mb-4 flex items-center justify-center">
                            <i class="fas fa-user text-3xl text-gray-400"></i>
                        </div>
                    @endif
                    <h3 class="font-semibold">{{ $user->name }}</h3>
                    <p class="text-sm text-gray-500">{{ $user->email }}</p>
                </div>

                <form method="POST" action="{{ route('user.profile.upload-avatar') }}" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="avatar" accept="image/*" class="hidden" id="avatar-input">
                    <button type="button" onclick="document.getElementById('avatar-input').click()" 
                        class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mb-2">
                        Change Avatar
                    </button>
                    <button type="submit" class="hidden" id="avatar-submit">Upload</button>
                </form>

                @if($user->avatar)
                <form method="POST" action="{{ route('user.profile.delete-avatar') }}">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="w-full bg-red-600 text-white py-2 rounded hover:bg-red-700">
                        Remove Avatar
                    </button>
                </form>
                @endif
            </div>

            <div class="bg-white rounded-lg shadow p-6 mt-6">
                <h3 class="font-semibold mb-4">Account Info</h3>
                <div class="space-y-3 text-sm">
                    <div>
                        <span class="text-gray-500">Status:</span>
                        <span class="font-semibold text-green-600">{{ ucfirst($user->status) }}</span>
                    </div>
                    <div>
                        <span class="text-gray-500">Member Since:</span>
                        <span class="font-semibold">{{ $user->created_at->format('M d, Y') }}</span>
                    </div>
                    <div>
                        <span class="text-gray-500">2FA:</span>
                        <span class="font-semibold">{{ $user->two_factor_enabled ? 'Enabled' : 'Disabled' }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Basic Information -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="font-semibold text-lg mb-4">Basic Information</h3>
                <form method="POST" action="{{ route('user.profile.update') }}">
                    @csrf
                    @method('PUT')

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-gray-700 mb-2">Name</label>
                            <input type="text" name="name" value="{{ old('name', $user->name) }}" required
                                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Email</label>
                            <input type="email" name="email" value="{{ old('email', $user->email) }}" required
                                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-gray-700 mb-2">Phone</label>
                            <input type="tel" name="phone" value="{{ old('phone', $user->phone) }}"
                                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Timezone</label>
                            <select name="timezone" class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Select Timezone</option>
                                @foreach($timezones as $tz)
                                    <option value="{{ $tz }}" {{ $user->timezone == $tz ? 'selected' : '' }}>{{ $tz }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                        Update Profile
                    </button>
                </form>
            </div>

            <!-- Change Password -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="font-semibold text-lg mb-4">Change Password</h3>
                <form method="POST" action="{{ route('user.profile.update-password') }}">
                    @csrf

                    <div class="mb-4">
                        <label class="block text-gray-700 mb-2">Current Password</label>
                        <input type="password" name="current_password" required
                            class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="mb-4">
                        <label class="block text-gray-700 mb-2">New Password</label>
                        <input type="password" name="password" required
                            class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="mb-4">
                        <label class="block text-gray-700 mb-2">Confirm New Password</label>
                        <input type="password" name="password_confirmation" required
                            class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                        Change Password
                    </button>
                </form>
            </div>

            <!-- Two-Factor Authentication -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="font-semibold text-lg mb-4">Two-Factor Authentication</h3>
                <p class="text-gray-600 mb-4">Add an extra layer of security to your account</p>

                @if($user->two_factor_enabled)
                    <div class="bg-green-50 border border-green-200 rounded p-4 mb-4">
                        <p class="text-green-800"><i class="fas fa-shield-alt mr-2"></i>2FA is currently enabled</p>
                    </div>
                    <form method="POST" action="{{ route('user.profile.disable-2fa') }}">
                        @csrf
                        <div class="mb-4">
                            <label class="block text-gray-700 mb-2">Confirm Password to Disable</label>
                            <input type="password" name="password" required class="w-full border rounded px-3 py-2">
                        </div>
                        <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700">
                            Disable 2FA
                        </button>
                    </form>
                @else
                    <a href="{{ route('user.profile.enable-2fa') }}" class="inline-block bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">
                        Enable 2FA
                    </a>
                @endif
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.getElementById('avatar-input').addEventListener('change', function() {
    if (this.files.length > 0) {
        document.getElementById('avatar-submit').click();
    }
});
</script>
@endpush
@endsection
