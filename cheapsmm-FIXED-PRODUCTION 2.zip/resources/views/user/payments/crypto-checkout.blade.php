@extends('layouts.app')
@section('title', 'Crypto Payment')
@section('content')
<div class="max-w-2xl mx-auto px-4 py-12">
    <div class="bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-2xl font-bold mb-6">Complete Your Crypto Payment</h2>
        
        <div class="bg-blue-50 border-l-4 border-blue-600 p-4 mb-6">
            <p class="font-semibold">Payment Details:</p>
            <p>Amount: <strong>${{ number_format($payment->amount, 2) }} USD</strong></p>
            <p>Crypto Amount: <strong>{{ $payment->crypto_amount }} {{ $payment->crypto_currency }}</strong></p>
        </div>

        <div class="mb-6">
            <label class="block mb-2 font-semibold">Send {{ $payment->crypto_currency }} to this address:</label>
            <div class="bg-gray-100 p-4 rounded font-mono text-sm break-all mb-2">
                {{ $payment->crypto_address }}
            </div>
            <button onclick="navigator.clipboard.writeText('{{ $payment->crypto_address }}')" class="text-blue-600 text-sm">
                📋 Copy Address
            </button>
        </div>

        <div class="bg-yellow-50 border-l-4 border-yellow-600 p-4 mb-6">
            <p class="font-semibold mb-2">Important:</p>
            <ul class="text-sm space-y-1">
                <li>• Send exactly {{ $payment->crypto_amount }} {{ $payment->crypto_currency }}</li>
                <li>• Payment will be confirmed automatically after blockchain confirmation</li>
                <li>• Do not close this page until payment is confirmed</li>
                <li>• Funds will be added to your account after confirmation</li>
            </ul>
        </div>

        <div id="status" class="text-center py-4">
            <div class="animate-pulse">
                <div class="text-4xl mb-2">⏳</div>
                <p class="text-gray-600">Waiting for payment...</p>
            </div>
        </div>

        <div class="text-center mt-6">
            <a href="{{ route('user.payments.index') }}" class="text-gray-600 hover:text-gray-800">Cancel & Return</a>
        </div>
    </div>
</div>

<script>
// Poll for payment status every 10 seconds
setInterval(function() {
    fetch('/api/payment-status/{{ $payment->id }}')
        .then(r => r.json())
        .then(data => {
            if(data.status === 'completed') {
                document.getElementById('status').innerHTML = '<div class="text-green-600"><div class="text-4xl mb-2">✅</div><p class="font-semibold">Payment Confirmed!</p></div>';
                setTimeout(() => window.location.href = '/dashboard', 2000);
            }
        });
}, 10000);
</script>
@endsection
