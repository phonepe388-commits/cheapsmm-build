@extends('layouts.app')

@section('title', 'Submit Payment Proof')

@section('content')
<div class="max-w-3xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">{{ $paymentMethod->name }} - Submit Payment</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Instructions -->
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 class="font-semibold text-lg mb-4">{{ $instructions['title'] ?? 'Payment Instructions' }}</h3>
            
            @if(isset($instructions['steps']))
                <ol class="list-decimal list-inside space-y-2 mb-4">
                    @foreach($instructions['steps'] as $step)
                        <li class="text-sm">{{ $step }}</li>
                    @endforeach
                </ol>
            @endif

            @if(isset($instructions['bank_details']))
                <div class="bg-white rounded p-4 mt-4">
                    <h4 class="font-semibold mb-2">Bank Details:</h4>
                    @foreach($instructions['bank_details'] as $label => $value)
                        <div class="flex justify-between py-1 text-sm">
                            <span class="text-gray-600">{{ $label }}:</span>
                            <span class="font-mono font-semibold">{{ $value }}</span>
                        </div>
                    @endforeach
                </div>
            @endif

            <div class="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm">
                <strong>⚠️ Important:</strong> Your payment will be manually reviewed and approved within 1-24 hours.
            </div>
        </div>

        <!-- Submission Form -->
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-semibold text-lg mb-4">Submit Payment Proof</h3>

            @if($errors->any())
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('user.payments.manual.submit') }}" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="amount" value="{{ $amount }}">
                <input type="hidden" name="payment_method_code" value="{{ $paymentMethod->code }}">

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Amount</label>
                    <div class="text-2xl font-bold text-blue-600">${{ number_format($amount, 2) }}</div>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Transaction Reference *</label>
                    <input type="text" name="transaction_ref" required
                        class="w-full border rounded px-3 py-2"
                        placeholder="Enter transaction/reference number">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Sender Name *</label>
                    <input type="text" name="sender_name" value="{{ auth()->user()->name }}" required
                        class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Transfer Date *</label>
                    <input type="date" name="transfer_date" value="{{ date('Y-m-d') }}" required
                        class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Upload Receipt/Proof *</label>
                    <input type="file" name="receipt" accept=".jpg,.jpeg,.png,.pdf" required
                        class="w-full border rounded px-3 py-2">
                    <p class="text-sm text-gray-500 mt-1">Accepted: JPG, PNG, PDF (Max 5MB)</p>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Additional Notes</label>
                    <textarea name="notes" rows="3" class="w-full border rounded px-3 py-2"></textarea>
                </div>

                <div class="flex gap-4">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-3 rounded font-semibold hover:bg-blue-700">
                        Submit for Review
                    </button>
                    <a href="{{ route('user.payments.create') }}" class="flex-1 bg-gray-200 text-center py-3 rounded font-semibold hover:bg-gray-300">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
