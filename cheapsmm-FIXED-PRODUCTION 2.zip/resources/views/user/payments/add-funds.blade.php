@extends('layouts.app')

@section('title', 'Add Funds')

@section('content')
<div class="max-w-2xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Add Funds to Your Account</h1>

    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div class="flex items-center">
            <i class="fas fa-wallet text-blue-600 text-2xl mr-3"></i>
            <div>
                <div class="text-sm text-gray-600">Current Balance</div>
                <div class="text-2xl font-bold text-blue-600">${{ number_format(auth()->user()->balance, 2) }}</div>
            </div>
        </div>
    </div>

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('user.payments.store') }}" class="bg-white rounded-lg shadow p-6">
        @csrf
        
        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Amount (USD)</label>
            <input type="number" name="amount" id="paymentAmount" step="0.01" min="{{ $minAmount }}" max="{{ $maxAmount }}" 
                value="{{ old('amount') }}" required
                class="w-full border rounded px-4 py-3 text-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter amount">
            <p class="text-sm text-gray-500 mt-1">Minimum: ${{ $minAmount }} | Maximum: ${{ $maxAmount }}</p>
        </div>

        <!-- Coupon Section -->
        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-2">Have a Coupon? 🎟️</label>
            <div class="flex gap-2">
                <input type="text" id="couponCode" name="coupon_code"
                    class="flex-1 border rounded px-4 py-2 uppercase"
                    placeholder="Enter coupon code">
                <button type="button" onclick="validateCoupon()" 
                    class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                    Apply
                </button>
            </div>
            <div id="couponMessage" class="mt-2 text-sm"></div>
            <div id="couponDiscount" class="hidden mt-3 bg-green-50 border border-green-200 rounded p-3">
                <div class="flex justify-between items-center">
                    <div>
                        <div class="text-sm text-gray-600">Discount Applied:</div>
                        <div class="font-semibold text-green-600">-$<span id="discountAmount">0.00</span></div>
                    </div>
                    <button type="button" onclick="removeCoupon()" 
                        class="text-red-600 hover:underline text-sm">
                        Remove
                    </button>
                </div>
            </div>
        </div>

        <div id="totalAmount" class="hidden mb-6 bg-blue-50 p-4 rounded">
            <div class="flex justify-between text-lg">
                <span class="font-semibold">Total to Pay:</span>
                <span class="font-bold text-blue-600">$<span id="finalAmount">0.00</span></span>
            </div>
        </div>

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-3">Select Payment Method</label>
            <div class="space-y-3">
                @foreach($paymentMethods as $method)
                <label class="flex items-center p-4 border-2 rounded-lg cursor-pointer hover:border-blue-500 transition">
                    <input type="radio" name="payment_method" value="{{ $method->id }}" required class="mr-3">
                    <div class="flex-1">
                        <div class="font-semibold">{{ $method->name }}</div>
                        @if($method->description)
                            <div class="text-sm text-gray-600">{{ $method->description }}</div>
                        @endif
                    </div>
                    @if($method->logo)
                        <img src="{{ $method->logo }}" alt="{{ $method->name }}" class="h-8">
                    @endif
                </label>
                @endforeach
            </div>
        </div>

        <div class="mb-6">
            <label class="flex items-center">
                <input type="checkbox" name="agree_terms" value="1" required class="mr-2">
                <span class="text-sm">I agree to the <a href="#" class="text-blue-600 hover:underline">terms and conditions</a></span>
            </label>
        </div>

        <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
            Proceed to Payment
        </button>
    </form>

    <div class="mt-6 bg-gray-50 rounded-lg p-4">
        <h3 class="font-semibold mb-2">Payment Information</h3>
        <ul class="text-sm text-gray-600 space-y-1">
            <li>✓ All payments are secure and encrypted</li>
            <li>✓ Funds are added instantly after confirmation</li>
            <li>✓ Bonus credits may apply for larger deposits</li>
            <li>✓ Contact support if you have any issues</li>
        </ul>
    </div>
</div>

@push('scripts')
<script>
let appliedCoupon = null;

async function validateCoupon() {
    const code = document.getElementById('couponCode').value.trim();
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    
    if (!code) {
        showCouponMessage('Please enter a coupon code', 'error');
        return;
    }
    
    if (!amount || amount < {{ $minAmount }}) {
        showCouponMessage('Please enter a valid amount first', 'error');
        return;
    }
    
    try {
        const response = await fetch('{{ route("api.validate-coupon") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ code, amount })
        });
        
        const data = await response.json();
        
        if (response.ok && data.valid) {
            appliedCoupon = data;
            showCouponMessage('✓ Coupon applied successfully!', 'success');
            document.getElementById('discountAmount').textContent = data.discount;
            document.getElementById('finalAmount').textContent = data.final_amount;
            document.getElementById('couponDiscount').classList.remove('hidden');
            document.getElementById('totalAmount').classList.remove('hidden');
        } else {
            showCouponMessage(data.error || 'Invalid coupon code', 'error');
            removeCoupon();
        }
    } catch (error) {
        showCouponMessage('Error validating coupon', 'error');
        removeCoupon();
    }
}

function removeCoupon() {
    appliedCoupon = null;
    document.getElementById('couponCode').value = '';
    document.getElementById('couponDiscount').classList.add('hidden');
    document.getElementById('totalAmount').classList.add('hidden');
    document.getElementById('couponMessage').textContent = '';
}

function showCouponMessage(message, type) {
    const messageEl = document.getElementById('couponMessage');
    messageEl.textContent = message;
    messageEl.className = 'mt-2 text-sm ' + (type === 'success' ? 'text-green-600' : 'text-red-600');
}

// Update total when amount changes
document.getElementById('paymentAmount').addEventListener('input', function() {
    if (appliedCoupon) {
        showCouponMessage('Amount changed. Please re-apply coupon', 'error');
        removeCoupon();
    }
});
</script>
@endpush
@endsection
