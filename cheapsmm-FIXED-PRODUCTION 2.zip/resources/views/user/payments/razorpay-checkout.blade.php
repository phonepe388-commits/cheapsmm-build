@extends('layouts.app')

@section('title', 'Complete Payment')

@section('content')
<div class="max-w-2xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Complete Your Payment</h1>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-center mb-6">
            <div class="text-gray-600 mb-2">Amount to Pay</div>
            <div class="text-4xl font-bold text-blue-600">${{ number_format($result['amount'] / 100, 2) }}</div>
        </div>

        <button id="rzp-button" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
            Pay with Razorpay
        </button>

        <div class="mt-4 text-center">
            <a href="{{ route('user.payments.create') }}" class="text-gray-600 hover:underline">Cancel</a>
        </div>
    </div>
</div>

<form id="razorpay-form" method="POST" action="{{ route('user.payments.razorpay.verify') }}" style="display: none;">
    @csrf
    <input type="hidden" name="razorpay_order_id" id="razorpay_order_id">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_signature" id="razorpay_signature">
</form>

@push('scripts')
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.getElementById('rzp-button').onclick = function(e) {
    e.preventDefault();
    
    var options = {
        "key": "{{ $result['key_id'] }}",
        "amount": "{{ $result['amount'] }}",
        "currency": "{{ $result['currency'] }}",
        "name": "{{ $result['name'] }}",
        "description": "{{ $result['description'] }}",
        "order_id": "{{ $result['order_id'] }}",
        "prefill": {
            "name": "{{ $result['prefill']['name'] }}",
            "email": "{{ $result['prefill']['email'] }}"
        },
        "theme": {
            "color": "#3b82f6"
        },
        "handler": function (response) {
            document.getElementById('razorpay_order_id').value = response.razorpay_order_id;
            document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
            document.getElementById('razorpay_signature').value = response.razorpay_signature;
            document.getElementById('razorpay-form').submit();
        }
    };
    
    var rzp = new Razorpay(options);
    rzp.open();
};
</script>
@endpush
@endsection
