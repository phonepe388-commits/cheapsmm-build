@extends('layouts.app')

@section('title', 'Payment Successful')

@section('content')
<div class="max-w-2xl mx-auto px-4">
    <div class="bg-white rounded-lg shadow-lg p-8 text-center">
        <div class="mb-6">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full">
                <i class="fas fa-check text-green-600 text-3xl"></i>
            </div>
        </div>

        <h1 class="text-3xl font-bold text-gray-800 mb-4">Payment Successful!</h1>
        <p class="text-gray-600 mb-6">Your payment has been processed successfully.</p>

        @if(isset($payment))
        <div class="bg-gray-50 rounded-lg p-6 mb-6">
            <div class="grid grid-cols-2 gap-4 text-left">
                <div>
                    <div class="text-sm text-gray-500">Transaction ID</div>
                    <div class="font-semibold">#{{ $payment->id }}</div>
                </div>
                <div>
                    <div class="text-sm text-gray-500">Amount</div>
                    <div class="font-semibold text-green-600">${{ number_format($payment->amount, 2) }}</div>
                </div>
                <div>
                    <div class="text-sm text-gray-500">Date</div>
                    <div class="font-semibold">{{ $payment->created_at->format('M d, Y H:i') }}</div>
                </div>
                <div>
                    <div class="text-sm text-gray-500">New Balance</div>
                    <div class="font-semibold">${{ number_format(auth()->user()->balance, 2) }}</div>
                </div>
            </div>
        </div>
        @endif

        <div class="space-y-3">
            <a href="{{ route('user.orders.create') }}" class="block w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
                Place New Order
            </a>
            <a href="{{ route('user.dashboard') }}" class="block w-full bg-gray-200 text-gray-800 py-3 rounded-lg font-semibold hover:bg-gray-300">
                Back to Dashboard
            </a>
        </div>
    </div>
</div>
@endsection
