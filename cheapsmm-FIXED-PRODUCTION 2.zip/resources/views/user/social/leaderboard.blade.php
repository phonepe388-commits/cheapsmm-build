@extends('layouts.app')
@section('title', 'Leaderboard')
@section('content')
<div class="max-w-7xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">🏆 Leaderboard</h1>
    
    <div class="grid md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-bold text-lg mb-4 text-yellow-600">🥇 Daily Top Spenders</h3>
            @foreach($daily as $index => $user)
            <div class="flex justify-between py-2 border-b">
                <div>
                    <span class="font-bold mr-2">#{{ $index + 1 }}</span>
                    <span>{{ $user['name'] }}</span>
                </div>
                <span class="font-semibold text-green-600">${{ number_format($user['orders_sum_charge'] ?? 0, 2) }}</span>
            </div>
            @endforeach
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-bold text-lg mb-4 text-blue-600">🥈 Weekly Top Spenders</h3>
            @foreach($weekly as $index => $user)
            <div class="flex justify-between py-2 border-b">
                <div>
                    <span class="font-bold mr-2">#{{ $index + 1 }}</span>
                    <span>{{ $user['name'] }}</span>
                </div>
                <span class="font-semibold text-green-600">${{ number_format($user['orders_sum_charge'] ?? 0, 2) }}</span>
            </div>
            @endforeach
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-bold text-lg mb-4 text-purple-600">🥉 All-Time Top Spenders</h3>
            @foreach($monthly as $index => $user)
            <div class="flex justify-between py-2 border-b">
                <div>
                    <span class="font-bold mr-2">#{{ $index + 1 }}</span>
                    <span>{{ $user['name'] }}</span>
                </div>
                <span class="font-semibold text-green-600">${{ number_format($user['orders_sum_charge'] ?? 0, 2) }}</span>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
