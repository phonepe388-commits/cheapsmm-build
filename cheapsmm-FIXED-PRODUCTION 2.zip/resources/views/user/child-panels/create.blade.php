@extends('layouts.app')

@section('title', 'Create Child Panel')

@section('content')
<div class="max-w-3xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Create New Child Panel</h1>

    <form method="POST" action="{{ route('user.child-panels.store') }}">
        @csrf

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Basic Information</h3>

            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Panel Name *</label>
                <input type="text" name="name" required value="{{ old('name') }}"
                    class="w-full border rounded px-3 py-2 @error('name') border-red-500 @enderror"
                    placeholder="My SMM Panel">
                @error('name')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Custom Domain</label>
                    <input type="text" name="domain" value="{{ old('domain') }}"
                        class="w-full border rounded px-3 py-2"
                        placeholder="panel.yourdomain.com">
                    <p class="text-xs text-gray-500 mt-1">Optional - Point your domain to our server</p>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Subdomain</label>
                    <div class="flex">
                        <input type="text" name="subdomain" value="{{ old('subdomain') }}"
                            class="flex-1 border rounded-l px-3 py-2"
                            placeholder="mypanel">
                        <span class="bg-gray-100 border-t border-b border-r px-3 py-2 rounded-r text-sm">
                            .cheapsmm.fun
                        </span>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Leave empty for auto-generation</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Pricing & Limits</h3>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Markup Percentage *</label>
                    <div class="flex">
                        <input type="number" name="markup_percentage" step="0.01" min="0" max="100" 
                            required value="{{ old('markup_percentage', 20) }}"
                            class="flex-1 border rounded-l px-3 py-2">
                        <span class="bg-gray-100 border-t border-b border-r px-3 py-2 rounded-r">%</span>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Your profit margin on all services</p>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Credit Limit ($)</label>
                    <input type="number" name="credit_limit" step="0.01" min="0" 
                        value="{{ old('credit_limit', 0) }}"
                        class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Allow negative balance up to this limit</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold mb-4">Contact Information</h3>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold mb-2">Support Email</label>
                    <input type="email" name="support_email" value="{{ old('support_email') }}"
                        class="w-full border rounded px-3 py-2">
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-2">Currency</label>
                    <select name="currency" class="w-full border rounded px-3 py-2">
                        <option value="USD">USD - US Dollar</option>
                        <option value="EUR">EUR - Euro</option>
                        <option value="GBP">GBP - British Pound</option>
                        <option value="INR">INR - Indian Rupee</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h4 class="font-semibold mb-2">📌 Important Notes</h4>
            <ul class="text-sm text-gray-700 space-y-1">
                <li>• You can customize branding, colors, and logo after creation</li>
                <li>• Service pricing can be adjusted individually later</li>
                <li>• You need to add balance to your child panel before users can place orders</li>
                <li>• Markup is applied to all services automatically</li>
            </ul>
        </div>

        <div class="flex gap-3">
            <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded font-semibold hover:bg-blue-700">
                Create Child Panel
            </button>
            <a href="{{ route('user.child-panels.index') }}" 
               class="bg-gray-200 px-6 py-3 rounded font-semibold hover:bg-gray-300">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection
