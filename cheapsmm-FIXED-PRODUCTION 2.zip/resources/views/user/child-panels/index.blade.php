@extends('layouts.app')

@section('title', 'My Child Panels')

@section('content')
<div class="max-w-7xl mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">My Child Panels</h1>
        <a href="{{ route('user.child-panels.create') }}" 
           class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            + Create Child Panel
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
        <h3 class="font-semibold text-lg mb-2">🎯 What are Child Panels?</h3>
        <p class="text-sm text-gray-700 mb-3">
            Create your own white-labeled SMM panel and sell services to your customers with your own branding and pricing!
        </p>
        <div class="grid md:grid-cols-3 gap-4 text-sm">
            <div>
                <strong>✅ Your Own Domain</strong>
                <p class="text-gray-600">Use your custom domain or subdomain</p>
            </div>
            <div>
                <strong>✅ Custom Pricing</strong>
                <p class="text-gray-600">Set your own markup and profit margins</p>
            </div>
            <div>
                <strong>✅ Full Branding</strong>
                <p class="text-gray-600">Logo, colors, and custom footer</p>
            </div>
        </div>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($panels as $panel)
        <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-bold">{{ $panel->name }}</h3>
                    @if($panel->status === 'active')
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                    @else
                        <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">Inactive</span>
                    @endif
                </div>

                <div class="space-y-2 text-sm mb-4">
                    <div class="flex justify-between">
                        <span class="text-gray-600">URL:</span>
                        <a href="{{ $panel->getUrl() }}" target="_blank" 
                           class="text-blue-600 hover:underline">
                            {{ $panel->domain ?: $panel->subdomain }}
                        </a>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Balance:</span>
                        <span class="font-semibold">${{ number_format($panel->balance, 2) }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Users:</span>
                        <span>{{ $panel->child_users_count }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Orders:</span>
                        <span>{{ $panel->orders_count }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Markup:</span>
                        <span>{{ $panel->markup_percentage }}%</span>
                    </div>
                </div>

                <div class="flex gap-2">
                    <a href="{{ route('user.child-panels.show', $panel) }}" 
                       class="flex-1 bg-blue-600 text-white text-center py-2 rounded hover:bg-blue-700 text-sm">
                        Manage
                    </a>
                    <a href="{{ route('user.child-panels.edit', $panel) }}" 
                       class="flex-1 bg-gray-200 text-center py-2 rounded hover:bg-gray-300 text-sm">
                        Edit
                    </a>
                </div>
            </div>
        </div>
        @empty
        <div class="col-span-full bg-white rounded-lg shadow p-12 text-center">
            <div class="text-6xl mb-4">🏢</div>
            <h3 class="text-xl font-bold mb-2">No Child Panels Yet</h3>
            <p class="text-gray-600 mb-4">Create your first child panel and start your reseller business!</p>
            <a href="{{ route('user.child-panels.create') }}" 
               class="inline-block bg-blue-600 text-white px-6 py-3 rounded hover:bg-blue-700">
                Create Your First Panel
            </a>
        </div>
        @endforelse
    </div>
</div>
@endsection
