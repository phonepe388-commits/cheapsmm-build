@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="max-w-7xl mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Welcome back, {{ auth()->user()->name }}!</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 mb-2">Current Balance</div>
            <div class="text-3xl font-bold text-green-600">${{ number_format(auth()->user()->balance, 2) }}</div>
            <a href="{{ route('user.payments.create') }}" class="text-blue-600 hover:underline text-sm">Add Funds</a>
        </div>

        <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 mb-2">Total Orders</div>
            <div class="text-3xl font-bold">{{ auth()->user()->orders()->count() }}</div>
            <a href="{{ route('user.orders.index') }}" class="text-blue-600 hover:underline text-sm">View All</a>
        </div>

        <div class="bg-white p-6 rounded-lg shadow">
            <div class="text-gray-500 mb-2">Pending Orders</div>
            <div class="text-3xl font-bold">{{ auth()->user()->orders()->where('status', 'pending')->count() }}</div>
            <a href="{{ route('user.orders.index', ['status' => 'pending']) }}" class="text-blue-600 hover:underline text-sm">View Pending</a>
        </div>
    </div>

    <div class="bg-white p-6 rounded-lg shadow">
        <h2 class="text-xl font-semibold mb-4">Quick Actions</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <a href="{{ route('user.orders.create') }}" class="block p-4 border-2 border-blue-600 rounded-lg hover:bg-blue-50 text-center">
                <i class="fas fa-plus-circle text-3xl text-blue-600 mb-2"></i>
                <div class="font-semibold">New Order</div>
            </a>
            <a href="{{ route('user.payments.create') }}" class="block p-4 border-2 border-green-600 rounded-lg hover:bg-green-50 text-center">
                <i class="fas fa-wallet text-3xl text-green-600 mb-2"></i>
                <div class="font-semibold">Add Funds</div>
            </a>
            <a href="{{ route('user.orders.index') }}" class="block p-4 border-2 border-purple-600 rounded-lg hover:bg-purple-50 text-center">
                <i class="fas fa-list text-3xl text-purple-600 mb-2"></i>
                <div class="font-semibold">Order History</div>
            </a>
            <a href="{{ route('user.tickets.create') }}" class="block p-4 border-2 border-red-600 rounded-lg hover:bg-red-50 text-center">
                <i class="fas fa-headset text-3xl text-red-600 mb-2"></i>
                <div class="font-semibold">Get Support</div>
            </a>
        </div>
    </div>
</div>
@endsection
