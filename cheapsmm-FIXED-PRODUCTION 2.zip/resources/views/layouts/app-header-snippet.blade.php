<!-- Add to navbar, after user menu -->
<div class="ml-4">
    @include('components.currency-selector')
</div>
