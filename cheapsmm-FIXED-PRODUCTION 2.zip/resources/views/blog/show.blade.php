@extends('layouts.app')
@section('title', $blog->title)
@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <article>
        @if($blog->featured_image)
        <img src="{{ $blog->featured_image }}" alt="{{ $blog->title }}" class="w-full h-64 object-cover rounded-lg mb-6">
        @endif
        
        <h1 class="text-4xl font-bold mb-4">{{ $blog->title }}</h1>
        
        <div class="flex items-center text-gray-600 mb-8">
            <span>{{ $blog->created_at->format('F d, Y') }}</span>
            <span class="mx-2">•</span>
            <span>{{ $blog->views }} views</span>
        </div>
        
        <div class="prose max-w-none">
            {!! nl2br(e($blog->content)) !!}
        </div>
    </article>
    
    <div class="mt-12 pt-8 border-t">
        <a href="{{ route('blog.index') }}" class="text-blue-600 hover:text-blue-800">← Back to Blog</a>
    </div>
</div>
@endsection
