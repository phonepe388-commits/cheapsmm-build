@extends('layouts.app')
@section('title', 'API Documentation')
@section('content')
<div class="max-w-6xl mx-auto px-4 py-8">
    <h1 class="text-4xl font-bold mb-2">API Documentation</h1>
    <p class="text-gray-600 mb-8">Complete guide to integrate with {{ config('app.name') }} API</p>

    <!-- Authentication -->
    <div class="bg-white rounded-lg shadow mb-6 overflow-hidden">
        <div class="bg-gray-800 text-white px-6 py-4">
            <h2 class="text-2xl font-bold">Authentication</h2>
        </div>
        <div class="p-6">
            <p class="mb-4">All API requests require authentication via API key. Include your API key in the request:</p>
            <div class="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm overflow-x-auto">
                <div>// Via header (recommended)</div>
                <div>X-API-Key: your_api_key_here</div>
                <div class="mt-3">// Via query parameter</div>
                <div>?api_key=your_api_key_here</div>
            </div>
            <div class="mt-4 bg-blue-50 border-l-4 border-blue-600 p-4">
                <p class="font-semibold">Base URL:</p>
                <code class="text-sm">{{ config('app.url') }}/api/v2</code>
            </div>
            <div class="mt-4 bg-yellow-50 border-l-4 border-yellow-600 p-4">
                <p class="font-semibold">Rate Limit:</p>
                <p class="text-sm">1000 requests per hour</p>
            </div>
        </div>
    </div>

    <!-- Endpoints -->
    @foreach([
        ['name' => 'Balance', 'method' => 'GET', 'endpoint' => '/balance', 'desc' => 'Get account balance'],
        ['name' => 'Services', 'method' => 'GET', 'endpoint' => '/services', 'desc' => 'List all available services'],
        ['name' => 'Add Order', 'method' => 'POST', 'endpoint' => '/add', 'desc' => 'Place a new order'],
        ['name' => 'Order Status', 'method' => 'GET', 'endpoint' => '/status', 'desc' => 'Get order status'],
        ['name' => 'Multiple Orders', 'method' => 'POST', 'endpoint' => '/add-multi', 'desc' => 'Place multiple orders'],
        ['name' => 'Orders List', 'method' => 'GET', 'endpoint' => '/orders', 'desc' => 'Get list of orders'],
        ['name' => 'Refill', 'method' => 'POST', 'endpoint' => '/refill', 'desc' => 'Request order refill'],
        ['name' => 'Cancel', 'method' => 'POST', 'endpoint' => '/cancel', 'desc' => 'Cancel pending order'],
    ] as $api)
    <div class="bg-white rounded-lg shadow mb-4 overflow-hidden">
        <div class="px-6 py-4 bg-gray-50 border-b flex items-center justify-between">
            <div>
                <h3 class="text-xl font-bold">{{ $api['name'] }}</h3>
                <p class="text-sm text-gray-600">{{ $api['desc'] }}</p>
            </div>
            <span class="px-3 py-1 rounded font-mono text-sm
                {{ $api['method'] === 'GET' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800' }}">
                {{ $api['method'] }}
            </span>
        </div>
        <div class="p-6">
            <div class="mb-4">
                <div class="text-sm text-gray-600 mb-1">Endpoint:</div>
                <code class="bg-gray-100 px-3 py-1 rounded">{{ $api['endpoint'] }}</code>
            </div>
            
            @if($api['endpoint'] === '/balance')
            <div class="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
                <div>// Response</div>
                <div>{</div>
                <div class="ml-4">"balance": "150.25",</div>
                <div class="ml-4">"currency": "USD"</div>
                <div>}</div>
            </div>
            @endif

            @if($api['endpoint'] === '/add')
            <div class="mb-4">
                <div class="text-sm text-gray-600 mb-2">Parameters:</div>
                <table class="min-w-full border text-sm">
                    <tr class="border-b bg-gray-50">
                        <th class="px-3 py-2 text-left">Parameter</th>
                        <th class="px-3 py-2 text-left">Type</th>
                        <th class="px-3 py-2 text-left">Description</th>
                    </tr>
                    <tr class="border-b">
                        <td class="px-3 py-2 font-mono">service</td>
                        <td class="px-3 py-2">integer</td>
                        <td class="px-3 py-2">Service ID</td>
                    </tr>
                    <tr class="border-b">
                        <td class="px-3 py-2 font-mono">link</td>
                        <td class="px-3 py-2">string</td>
                        <td class="px-3 py-2">Link to page/post/profile</td>
                    </tr>
                    <tr class="border-b">
                        <td class="px-3 py-2 font-mono">quantity</td>
                        <td class="px-3 py-2">integer</td>
                        <td class="px-3 py-2">Order quantity</td>
                    </tr>
                </table>
            </div>
            <div class="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
                <div>// Example Request</div>
                <div>POST /api/v2/add</div>
                <div>{</div>
                <div class="ml-4">"service": 123,</div>
                <div class="ml-4">"link": "https://instagram.com/username",</div>
                <div class="ml-4">"quantity": 1000</div>
                <div>}</div>
                <div class="mt-3">// Response</div>
                <div>{</div>
                <div class="ml-4">"order": 54321</div>
                <div>}</div>
            </div>
            @endif
        </div>
    </div>
    @endforeach

    <!-- Code Examples -->
    <div class="bg-white rounded-lg shadow mb-6">
        <div class="bg-gray-800 text-white px-6 py-4">
            <h2 class="text-2xl font-bold">Code Examples</h2>
        </div>
        <div class="p-6">
            <h3 class="font-bold mb-2">PHP Example:</h3>
            <div class="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm overflow-x-auto mb-4">
                <pre>$apiKey = 'your_api_key_here';
$url = '{{ config("app.url") }}/api/v2/add';

$data = [
    'service' => 123,
    'link' => 'https://instagram.com/username',
    'quantity' => 1000
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-Key: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
echo "Order ID: " . $result['order'];</pre>
            </div>

            <h3 class="font-bold mb-2">JavaScript Example:</h3>
            <div class="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm overflow-x-auto">
                <pre>const apiKey = 'your_api_key_here';
const url = '{{ config("app.url") }}/api/v2/add';

const data = {
    service: 123,
    link: 'https://instagram.com/username',
    quantity: 1000
};

fetch(url, {
    method: 'POST',
    headers: {
        'X-API-Key': apiKey,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
})
.then(response => response.json())
.then(result => {
    console.log('Order ID:', result.order);
});</pre>
            </div>
        </div>
    </div>

    <!-- Error Codes -->
    <div class="bg-white rounded-lg shadow">
        <div class="bg-gray-800 text-white px-6 py-4">
            <h2 class="text-2xl font-bold">Error Codes</h2>
        </div>
        <div class="p-6">
            <table class="min-w-full text-sm">
                <tr class="border-b">
                    <td class="py-2 font-mono">401</td>
                    <td class="py-2">Invalid API key</td>
                </tr>
                <tr class="border-b">
                    <td class="py-2 font-mono">400</td>
                    <td class="py-2">Invalid parameters</td>
                </tr>
                <tr class="border-b">
                    <td class="py-2 font-mono">429</td>
                    <td class="py-2">Rate limit exceeded</td>
                </tr>
                <tr class="border-b">
                    <td class="py-2 font-mono">500</td>
                    <td class="py-2">Server error</td>
                </tr>
            </table>
        </div>
    </div>
</div>
@endsection
