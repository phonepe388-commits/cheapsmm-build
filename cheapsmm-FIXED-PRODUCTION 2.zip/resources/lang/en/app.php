<?php

return [
    // Navigation
    'dashboard' => 'Dashboard',
    'orders' => 'Orders',
    'services' => 'Services',
    'payments' => 'Payments',
    'tickets' => 'Support Tickets',
    'referrals' => 'Referrals',
    'api' => 'API',
    
    // Common
    'welcome' => 'Welcome',
    'home' => 'Home',
    'logout' => 'Logout',
    'login' => 'Login',
    'register' => 'Register',
    'email' => 'Email',
    'password' => 'Password',
    'submit' => 'Submit',
    'cancel' => 'Cancel',
    'save' => 'Save',
    'delete' => 'Delete',
    'edit' => 'Edit',
    'view' => 'View',
    'search' => 'Search',
    'filter' => 'Filter',
    'export' => 'Export',
    'actions' => 'Actions',
    'status' => 'Status',
    'date' => 'Date',
    'amount' => 'Amount',
    'total' => 'Total',
    'balance' => 'Balance',
    
    // Dashboard
    'total_orders' => 'Total Orders',
    'pending_orders' => 'Pending Orders',
    'completed_orders' => 'Completed Orders',
    'total_spent' => 'Total Spent',
    'recent_orders' => 'Recent Orders',
    
    // Orders
    'new_order' => 'New Order',
    'mass_order' => 'Mass Order',
    'order_id' => 'Order ID',
    'service' => 'Service',
    'link' => 'Link',
    'quantity' => 'Quantity',
    'charge' => 'Charge',
    'place_order' => 'Place Order',
    
    // Payments
    'add_funds' => 'Add Funds',
    'payment_method' => 'Payment Method',
    'transaction_id' => 'Transaction ID',
    'payment_history' => 'Payment History',
    
    // Tickets
    'create_ticket' => 'Create Ticket',
    'ticket_subject' => 'Subject',
    'ticket_message' => 'Message',
    'ticket_status' => 'Status',
    
    // Status values
    'active' => 'Active',
    'inactive' => 'Inactive',
    'pending' => 'Pending',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    'processing' => 'Processing',
    
    // Messages
    'success' => 'Success!',
    'error' => 'Error!',
    'created_successfully' => 'Created successfully!',
    'updated_successfully' => 'Updated successfully!',
    'deleted_successfully' => 'Deleted successfully!',
    'insufficient_balance' => 'Insufficient balance',
    
    // Referrals
    'referral_link' => 'Referral Link',
    'total_referrals' => 'Total Referrals',
    'total_earned' => 'Total Earned',
    'withdraw_earnings' => 'Withdraw Earnings',
];
