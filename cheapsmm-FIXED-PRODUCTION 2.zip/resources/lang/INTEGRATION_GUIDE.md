# Multi-Language Integration Guide

## Quick Start

### 1. Add Language Switcher to Layout

Add to your main layout file (e.g., `layouts/app.blade.php`):

```blade
<!-- In navigation or header -->
@include('components.language-switcher')
```

### 2. Using Translations in Views

Replace hard-coded text with translation keys:

```blade
<!-- Before -->
<h1>Dashboard</h1>
<button>New Order</button>

<!-- After -->
<h1>{{ __('app.dashboard') }}</h1>
<button>{{ __('app.new_order') }}</button>
```

### 3. Using Translations in Controllers

```php
return redirect()->back()->with('success', __('app.created_successfully'));
```

## Available Translation Keys

All keys are in `resources/lang/{locale}/app.php`

### Navigation
- `app.dashboard`
- `app.orders`
- `app.services`
- `app.payments`
- `app.tickets`
- `app.referrals`
- `app.api`

### Common Actions
- `app.submit`
- `app.cancel`
- `app.save`
- `app.delete`
- `app.edit`
- `app.view`

### Status Values
- `app.active`
- `app.inactive`
- `app.pending`
- `app.completed`
- `app.cancelled`

### Messages
- `app.success`
- `app.error`
- `app.created_successfully`
- `app.updated_successfully`

## Adding New Languages

1. Create new folder: `resources/lang/CODE/`
2. Copy `en/app.php` to new folder
3. Translate all values
4. Add to `config/languages.php`
5. Add to middleware's `$locales` array

## Adding New Translation Keys

1. Add to `resources/lang/en/app.php`:
```php
'my_new_key' => 'My English Text',
```

2. Add to all other language files with translations

3. Use in views:
```blade
{{ __('app.my_new_key') }}
```

## RTL Support

For RTL languages (Arabic), add to your layout:

```blade
<html dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
```

## Testing

To test different languages:
1. Click language switcher dropdown
2. Select a language
3. All text should update immediately
4. Language preference is saved for logged-in users

## Supported Languages

✅ English (en) - English  
✅ Spanish (es) - Español  
✅ French (fr) - Français  
✅ German (de) - Deutsch  
✅ Portuguese (pt) - Português  
✅ Arabic (ar) - العربية  
✅ Hindi (hi) - हिन्दी  
✅ Chinese (zh) - 中文  
✅ Japanese (ja) - 日本語  
✅ Russian (ru) - Русский  
