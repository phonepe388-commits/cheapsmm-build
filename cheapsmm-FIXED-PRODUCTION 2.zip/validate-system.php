<?php
/**
 * CheapSMM Panel - System Validation Script
 * Checks all files, structure, and potential issues
 */

class SystemValidator {
    private $errors = [];
    private $warnings = [];
    private $passed = 0;
    
    public function validate() {
        echo "\n========================================\n";
        echo "CHEAPSMM PANEL - SYSTEM VALIDATION\n";
        echo "========================================\n\n";
        
        $this->checkDirectoryStructure();
        $this->checkModels();
        $this->checkControllers();
        $this->checkViews();
        $this->checkRoutes();
        $this->checkDatabase();
        $this->checkConfiguration();
        $this->checkPermissions();
        
        $this->displayResults();
    }
    
    private function checkDirectoryStructure() {
        echo "[1/8] Checking directory structure...\n";
        $required = [
            'app/Models', 'app/Http/Controllers', 'app/Services',
            'app/Jobs', 'resources/views', 'routes', 'public',
            'storage/logs', 'database', 'config'
        ];
        
        foreach ($required as $dir) {
            if (is_dir($dir)) {
                $this->passed++;
            } else {
                $this->errors[] = "Missing directory: $dir";
            }
        }
    }
    
    private function checkModels() {
        echo "[2/8] Checking models...\n";
        $required = [
            'User', 'Order', 'Service', 'Category', 'Payment',
            'Ticket', 'ApiProvider', 'Transaction', 'Setting'
        ];
        
        foreach ($required as $model) {
            $file = "app/Models/$model.php";
            if (file_exists($file)) {
                $this->passed++;
                // Check for syntax errors
                $content = file_get_contents($file);
                if (strpos($content, 'class ' . $model) === false) {
                    $this->warnings[] = "Model $model may have incorrect class name";
                }
            } else {
                $this->errors[] = "Missing model: $model";
            }
        }
    }
    
    private function checkControllers() {
        echo "[3/8] Checking controllers...\n";
        $required = [
            'Auth/LoginController',
            'Auth/RegisterController',
            'User/DashboardController',
            'User/OrderController',
            'User/ServiceController',
            'Admin/DashboardController',
            'Admin/UserController'
        ];
        
        foreach ($required as $controller) {
            $file = "app/Http/Controllers/$controller.php";
            if (file_exists($file)) {
                $this->passed++;
            } else {
                $this->warnings[] = "Missing controller: $controller";
            }
        }
    }
    
    private function checkViews() {
        echo "[4/8] Checking views...\n";
        $required = [
            'user/dashboard.blade.php',
            'user/orders/create.blade.php',
            'user/orders/index.blade.php'
        ];
        
        foreach ($required as $view) {
            $file = "resources/views/$view";
            if (file_exists($file)) {
                $this->passed++;
            } else {
                $this->warnings[] = "Missing view: $view";
            }
        }
    }
    
    private function checkRoutes() {
        echo "[5/8] Checking routes...\n";
        if (file_exists('routes/web.php')) {
            $this->passed++;
            $content = file_get_contents('routes/web.php');
            if (strpos($content, 'user.orders') === false) {
                $this->warnings[] = "Routes file may be incomplete";
            }
        } else {
            $this->errors[] = "Missing routes/web.php";
        }
    }
    
    private function checkDatabase() {
        echo "[6/8] Checking database files...\n";
        if (file_exists('database/STEP-01-database.sql')) {
            $this->passed++;
        } else {
            $this->warnings[] = "Missing database file (Part 1)";
        }
        
        if (file_exists('database/STEP-01-database-part2.sql')) {
            $this->passed++;
        } else {
            $this->warnings[] = "Missing database file (Part 2)";
        }
    }
    
    private function checkConfiguration() {
        echo "[7/8] Checking configuration files...\n";
        if (file_exists('.env.example')) {
            $this->passed++;
        } else {
            $this->errors[] = "Missing .env.example";
        }
        
        if (file_exists('composer.json')) {
            $this->passed++;
        } else {
            $this->errors[] = "Missing composer.json";
        }
    }
    
    private function checkPermissions() {
        echo "[8/8] Checking file permissions...\n";
        $writable = ['storage', 'bootstrap/cache'];
        
        foreach ($writable as $dir) {
            if (is_dir($dir) && is_writable($dir)) {
                $this->passed++;
            } else {
                $this->warnings[] = "Directory not writable: $dir";
            }
        }
    }
    
    private function displayResults() {
        echo "\n========================================\n";
        echo "VALIDATION RESULTS\n";
        echo "========================================\n\n";
        
        echo "✅ Passed: " . $this->passed . " checks\n";
        echo "⚠️  Warnings: " . count($this->warnings) . "\n";
        echo "❌ Errors: " . count($this->errors) . "\n\n";
        
        if (count($this->errors) > 0) {
            echo "ERRORS:\n";
            foreach ($this->errors as $error) {
                echo "  ❌ $error\n";
            }
            echo "\n";
        }
        
        if (count($this->warnings) > 0) {
            echo "WARNINGS:\n";
            foreach ($this->warnings as $warning) {
                echo "  ⚠️  $warning\n";
            }
            echo "\n";
        }
        
        if (count($this->errors) === 0) {
            echo "========================================\n";
            echo "✅ VALIDATION PASSED!\n";
            echo "System is ready for packaging!\n";
            echo "========================================\n\n";
            return 0;
        } else {
            echo "========================================\n";
            echo "❌ VALIDATION FAILED\n";
            echo "Please fix errors above\n";
            echo "========================================\n\n";
            return 1;
        }
    }
}

$validator = new SystemValidator();
exit($validator->validate());
