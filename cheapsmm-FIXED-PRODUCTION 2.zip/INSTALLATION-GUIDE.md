# 📘 CheapSMM Panel - Complete Installation Guide

**Version:** 100% Complete Edition  
**Date:** March 23, 2026  
**Requirements:** PHP 8.2+, MariaDB 10.11+, Apache/Nginx  

---

## 🎯 **PRE-INSTALLATION REQUIREMENTS**

### **Server Requirements:**
- PHP 8.2 or higher
- MariaDB 10.11 or MySQL 8.0+
- Apache 2.4+ with mod_rewrite OR Nginx
- Composer 2.x
- Node.js 18+ & NPM (for frontend assets)
- PHP Extensions:
  - BCMath
  - Ctype
  - JSON
  - Mbstring
  - OpenSSL
  - PDO MySQL
  - Tokenizer
  - XML
  - cURL
  - GD or Imagick
  - Zip

### **Recommended Server Specs:**
- CPU: 2+ cores
- RAM: 2GB minimum, 4GB recommended
- Storage: 10GB+ SSD
- Bandwidth: Unmetered

---

## 📦 **STEP 1: UPLOAD FILES**

### **Option A: Via cPanel File Manager**
1. Login to cPanel
2. Navigate to File Manager
3. Go to `public_html` directory
4. Upload `cheapsmm-COMPLETE-SYSTEM.zip`
5. Extract the ZIP file
6. Move all files from extracted folder to `public_html` root

### **Option B: Via FTP**
1. Connect via FTP client (FileZilla recommended)
2. Upload all project files to `/public_html/` or `/home/username/`
3. Set proper permissions (see Step 6)

### **Option C: Via SSH**
```bash
cd /path/to/public_html
wget https://yourserver.com/cheapsmm-COMPLETE-SYSTEM.zip
unzip cheapsmm-COMPLETE-SYSTEM.zip
mv cheapsmm-panel-PRODUCTION-READY/* .
rm -rf cheapsmm-panel-PRODUCTION-READY
```

---

## 🗄️ **STEP 2: CREATE DATABASE**

### **Via cPanel:**
1. Go to **MySQL Databases**
2. Create database: `cheapsmm_db`
3. Create user: `cheapsmm_user`
4. Set strong password
5. Add user to database with ALL PRIVILEGES
6. Note: database name, username, password

### **Via phpMyAdmin:**
1. Click **New** to create database
2. Name it `cheapsmm_db` with `utf8mb4_unicode_ci` collation
3. Go to Users → Add user account
4. Grant all privileges

### **Via SSH:**
```bash
mysql -u root -p

CREATE DATABASE cheapsmm_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'cheapsmm_user'@'localhost' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON cheapsmm_db.* TO 'cheapsmm_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## 📊 **STEP 3: IMPORT DATABASE**

### **Import the complete schema:**

#### **Via phpMyAdmin:**
1. Select `cheapsmm_db` database
2. Click **Import** tab
3. Choose file: `database/COMPLETE-DATABASE-SCHEMA.sql`
4. Click **Go**
5. Wait for success message

#### **Via SSH:**
```bash
mysql -u cheapsmm_user -p cheapsmm_db < database/COMPLETE-DATABASE-SCHEMA.sql
```

**✅ This creates all 50+ tables with default data including:**
- Admin account (admin@cheapsmm.fun / admin123)
- Payment methods
- Currencies
- Languages

---

## ⚙️ **STEP 4: CONFIGURE ENVIRONMENT**

### **Copy and edit .env file:**
```bash
cp .env.example .env
nano .env  # or use cPanel File Manager editor
```

### **Critical .env Settings:**

```env
APP_NAME="CheapSMM"
APP_ENV=production
APP_KEY=  # Will generate in Step 5
APP_DEBUG=false
APP_URL=https://cheapsmm.fun

# Database Configuration
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cheapsmm_db
DB_USERNAME=cheapsmm_user
DB_PASSWORD=your_database_password

# Mail Configuration (SMTP)
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@cheapsmm.fun
MAIL_FROM_NAME="${APP_NAME}"

# Payment Gateways
STRIPE_KEY=pk_test_xxxxxxxxxxxx
STRIPE_SECRET=sk_test_xxxxxxxxxxxx

PAYPAL_MODE=sandbox  # Change to 'live' in production
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_SECRET=your_paypal_secret

RAZORPAY_KEY=your_razorpay_key
RAZORPAY_SECRET=your_razorpay_secret

# Exchange Rate API (for multi-currency)
EXCHANGE_RATE_API_KEY=your_exchangerate_api_key
# Get free key from: https://www.exchangerate-api.com/

# Crypto Wallet Addresses (for crypto payments)
CRYPTO_BTC_ADDRESS=your_btc_wallet_address
CRYPTO_ETH_ADDRESS=your_eth_wallet_address
CRYPTO_USDT_ADDRESS=your_usdt_wallet_address
CRYPTO_BNB_ADDRESS=your_bnb_wallet_address

# Session & Cache
SESSION_DRIVER=file
CACHE_DRIVER=file
QUEUE_CONNECTION=database

# Security
SESSION_LIFETIME=120
SESSION_SECURE_COOKIE=true  # Set false for local testing
```

---

## 🔑 **STEP 5: INSTALL DEPENDENCIES & GENERATE KEY**

### **Install Composer Dependencies:**
```bash
cd /path/to/project
composer install --optimize-autoloader --no-dev
```

### **Generate Application Key:**
```bash
php artisan key:generate
```

**This will update your .env file with APP_KEY**

### **Install NPM Dependencies (Optional - for asset compilation):**
```bash
npm install
npm run build
```

---

## 📁 **STEP 6: SET PERMISSIONS**

### **Critical directories must be writable:**

#### **Via SSH:**
```bash
chmod -R 755 storage bootstrap/cache
chmod -R 775 storage/logs
chmod -R 775 storage/framework/{sessions,views,cache}
chmod -R 775 storage/app/{public,backups,exports}

# If using Apache
chown -R www-data:www-data storage bootstrap/cache

# If using Nginx
chown -R nginx:nginx storage bootstrap/cache
```

#### **Via cPanel File Manager:**
- Right-click `storage` folder → Change Permissions → 755
- Right-click `bootstrap/cache` → Change Permissions → 755

---

## 🌐 **STEP 7: CONFIGURE WEB SERVER**

### **Option A: Apache (.htaccess already included)**

**Ensure mod_rewrite is enabled:**
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

**Document Root should point to `/public` directory**

### **Option B: Nginx**

Add this to your Nginx config:

```nginx
server {
    listen 80;
    server_name cheapsmm.fun www.cheapsmm.fun;
    root /path/to/cheapsmm-panel-PRODUCTION-READY/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

Then reload Nginx:
```bash
sudo systemctl reload nginx
```

---

## ⏰ **STEP 8: CONFIGURE CRON JOBS**

### **Critical for automation!**

#### **Via cPanel:**
1. Go to **Cron Jobs**
2. Add new cron:
   - Minute: `*`
   - Hour: `*`
   - Day: `*`
   - Month: `*`
   - Weekday: `*`
   - Command: `cd /home/username/public_html && php artisan schedule:run >> /dev/null 2>&1`
3. Click **Add New Cron Job**

#### **Via SSH:**
```bash
crontab -e

# Add this line:
* * * * * cd /path/to/project && php artisan schedule:run >> /dev/null 2>&1
```

**This enables:**
- Order status checking (every 5 min)
- Dripfeed processing (every 10 min)
- Exchange rate updates (every 6 hours)
- Daily statistics (daily at 12:30 AM)
- Low balance alerts (daily at 9 AM)
- User cleanup (weekly)
- Automated backups (daily at 3 AM)

---

## 🔒 **STEP 9: SSL CERTIFICATE (HTTPS)**

### **Via cPanel (Let's Encrypt - Free):**
1. Go to **SSL/TLS Status**
2. Click **Run AutoSSL**
3. Wait for certificate installation
4. Update `APP_URL` in `.env` to use `https://`

### **Via Certbot (SSH):**
```bash
sudo certbot --nginx -d cheapsmm.fun -d www.cheapsmm.fun
```

**After SSL is installed:**
- Update `.env`: `SESSION_SECURE_COOKIE=true`
- Force HTTPS in `.htaccess` (already configured)

---

## 🧪 **STEP 10: TEST INSTALLATION**

### **1. Access Your Site:**
Visit: `https://yourdomain.com`

### **2. Login to Admin Panel:**
URL: `https://yourdomain.com/admin/login`
- Email: `admin@cheapsmm.fun`
- Password: `admin123`

**⚠️ CHANGE THIS PASSWORD IMMEDIATELY!**

### **3. Test User Registration:**
- Register a new user account
- Check email delivery
- Login with test account

### **4. Verify Cron Jobs:**
```bash
php artisan schedule:list
```

You should see all 7 scheduled jobs

### **5. Test Payment Gateways:**
- Add funds using test mode
- Verify Stripe test payments work
- Check PayPal sandbox

---

## 🎨 **STEP 11: CUSTOMIZE YOUR PANEL**

### **1. Admin Settings:**
- Go to Admin → Settings
- Update site name, logo, contact details
- Configure payment gateways (live mode)
- Set default currency & language

### **2. Add Services:**
- Admin → Services → Add New Service
- Configure API providers
- Set pricing per 1000

### **3. Payment Gateway Setup:**

#### **Stripe (Live Mode):**
1. Get live keys from: https://dashboard.stripe.com/apikeys
2. Update `.env`:
   ```env
   STRIPE_KEY=pk_live_xxxxx
   STRIPE_SECRET=sk_live_xxxxx
   ```

#### **PayPal (Live Mode):**
1. Change `PAYPAL_MODE=live`
2. Get credentials from: https://developer.paypal.com
3. Update client ID and secret

#### **Razorpay:**
1. Get keys from: https://dashboard.razorpay.com
2. Update `.env` with live keys

---

## 📧 **STEP 12: EMAIL CONFIGURATION**

### **Gmail SMTP (Recommended for testing):**
1. Enable 2FA on Gmail
2. Generate App Password
3. Update `.env`:
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-16-digit-app-password
MAIL_ENCRYPTION=tls
```

### **SendGrid (Recommended for production):**
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USERNAME=apikey
MAIL_PASSWORD=your-sendgrid-api-key
MAIL_ENCRYPTION=tls
```

### **Test Email:**
```bash
php artisan tinker
Mail::raw('Test email', function($msg) {
    $msg->to('test@example.com')->subject('Test');
});
```

---

## 🔧 **TROUBLESHOOTING**

### **Error: "500 Internal Server Error"**
- Check storage permissions: `chmod -R 755 storage`
- Check PHP version: `php -v` (must be 8.2+)
- Enable error display temporarily:
  ```env
  APP_DEBUG=true
  ```
- Check Laravel logs: `storage/logs/laravel.log`

### **Error: "Database connection failed"**
- Verify database credentials in `.env`
- Test connection: `php artisan migrate:status`
- Check MySQL is running: `systemctl status mysql`

### **Cron Jobs Not Running:**
- Verify cron is set: `crontab -l`
- Check cron logs: `/var/log/syslog` or `/var/log/cron`
- Test manually: `php artisan schedule:run`

### **Payment Gateway Errors:**
- Ensure SSL is active (HTTPS)
- Verify API keys are for correct mode (test/live)
- Check webhook URLs are accessible

### **Email Not Sending:**
- Test SMTP connection
- Check spam folder
- Verify firewall allows port 587
- Try different MAIL_PORT (465, 587, 2525)

---

## 🚀 **POST-INSTALLATION CHECKLIST**

- [ ] Changed default admin password
- [ ] Configured payment gateways (live mode)
- [ ] Added at least 5 services
- [ ] Tested user registration
- [ ] Tested order placement
- [ ] Verified email delivery
- [ ] Cron jobs running (check after 10 minutes)
- [ ] SSL certificate installed
- [ ] Created first test order
- [ ] Set up backup schedule
- [ ] Configured API providers
- [ ] Tested all payment methods
- [ ] Reviewed admin settings
- [ ] Created terms & privacy pages
- [ ] Set up support email
- [ ] Tested mobile responsiveness

---

## 🛡️ **SECURITY BEST PRACTICES**

1. **Change default admin credentials immediately**
2. **Keep APP_DEBUG=false in production**
3. **Never commit .env to version control**
4. **Use strong passwords (16+ characters)**
5. **Enable 2FA for admin accounts** (future feature)
6. **Regular backups** (automated daily)
7. **Monitor error logs weekly**
8. **Update dependencies monthly**
9. **Use HTTPS only (force SSL)**
10. **Limit failed login attempts**

---

## 📞 **SUPPORT**

### **Default Credentials:**
- **Admin:** admin@cheapsmm.fun / admin123
- **Test User:** test@cheapsmm.fun / password

### **File Locations:**
- **Logs:** `storage/logs/`
- **Backups:** `storage/app/backups/`
- **Uploads:** `storage/app/public/`
- **Database:** `database/COMPLETE-DATABASE-SCHEMA.sql`

### **Common Commands:**
```bash
# Clear cache
php artisan cache:clear
php artisan config:clear
php artisan view:clear

# Run migrations (if needed)
php artisan migrate

# Create storage link
php artisan storage:link

# Run queue worker
php artisan queue:work

# Test scheduler
php artisan schedule:test
```

---

## 🎊 **CONGRATULATIONS!**

Your CheapSMM Panel is now **100% installed and ready!**

**What you can do now:**
- Start accepting orders
- Configure child panels for resellers
- Set up API access
- Launch marketing campaigns
- Generate revenue!

**Next Steps:**
1. Add your SMM API providers
2. Populate services catalog
3. Create promotional campaigns
4. Set up social media
5. Start customer acquisition

---

**Built with 💎 - CheapSMM Panel 100% Complete Edition**

*For technical support, refer to the included documentation files.*
