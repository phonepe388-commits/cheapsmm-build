# cPanel Vendor Deployment Strategy (NO SSH/TERMINAL)

## Problem:
cPanel shared hosting has NO terminal access to run `composer install`

## Solution:
Pre-build vendor directory LOCALLY, then upload it

---

## STEP-BY-STEP DEPLOYMENT

### OPTION 1: Build on Local Machine (RECOMMENDED)

**Requirements:**
- Local computer with PHP 8.2+
- Composer installed locally

**Steps:**

1. **Extract project on your local machine:**
   ```
   unzip cheapsmm-panel-PRODUCTION-READY.zip
   cd cheapsmm-panel-PRODUCTION-READY
   ```

2. **Install dependencies locally:**
   ```
   composer install --optimize-autoloader --no-dev
   ```
   
   This creates the `vendor/` folder (~50MB)

3. **ZIP the complete project:**
   ```
   zip -r cheapsmm-complete-with-vendor.zip . -x "*.git*" -x "node_modules/*"
   ```

4. **Upload to cPanel:**
   - Upload ZIP via cPanel File Manager
   - Extract in public_html parent directory
   - Move contents appropriately

---

### OPTION 2: Use Third-Party Composer Service

**If you don't have local PHP:**

Use online services like:
- https://getcomposer.org/download/ (download composer.phar)
- Run on any PHP 8.2 hosting temporarily
- Download complete project with vendor/

---

### OPTION 3: Request from Hosting Provider

Some cPanel hosts offer SSH on request or provide WP-CLI-style tools
Contact support: "I need to run composer install for my Laravel app"

---

## VERIFICATION

After deployment, vendor/ should contain:
- autoload.php
- composer/
- laravel/
- symfony/
- ~100+ package directories

Total size: 50-70 MB

---

## CRITICAL FILES NEEDED IN UPLOAD

✅ vendor/ (entire folder)
✅ .env (created from .env.example)
✅ bootstrap/cache/ (writable)
✅ storage/ (all subdirectories writable)
✅ public/index.php
✅ All app/, config/, routes/, database/ files

---

## POST-UPLOAD COMMANDS (if SSH available)

If you get SSH access later:
```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan storage:link
```

Otherwise, these are optional optimizations.
