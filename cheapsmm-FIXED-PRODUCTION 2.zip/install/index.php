<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Security check - disable installer if .env exists and has APP_KEY
if (file_exists('../.env') && strpos(file_get_contents('../.env'), 'APP_KEY=base64:') !== false) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <title>Installation Complete</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 50px; text-align: center; }
            .box { background: white; max-width: 600px; margin: 0 auto; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .success { color: #10b981; font-size: 48px; }
        </style>
    </head>
    <body>
        <div class="box">
            <div class="success">✅</div>
            <h1>Installation Already Complete</h1>
            <p>The application is already installed. Please delete the /install directory for security.</p>
            <p><a href="../">Go to Application →</a></p>
        </div>
    </body>
    </html>
    ');
}

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheapSMM Panel - Installation Wizard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .header { text-align: center; color: white; margin-bottom: 30px; }
        .header h1 { font-size: 36px; margin-bottom: 10px; }
        .header p { opacity: 0.9; }
        .card { background: white; border-radius: 10px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); overflow: hidden; }
        .progress { height: 8px; background: #e5e7eb; }
        .progress-bar { height: 100%; background: linear-gradient(90deg, #667eea, #764ba2); transition: width 0.3s; }
        .content { padding: 40px; }
        .steps { display: flex; justify-content: space-between; margin-bottom: 40px; }
        .step-item { flex: 1; text-align: center; position: relative; }
        .step-item:not(:last-child)::after { content: ''; position: absolute; top: 15px; left: 50%; width: 100%; height: 2px; background: #e5e7eb; z-index: -1; }
        .step-number { width: 30px; height: 30px; border-radius: 50%; background: #e5e7eb; color: #6b7280; display: inline-flex; align-items: center; justify-content: center; font-weight: bold; margin-bottom: 5px; }
        .step-item.active .step-number { background: #667eea; color: white; }
        .step-item.completed .step-number { background: #10b981; color: white; }
        .step-label { font-size: 12px; color: #6b7280; }
        h2 { color: #1f2937; margin-bottom: 20px; font-size: 24px; }
        .info { background: #dbeafe; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; border-radius: 4px; }
        .success { background: #d1fae5; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; border-radius: 4px; }
        .error { background: #fee2e2; border-left: 4px solid #ef4444; padding: 15px; margin: 20px 0; border-radius: 4px; }
        .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 4px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; color: #374151; font-weight: 500; }
        input, select, textarea { width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; }
        input:focus, select:focus { outline: none; border-color: #667eea; }
        .btn { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 500; text-decoration: none; }
        .btn:hover { opacity: 0.9; }
        .btn-secondary { background: #6b7280; }
        .btn-group { display: flex; gap: 10px; margin-top: 30px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; color: #374151; }
        .status-ok { color: #10b981; font-weight: bold; }
        .status-fail { color: #ef4444; font-weight: bold; }
        .check-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
        code { background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 CheapSMM Panel</h1>
            <p>Installation Wizard</p>
        </div>

        <div class="card">
            <div class="progress">
                <div class="progress-bar" style="width: <?php echo ($step / 6) * 100; ?>%"></div>
            </div>

            <div class="content">
                <div class="steps">
                    <div class="step-item <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                        <div class="step-number">1</div>
                        <div class="step-label">Welcome</div>
                    </div>
                    <div class="step-item <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                        <div class="step-number">2</div>
                        <div class="step-label">Requirements</div>
                    </div>
                    <div class="step-item <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'completed' : ''; ?>">
                        <div class="step-number">3</div>
                        <div class="step-label">Database</div>
                    </div>
                    <div class="step-item <?php echo $step >= 4 ? 'active' : ''; ?> <?php echo $step > 4 ? 'completed' : ''; ?>">
                        <div class="step-number">4</div>
                        <div class="step-label">Configuration</div>
                    </div>
                    <div class="step-item <?php echo $step >= 5 ? 'active' : ''; ?> <?php echo $step > 5 ? 'completed' : ''; ?>">
                        <div class="step-number">5</div>
                        <div class="step-label">Install</div>
                    </div>
                    <div class="step-item <?php echo $step >= 6 ? 'active' : ''; ?>">
                        <div class="step-number">6</div>
                        <div class="step-label">Complete</div>
                    </div>
                </div>

                <?php
                switch ($step) {
                    case 1:
                        include 'steps/welcome.php';
                        break;
                    case 2:
                        include 'steps/requirements.php';
                        break;
                    case 3:
                        include 'steps/database.php';
                        break;
                    case 4:
                        include 'steps/configuration.php';
                        break;
                    case 5:
                        include 'steps/install.php';
                        break;
                    case 6:
                        include 'steps/complete.php';
                        break;
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
