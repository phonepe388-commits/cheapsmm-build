<?php
if (!isset($_SESSION['db_host']) || !isset($_SESSION['admin_email'])) {
    header('Location: ?step=1');
    exit;
}

$errors = [];
$steps = [];

function addStep($message, $success = true) {
    global $steps;
    $steps[] = ['message' => $message, 'success' => $success];
}

function generateRandomKey() {
    return 'base64:' . base64_encode(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Step 1: Create .env file
        addStep('Creating environment configuration...');
        $envContent = "APP_NAME=\"{$_SESSION['app_name']}\"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL={$_SESSION['app_url']}

DB_CONNECTION=mysql
DB_HOST={$_SESSION['db_host']}
DB_PORT={$_SESSION['db_port']}
DB_DATABASE={$_SESSION['db_database']}
DB_USERNAME={$_SESSION['db_username']}
DB_PASSWORD={$_SESSION['db_password']}

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DISK=local
QUEUE_CONNECTION=database
SESSION_DRIVER=file
SESSION_LIFETIME=120

MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=
MAIL_PASSWORD=
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@cheapsmm.fun
MAIL_FROM_NAME=\"\${APP_NAME}\"
";
        
        if (!file_put_contents('../.env', $envContent)) {
            throw new Exception('Failed to create .env file');
        }
        addStep('.env file created successfully', true);

        // Step 2: Generate APP_KEY
        addStep('Generating application key...');
        $appKey = generateRandomKey();
        $envContent = str_replace('APP_KEY=', 'APP_KEY=' . $appKey, $envContent);
        file_put_contents('../.env', $envContent);
        addStep('Application key generated', true);

        // Step 3: Import database
        addStep('Importing database schema...');
        $dsn = "mysql:host={$_SESSION['db_host']};port={$_SESSION['db_port']};dbname={$_SESSION['db_database']}";
        $pdo = new PDO($dsn, $_SESSION['db_username'], $_SESSION['db_password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = file_get_contents('../database/COMPLETE-DATABASE-SCHEMA.sql');
        $pdo->exec($sql);
        addStep('Database schema imported successfully', true);

        // Step 4: Update admin credentials
        addStep('Creating admin account...');
        $hashedPassword = password_hash($_SESSION['admin_password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE admins SET email = ?, password = ? WHERE id = 1");
        $stmt->execute([$_SESSION['admin_email'], $hashedPassword]);
        addStep('Admin account created', true);

        // Step 5: Clear session
        session_destroy();
        
        addStep('Installation completed successfully!', true);
        
        header('Location: ?step=6');
        exit;
        
    } catch (Exception $e) {
        addStep('Error: ' . $e->getMessage(), false);
        $errors[] = $e->getMessage();
    }
}
?>

<h2>Ready to Install</h2>

<div class="info">
    <strong>Installation Summary:</strong>
    <ul style="margin: 10px 0 0 20px;">
        <li>Database: <?php echo htmlspecialchars($_SESSION['db_database']); ?></li>
        <li>App Name: <?php echo htmlspecialchars($_SESSION['app_name']); ?></li>
        <li>App URL: <?php echo htmlspecialchars($_SESSION['app_url']); ?></li>
        <li>Admin Email: <?php echo htmlspecialchars($_SESSION['admin_email']); ?></li>
    </ul>
</div>

<?php if (empty($steps)): ?>
<p>Click the button below to start the installation process. This may take a few moments.</p>

<form method="POST">
    <div class="btn-group">
        <a href="?step=4" class="btn btn-secondary">← Back</a>
        <button type="submit" class="btn">🚀 Install Now</button>
    </div>
</form>

<?php else: ?>
    <h3 style="margin-top: 30px;">Installation Progress:</h3>
    <div style="background: #f9fafb; padding: 20px; border-radius: 6px; font-family: monospace; font-size: 14px;">
        <?php foreach ($steps as $step): ?>
            <div style="margin: 5px 0; color: <?php echo $step['success'] ? '#10b981' : '#ef4444'; ?>;">
                <?php echo $step['success'] ? '✓' : '✗'; ?> <?php echo htmlspecialchars($step['message']); ?>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="error" style="margin-top: 20px;">
        <strong>Installation Failed:</strong>
        <?php foreach ($errors as $error): ?>
            <div><?php echo htmlspecialchars($error); ?></div>
        <?php endforeach; ?>
    </div>
    <div class="btn-group">
        <a href="?step=4" class="btn">← Try Again</a>
    </div>
    <?php endif; ?>
<?php endif; ?>
