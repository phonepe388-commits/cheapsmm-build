<?php
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['db_host'] ?? 'localhost';
    $port = $_POST['db_port'] ?? '3306';
    $database = $_POST['db_database'] ?? '';
    $username = $_POST['db_username'] ?? '';
    $password = $_POST['db_password'] ?? '';

    try {
        $dsn = "mysql:host=$host;port=$port;dbname=$database";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Save to session
        $_SESSION['db_host'] = $host;
        $_SESSION['db_port'] = $port;
        $_SESSION['db_database'] = $database;
        $_SESSION['db_username'] = $username;
        $_SESSION['db_password'] = $password;

        header('Location: ?step=4');
        exit;
    } catch (PDOException $e) {
        $error = 'Connection failed: ' . $e->getMessage();
    }
}

$db_host = $_SESSION['db_host'] ?? 'localhost';
$db_port = $_SESSION['db_port'] ?? '3306';
$db_database = $_SESSION['db_database'] ?? '';
$db_username = $_SESSION['db_username'] ?? '';
?>

<h2>Database Configuration</h2>

<p>Enter your database credentials. Make sure the database is already created.</p>

<?php if ($error): ?>
<div class="error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<form method="POST">
    <div class="form-group">
        <label>Database Host</label>
        <input type="text" name="db_host" value="<?php echo htmlspecialchars($db_host); ?>" required>
        <small style="color: #6b7280;">Usually "localhost" or "127.0.0.1"</small>
    </div>

    <div class="form-group">
        <label>Database Port</label>
        <input type="text" name="db_port" value="<?php echo htmlspecialchars($db_port); ?>" required>
        <small style="color: #6b7280;">Default MySQL port is 3306</small>
    </div>

    <div class="form-group">
        <label>Database Name</label>
        <input type="text" name="db_database" value="<?php echo htmlspecialchars($db_database); ?>" required>
        <small style="color: #6b7280;">The database must already exist</small>
    </div>

    <div class="form-group">
        <label>Database Username</label>
        <input type="text" name="db_username" value="<?php echo htmlspecialchars($db_username); ?>" required>
    </div>

    <div class="form-group">
        <label>Database Password</label>
        <input type="password" name="db_password" value="">
    </div>

    <div class="info">
        <strong>💡 Tip:</strong> You can create a database in cPanel → MySQL Databases or via phpMyAdmin.
    </div>

    <div class="btn-group">
        <a href="?step=2" class="btn btn-secondary">← Back</a>
        <button type="submit" class="btn">Test Connection →</button>
    </div>
</form>
