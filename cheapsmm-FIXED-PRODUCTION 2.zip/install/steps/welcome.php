<h2>👋 Welcome to CheapSMM Panel Installation</h2>

<div class="info">
    <strong>Before You Begin:</strong>
    <ul style="margin: 10px 0 0 20px;">
        <li>Make sure you have created a MySQL database</li>
        <li>Have your database credentials ready</li>
        <li>Ensure you have PHP 8.2+ installed</li>
        <li>Have write permissions for this directory</li>
    </ul>
</div>

<p style="margin: 20px 0;">This wizard will guide you through the installation process:</p>

<table>
    <tr>
        <td><strong>✅ System Check</strong></td>
        <td>Verify your server meets all requirements</td>
    </tr>
    <tr>
        <td><strong>🗄️ Database Setup</strong></td>
        <td>Configure your database connection</td>
    </tr>
    <tr>
        <td><strong>⚙️ Configuration</strong></td>
        <td>Set up application settings</td>
    </tr>
    <tr>
        <td><strong>📦 Installation</strong></td>
        <td>Import database and finalize setup</td>
    </tr>
</table>

<div class="warning">
    <strong>⚠️ Important:</strong> This installer should only be run once. After installation is complete, delete the <code>/install</code> directory for security.
</div>

<div class="btn-group">
    <a href="?step=2" class="btn">Start Installation →</a>
</div>
