<?php
$requirements = [
    'PHP Version' => [
        'required' => '8.2.0',
        'current' => PHP_VERSION,
        'passed' => version_compare(PHP_VERSION, '8.2.0', '>=')
    ],
    'BCMath Extension' => [
        'current' => extension_loaded('bcmath') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('bcmath')
    ],
    'Ctype Extension' => [
        'current' => extension_loaded('ctype') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('ctype')
    ],
    'JSON Extension' => [
        'current' => extension_loaded('json') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('json')
    ],
    'Mbstring Extension' => [
        'current' => extension_loaded('mbstring') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('mbstring')
    ],
    'OpenSSL Extension' => [
        'current' => extension_loaded('openssl') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('openssl')
    ],
    'PDO Extension' => [
        'current' => extension_loaded('pdo') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('pdo')
    ],
    'PDO MySQL' => [
        'current' => extension_loaded('pdo_mysql') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('pdo_mysql')
    ],
    'cURL Extension' => [
        'current' => extension_loaded('curl') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('curl')
    ],
    'GD Extension' => [
        'current' => extension_loaded('gd') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('gd')
    ],
    'Zip Extension' => [
        'current' => extension_loaded('zip') ? 'Installed' : 'Not Installed',
        'passed' => extension_loaded('zip')
    ],
];

$permissions = [
    'storage' => is_writable('../storage'),
    'bootstrap/cache' => is_writable('../bootstrap/cache'),
    '.env' => !file_exists('../.env') || is_writable('../.env'),
];

$allRequirementsPassed = true;
foreach ($requirements as $req) {
    if (!$req['passed']) $allRequirementsPassed = false;
}

$allPermissionsPassed = true;
foreach ($permissions as $perm) {
    if (!$perm) $allPermissionsPassed = false;
}

$canContinue = $allRequirementsPassed && $allPermissionsPassed;
?>

<h2>System Requirements Check</h2>

<p>Checking if your server meets the minimum requirements...</p>

<h3 style="margin-top: 30px;">PHP Requirements</h3>
<table>
    <thead>
        <tr>
            <th>Requirement</th>
            <th>Required</th>
            <th>Current</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($requirements as $name => $req): ?>
        <tr>
            <td><?php echo $name; ?></td>
            <td><?php echo isset($req['required']) ? $req['required'] : 'Required'; ?></td>
            <td><?php echo $req['current']; ?></td>
            <td class="<?php echo $req['passed'] ? 'status-ok' : 'status-fail'; ?>">
                <?php echo $req['passed'] ? '✓ Passed' : '✗ Failed'; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h3 style="margin-top: 30px;">Directory Permissions</h3>
<table>
    <thead>
        <tr>
            <th>Directory</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($permissions as $dir => $writable): ?>
        <tr>
            <td><code><?php echo $dir; ?></code></td>
            <td class="<?php echo $writable ? 'status-ok' : 'status-fail'; ?>">
                <?php echo $writable ? '✓ Writable' : '✗ Not Writable'; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php if (!$canContinue): ?>
<div class="error">
    <strong>Cannot Continue:</strong> Please fix the issues above before proceeding with installation.
</div>
<?php else: ?>
<div class="success">
    <strong>✓ All requirements met!</strong> Your server is ready for installation.
</div>
<?php endif; ?>

<div class="btn-group">
    <a href="?step=1" class="btn btn-secondary">← Back</a>
    <?php if ($canContinue): ?>
    <a href="?step=3" class="btn">Continue →</a>
    <?php endif; ?>
</div>
