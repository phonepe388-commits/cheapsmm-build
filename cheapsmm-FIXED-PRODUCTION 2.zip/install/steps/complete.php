<h2>🎉 Installation Complete!</h2>

<div class="success">
    <strong>Congratulations!</strong> CheapSMM Panel has been successfully installed on your server.
</div>

<h3 style="margin-top: 30px;">Next Steps:</h3>

<div style="background: #f9fafb; padding: 20px; border-radius: 6px; margin: 20px 0;">
    <p><strong>1. Delete the installer for security:</strong></p>
    <code style="display: block; background: #1f2937; color: #10b981; padding: 10px; border-radius: 4px; margin: 10px 0;">
        rm -rf install/
    </code>

    <p style="margin-top: 20px;"><strong>2. Login to Admin Panel:</strong></p>
    <p>URL: <a href="../admin/login" target="_blank" style="color: #3b82f6;"><?php echo $_SESSION['app_url'] ?? ''; ?>/admin/login</a></p>
    
    <p style="margin-top: 20px;"><strong>3. Configure your panel:</strong></p>
    <ul style="margin: 10px 0 0 20px; color: #374151;">
        <li>Add payment gateways (Admin → Settings)</li>
        <li>Add services and API providers</li>
        <li>Configure SMTP for emails</li>
        <li>Set up cron jobs for automation</li>
        <li>Customize branding and logo</li>
    </ul>
</div>

<div class="warning">
    <strong>⚠️ Important Security Steps:</strong>
    <ul style="margin: 10px 0 0 20px;">
        <li>Delete the <code>/install</code> directory immediately</li>
        <li>Change your admin password after first login</li>
        <li>Never set <code>APP_DEBUG=true</code> in production</li>
        <li>Keep your <code>.env</code> file secure</li>
    </ul>
</div>

<h3 style="margin-top: 30px;">Documentation:</h3>
<ul style="margin: 10px 0 0 20px;">
    <li>Installation Guide: <code>INSTALLATION-GUIDE.md</code></li>
    <li>Cron Setup: <code>CRON_SETUP_GUIDE.md</code></li>
    <li>API Documentation: Built-in at <code>/api/documentation</code></li>
</ul>

<div class="btn-group" style="margin-top: 40px;">
    <a href="../admin/login" class="btn">Go to Admin Panel →</a>
</div>

<p style="text-align: center; color: #6b7280; margin-top: 40px;">
    Thank you for choosing CheapSMM Panel! 🚀
</p>
