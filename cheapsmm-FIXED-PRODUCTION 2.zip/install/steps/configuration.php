<?php
if (!isset($_SESSION['db_host'])) {
    header('Location: ?step=3');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['app_name'] = $_POST['app_name'] ?? 'CheapSMM';
    $_SESSION['app_url'] = $_POST['app_url'] ?? '';
    $_SESSION['admin_email'] = $_POST['admin_email'] ?? '';
    $_SESSION['admin_password'] = $_POST['admin_password'] ?? '';
    
    header('Location: ?step=5');
    exit;
}

$app_name = $_SESSION['app_name'] ?? 'CheapSMM';
$app_url = $_SESSION['app_url'] ?? 'http://' . $_SERVER['HTTP_HOST'];
$admin_email = $_SESSION['admin_email'] ?? 'admin@cheapsmm.fun';
?>

<h2>Application Configuration</h2>

<p>Configure your application settings and admin account.</p>

<?php if ($error): ?>
<div class="error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<form method="POST">
    <h3 style="margin-top: 30px;">Application Details</h3>
    
    <div class="form-group">
        <label>Application Name</label>
        <input type="text" name="app_name" value="<?php echo htmlspecialchars($app_name); ?>" required>
        <small style="color: #6b7280;">Your SMM panel's name</small>
    </div>

    <div class="form-group">
        <label>Application URL</label>
        <input type="url" name="app_url" value="<?php echo htmlspecialchars($app_url); ?>" required>
        <small style="color: #6b7280;">Your website URL (without trailing slash)</small>
    </div>

    <h3 style="margin-top: 30px;">Admin Account</h3>
    <div class="info">
        <strong>⚠️ Important:</strong> This will be your main admin account. Choose a strong password!
    </div>

    <div class="form-group">
        <label>Admin Email</label>
        <input type="email" name="admin_email" value="<?php echo htmlspecialchars($admin_email); ?>" required>
        <small style="color: #6b7280;">You'll use this to login to admin panel</small>
    </div>

    <div class="form-group">
        <label>Admin Password</label>
        <input type="password" name="admin_password" required minlength="8">
        <small style="color: #6b7280;">Minimum 8 characters</small>
    </div>

    <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="admin_password_confirm" required minlength="8">
    </div>

    <div class="btn-group">
        <a href="?step=3" class="btn btn-secondary">← Back</a>
        <button type="submit" class="btn">Continue →</button>
    </div>
</form>

<script>
document.querySelector('form').addEventListener('submit', function(e) {
    const pass = document.querySelector('input[name="admin_password"]').value;
    const confirm = document.querySelector('input[name="admin_password_confirm"]').value;
    if (pass !== confirm) {
        e.preventDefault();
        alert('Passwords do not match!');
    }
});
</script>
