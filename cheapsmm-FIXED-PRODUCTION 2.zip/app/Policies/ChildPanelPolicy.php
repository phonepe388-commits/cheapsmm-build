<?php

namespace App\Policies;

use App\Models\{User, ChildPanel};

class ChildPanelPolicy
{
    /**
     * Determine if user can view the child panel
     */
    public function view(User $user, ChildPanel $childPanel): bool
    {
        return $user->id === $childPanel->user_id;
    }

    /**
     * Determine if user can update the child panel
     */
    public function update(User $user, ChildPanel $childPanel): bool
    {
        return $user->id === $childPanel->user_id;
    }

    /**
     * Determine if user can delete the child panel
     */
    public function delete(User $user, ChildPanel $childPanel): bool
    {
        return $user->id === $childPanel->user_id;
    }
}
