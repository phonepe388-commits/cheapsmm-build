<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WelcomeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;

    /**
     * Create a new message instance.
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('Welcome to ' . config('app.name') . '!')
            ->view('emails.auth.welcome')
            ->with([
                'userName' => $this->user->name,
                'loginUrl' => route('login'),
                'dashboardUrl' => route('user.dashboard'),
                'supportEmail' => config('mail.support_email', 'support@cheapsmm.fun')
            ]);
    }
}
