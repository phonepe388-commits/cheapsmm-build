<?php

namespace App\Mail;

use App\Models\Payment;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PaymentSuccess extends Mailable
{
    use Queueable, SerializesModels;

    public $payment;

    public function __construct(Payment $payment)
    {
        $this->payment = $payment;
    }

    public function build()
    {
        return $this->subject('Payment Successful - $' . number_format($this->payment->amount, 2))
            ->view('emails.payments.success')
            ->with([
                'amount' => $this->payment->amount,
                'transactionId' => $this->payment->transaction_id,
                'paymentMethod' => $this->payment->paymentMethod->name ?? 'N/A',
                'newBalance' => $this->payment->user->balance,
                'userName' => $this->payment->user->name,
                'date' => $this->payment->created_at->format('M d, Y H:i')
            ]);
    }
}
