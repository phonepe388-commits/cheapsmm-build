<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LowBalanceAlert extends Mailable
{
    use Queueable, SerializesModels;

    public $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function build()
    {
        return $this->subject('Low Balance Alert')
            ->view('emails.system.low-balance')
            ->with([
                'userName' => $this->user->name,
                'currentBalance' => $this->user->balance,
                'addFundsUrl' => route('user.payments.create')
            ]);
    }
}
