<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PasswordReset extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $token;

    public function __construct(User $user, string $token)
    {
        $this->user = $user;
        $this->token = $token;
    }

    public function build()
    {
        return $this->subject('Reset Your Password')
            ->view('emails.auth.password-reset')
            ->with([
                'userName' => $this->user->name,
                'resetUrl' => route('password.reset', ['token' => $this->token, 'email' => $this->user->email]),
                'expiresIn' => 60 // minutes
            ]);
    }
}
