<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderConfirmation extends Mailable
{
    use Queueable, SerializesModels;

    public $order;

    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    public function build()
    {
        return $this->subject('Order #' . $this->order->id . ' Confirmed')
            ->view('emails.orders.confirmation')
            ->with([
                'orderNumber' => $this->order->id,
                'serviceName' => $this->order->service->name,
                'quantity' => $this->order->quantity,
                'charge' => $this->order->charge,
                'link' => $this->order->link,
                'status' => $this->order->status,
                'orderUrl' => route('user.orders.show', $this->order->id),
                'userName' => $this->order->user->name
            ]);
    }
}
