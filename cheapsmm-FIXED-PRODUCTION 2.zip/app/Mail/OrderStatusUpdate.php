<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderStatusUpdate extends Mailable
{
    use Queueable, SerializesModels;

    public $order;
    public $oldStatus;

    public function __construct(Order $order, string $oldStatus)
    {
        $this->order = $order;
        $this->oldStatus = $oldStatus;
    }

    public function build()
    {
        return $this->subject('Order #' . $this->order->id . ' - Status Updated')
            ->view('emails.orders.status-update')
            ->with([
                'orderNumber' => $this->order->id,
                'serviceName' => $this->order->service->name,
                'oldStatus' => ucfirst($this->oldStatus),
                'newStatus' => ucfirst($this->order->status),
                'orderUrl' => route('user.orders.show', $this->order->id),
                'userName' => $this->order->user->name
            ]);
    }
}
