<?php

namespace App\Mail;

use App\Models\Ticket;
use App\Models\TicketMessage;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TicketReply extends Mailable
{
    use Queueable, SerializesModels;

    public $ticket;
    public $message;

    public function __construct(Ticket $ticket, TicketMessage $message)
    {
        $this->ticket = $ticket;
        $this->message = $message;
    }

    public function build()
    {
        $subject = $this->message->is_admin 
            ? 'Support Reply to Ticket #' . $this->ticket->id
            : 'New Reply on Ticket #' . $this->ticket->id;

        return $this->subject($subject)
            ->view('emails.tickets.reply')
            ->with([
                'ticketId' => $this->ticket->id,
                'ticketSubject' => $this->ticket->subject,
                'messageContent' => $this->message->message,
                'senderName' => $this->message->is_admin 
                    ? 'Support Team' 
                    : $this->ticket->user->name,
                'ticketUrl' => route('user.tickets.show', $this->ticket->id),
                'userName' => $this->ticket->user->name
            ]);
    }
}
