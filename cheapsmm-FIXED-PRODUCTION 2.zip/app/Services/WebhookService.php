<?php

namespace App\Services;

use App\Models\Webhook;
use Illuminate\Support\Facades\Http;

class WebhookService
{
    /**
     * Trigger webhook
     */
    public function trigger(string $event, array $data): void
    {
        $webhooks = Webhook::where('event', $event)
            ->where('status', 'active')
            ->get();

        foreach ($webhooks as $webhook) {
            $this->send($webhook, $data);
        }
    }

    /**
     * Send webhook request
     */
    private function send(Webhook $webhook, array $data): void
    {
        try {
            $payload = [
                'event' => $webhook->event,
                'timestamp' => now()->toIso8601String(),
                'data' => $data
            ];

            $response = Http::timeout(10)
                ->withHeaders(['Content-Type' => 'application/json'])
                ->post($webhook->url, $payload);

            $webhook->update([
                'last_triggered_at' => now(),
                'last_status' => $response->successful() ? 'success' : 'failed'
            ]);

        } catch (\Exception $e) {
            $webhook->update([
                'last_status' => 'failed',
                'last_error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Test webhook
     */
    public function test(Webhook $webhook): array
    {
        try {
            $testData = [
                'test' => true,
                'message' => 'This is a test webhook'
            ];

            $this->send($webhook, $testData);

            return [
                'success' => $webhook->last_status === 'success',
                'status' => $webhook->last_status,
                'error' => $webhook->last_error
            ];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
