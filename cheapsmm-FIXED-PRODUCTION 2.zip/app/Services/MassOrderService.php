<?php

namespace App\Services;

use App\Models\{User, Service, Order};
use Illuminate\Support\Facades\{DB, Log};

class MassOrderService
{
    protected $orderService;
    protected $emailService;

    public function __construct(OrderService $orderService, EmailService $emailService)
    {
        $this->orderService = $orderService;
        $this->emailService = $emailService;
    }

    /**
     * Parse mass order data from text format
     */
    public function parseTextInput(string $text): array
    {
        $lines = array_filter(array_map('trim', explode("\n", $text)));
        $orders = [];
        $errors = [];

        foreach ($lines as $index => $line) {
            $lineNumber = $index + 1;
            
            if (empty($line) || strpos($line, '#') === 0 || strpos($line, '//') === 0) {
                continue;
            }

            $parts = array_map('trim', explode('|', $line));

            if (count($parts) !== 3) {
                $errors[] = "Line {$lineNumber}: Invalid format. Expected: service_id|link|quantity";
                continue;
            }

            [$serviceId, $link, $quantity] = $parts;

            if (!is_numeric($serviceId)) {
                $errors[] = "Line {$lineNumber}: Invalid service ID '{$serviceId}'";
                continue;
            }

            if (!filter_var($link, FILTER_VALIDATE_URL)) {
                $errors[] = "Line {$lineNumber}: Invalid URL '{$link}'";
                continue;
            }

            if (!is_numeric($quantity) || $quantity < 1) {
                $errors[] = "Line {$lineNumber}: Invalid quantity '{$quantity}'";
                continue;
            }

            $orders[] = [
                'service_id' => (int)$serviceId,
                'link' => $link,
                'quantity' => (int)$quantity,
                'line' => $lineNumber
            ];
        }

        return [
            'orders' => $orders,
            'errors' => $errors,
            'total_lines' => count($lines),
            'valid_orders' => count($orders),
            'error_count' => count($errors)
        ];
    }

    /**
     * Parse mass order data from CSV
     */
    public function parseCsvFile($file): array
    {
        $orders = [];
        $errors = [];
        $lineNumber = 0;

        if (($handle = fopen($file->getRealPath(), 'r')) !== false) {
            $header = fgetcsv($handle);
            
            if ($header && strtolower($header[0]) === 'service_id') {
                $lineNumber = 1;
            } else {
                rewind($handle);
            }

            while (($data = fgetcsv($handle)) !== false) {
                $lineNumber++;

                if (empty(array_filter($data))) {
                    continue;
                }

                if (count($data) < 3) {
                    $errors[] = "Line {$lineNumber}: Insufficient columns";
                    continue;
                }

                [$serviceId, $link, $quantity] = array_map('trim', $data);

                if (!is_numeric($serviceId)) {
                    $errors[] = "Line {$lineNumber}: Invalid service ID";
                    continue;
                }

                if (!filter_var($link, FILTER_VALIDATE_URL)) {
                    $errors[] = "Line {$lineNumber}: Invalid URL";
                    continue;
                }

                if (!is_numeric($quantity) || $quantity < 1) {
                    $errors[] = "Line {$lineNumber}: Invalid quantity";
                    continue;
                }

                $orders[] = [
                    'service_id' => (int)$serviceId,
                    'link' => $link,
                    'quantity' => (int)$quantity,
                    'line' => $lineNumber
                ];
            }

            fclose($handle);
        }

        return [
            'orders' => $orders,
            'errors' => $errors,
            'total_lines' => $lineNumber,
            'valid_orders' => count($orders),
            'error_count' => count($errors)
        ];
    }

    /**
     * Validate mass orders before processing
     */
    public function validateOrders(User $user, array $orders): array
    {
        $validated = [];
        $errors = [];
        $totalCost = 0;

        foreach ($orders as $order) {
            $service = Service::where('id', $order['service_id'])
                ->where('status', 'active')
                ->first();

            if (!$service) {
                $errors[] = "Line {$order['line']}: Service ID {$order['service_id']} not found or inactive";
                continue;
            }

            if ($order['quantity'] < $service->min_quantity) {
                $errors[] = "Line {$order['line']}: Quantity {$order['quantity']} below minimum {$service->min_quantity}";
                continue;
            }

            if ($order['quantity'] > $service->max_quantity) {
                $errors[] = "Line {$order['line']}: Quantity {$order['quantity']} exceeds maximum {$service->max_quantity}";
                continue;
            }

            $charge = ($service->price_per_1000 * $order['quantity']) / 1000;
            $totalCost += $charge;

            $validated[] = [
                'service_id' => $service->id,
                'service_name' => $service->name,
                'link' => $order['link'],
                'quantity' => $order['quantity'],
                'charge' => $charge,
                'line' => $order['line']
            ];
        }

        $hasSufficientBalance = $user->balance >= $totalCost;

        return [
            'validated_orders' => $validated,
            'errors' => $errors,
            'total_cost' => $totalCost,
            'user_balance' => $user->balance,
            'has_sufficient_balance' => $hasSufficientBalance,
            'valid_count' => count($validated),
            'error_count' => count($errors)
        ];
    }

    /**
     * Process mass orders
     */
    public function processMassOrders(User $user, array $validatedOrders): array
    {
        $totalCost = array_sum(array_column($validatedOrders, 'charge'));
        $count = count($validatedOrders);

        if ($user->balance < $totalCost) {
            throw new \Exception('Insufficient balance');
        }

        $created = [];
        $failed = [];

        DB::beginTransaction();

        try {
            $user->decrement('balance', $totalCost);

            $user->transactions()->create([
                'type' => 'debit',
                'amount' => $totalCost,
                'balance_before' => $user->balance + $totalCost,
                'balance_after' => $user->balance,
                'description' => "Mass order - {$count} orders",
                'reference_type' => 'mass_order'
            ]);

            foreach ($validatedOrders as $orderData) {
                try {
                    $order = Order::create([
                        'user_id' => $user->id,
                        'service_id' => $orderData['service_id'],
                        'link' => $orderData['link'],
                        'quantity' => $orderData['quantity'],
                        'charge' => $orderData['charge'],
                        'start_count' => 0,
                        'remain' => $orderData['quantity'],
                        'status' => 'pending'
                    ]);

                    $order->history()->create([
                        'status' => 'pending',
                        'description' => 'Order created via mass order',
                        'created_by' => $user->id
                    ]);

                    $created[] = [
                        'order_id' => $order->id,
                        'service' => $orderData['service_name'],
                        'quantity' => $orderData['quantity'],
                        'charge' => $orderData['charge'],
                        'line' => $orderData['line']
                    ];

                    $this->emailService->sendOrderConfirmation($order);

                } catch (\Exception $e) {
                    $failed[] = [
                        'line' => $orderData['line'],
                        'error' => $e->getMessage(),
                        'data' => $orderData
                    ];
                }
            }

            DB::commit();

            \App\Models\ActivityLog::create([
                'user_id' => $user->id,
                'action' => 'mass_order_created',
                'description' => "Created {$count} mass orders totaling $" . number_format($totalCost, 2),
                'metadata' => [
                    'order_count' => count($created),
                    'total_cost' => $totalCost,
                    'failed_count' => count($failed)
                ]
            ]);

            return [
                'success' => true,
                'created' => $created,
                'failed' => $failed,
                'created_count' => count($created),
                'failed_count' => count($failed),
                'total_cost' => $totalCost,
                'new_balance' => $user->balance
            ];

        } catch (\Exception $e) {
            DB::rollBack();
            
            Log::error('Mass order processing failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage()
            ]);

            throw new \Exception('Failed to process mass orders: ' . $e->getMessage());
        }
    }

    /**
     * Get mass order template
     */
    public function getTemplate(string $format = 'text'): string
    {
        if ($format === 'csv') {
            return "service_id,link,quantity\n1,https://instagram.com/username,1000\n2,https://facebook.com/page,500";
        }

        return "# Mass Order Template\n# Format: service_id|link|quantity\n# Example:\n1|https://instagram.com/username|1000\n2|https://facebook.com/page|500\n3|https://twitter.com/profile|2000";
    }

    /**
     * Export mass order results to CSV
     */
    public function exportResults(array $results): string
    {
        $csv = "Order ID,Service,Link,Quantity,Charge,Status\n";

        foreach ($results['created'] as $order) {
            $csv .= sprintf(
                "%d,%s,%s,%d,%.2f,Success\n",
                $order['order_id'],
                $order['service'],
                '',
                $order['quantity'],
                $order['charge']
            );
        }

        foreach ($results['failed'] as $failed) {
            $csv .= sprintf(
                "N/A,%s,%s,%d,%.2f,Failed: %s\n",
                $failed['data']['service_name'] ?? 'Unknown',
                $failed['data']['link'] ?? '',
                $failed['data']['quantity'] ?? 0,
                $failed['data']['charge'] ?? 0,
                $failed['error']
            );
        }

        return $csv;
    }
}
