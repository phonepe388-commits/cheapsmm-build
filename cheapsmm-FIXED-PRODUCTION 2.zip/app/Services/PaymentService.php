<?php

namespace App\Services;

use App\Models\{Payment, User};
use Illuminate\Support\Facades\DB;

class PaymentService
{
    /**
     * Process payment with transaction safety
     */
    public function processPayment(User $user, float $amount, int $paymentMethodId, array $data = []): Payment
    {
        return DB::transaction(function () use ($user, $amount, $paymentMethodId, $data) {
            // Create payment record
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $paymentMethodId,
                'amount' => $amount,
                'currency' => $data['currency'] ?? 'USD',
                'status' => 'pending',
                'transaction_id' => $data['transaction_id'] ?? 'TXN_' . uniqid()
            ]);

            return $payment;
        });
    }

    /**
     * Complete payment and add balance
     */
    public function completePayment(Payment $payment): bool
    {
        return DB::transaction(function () use ($payment) {
            if ($payment->status !== 'pending') {
                return false;
            }

            // Calculate bonus
            $bonus = $this->calculateBonus($payment->amount);
            $totalCredit = $payment->amount + $bonus;

            // Update payment
            $payment->update([
                'status' => 'completed',
                'bonus_amount' => $bonus
            ]);

            // Credit user balance
            $payment->user->increment('balance', $totalCredit);

            // Create transaction record
            \App\Models\Transaction::create([
                'user_id' => $payment->user_id,
                'type' => 'credit',
                'amount' => $totalCredit,
                'description' => 'Payment deposit',
                'reference_type' => 'payment',
                'reference_id' => $payment->id,
                'balance_before' => $payment->user->balance - $totalCredit,
                'balance_after' => $payment->user->balance
            ]);

            return true;
        });
    }

    /**
     * Calculate bonus based on amount
     */
    private function calculateBonus(float $amount): float
    {
        if ($amount >= 500) {
            return $amount * 0.15; // 15%
        } elseif ($amount >= 100) {
            return $amount * 0.10; // 10%
        } elseif ($amount >= 50) {
            return $amount * 0.05; // 5%
        }
        return 0;
    }

    /**
     * Fail payment
     */
    public function failPayment(Payment $payment, string $reason = ''): bool
    {
        return DB::transaction(function () use ($payment, $reason) {
            $payment->update([
                'status' => 'failed',
                'admin_note' => $reason
            ]);
            return true;
        });
    }
}
