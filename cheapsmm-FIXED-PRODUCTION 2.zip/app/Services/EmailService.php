<?php

namespace App\Services;

use App\Models\{User, Order, Payment, Ticket, TicketMessage};
use App\Mail\{
    WelcomeEmail,
    OrderConfirmation,
    PaymentSuccess,
    TicketReply,
    PasswordReset,
    OrderStatusUpdate,
    LowBalanceAlert
};
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class EmailService
{
    /**
     * Send welcome email to new user
     */
    public function sendWelcomeEmail(User $user): bool
    {
        try {
            Mail::to($user->email)->send(new WelcomeEmail($user));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send welcome email: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send order confirmation email
     */
    public function sendOrderConfirmation(Order $order): bool
    {
        try {
            Mail::to($order->user->email)->send(new OrderConfirmation($order));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send order confirmation: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send payment success email
     */
    public function sendPaymentSuccess(Payment $payment): bool
    {
        try {
            Mail::to($payment->user->email)->send(new PaymentSuccess($payment));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send payment success email: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send ticket reply notification
     */
    public function sendTicketReply(Ticket $ticket, TicketMessage $message): bool
    {
        try {
            // Send to user if admin replied, or to admin if user replied
            $recipient = $message->is_admin ? $ticket->user->email : config('mail.support_email');
            
            Mail::to($recipient)->send(new TicketReply($ticket, $message));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send ticket reply email: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send password reset email
     */
    public function sendPasswordReset(User $user, string $token): bool
    {
        try {
            Mail::to($user->email)->send(new PasswordReset($user, $token));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send password reset email: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send order status update email
     */
    public function sendOrderStatusUpdate(Order $order, string $oldStatus): bool
    {
        try {
            Mail::to($order->user->email)->send(new OrderStatusUpdate($order, $oldStatus));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send order status update: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send low balance alert
     */
    public function sendLowBalanceAlert(User $user): bool
    {
        try {
            Mail::to($user->email)->send(new LowBalanceAlert($user));
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send low balance alert: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send bulk email to multiple users
     */
    public function sendBulkEmail(array $userIds, string $subject, string $message): int
    {
        $sent = 0;
        $users = User::whereIn('id', $userIds)->get();

        foreach ($users as $user) {
            try {
                Mail::raw($message, function($mail) use ($user, $subject) {
                    $mail->to($user->email)->subject($subject);
                });
                $sent++;
            } catch (\Exception $e) {
                Log::error("Failed to send bulk email to {$user->email}: " . $e->getMessage());
            }
        }

        return $sent;
    }

    /**
     * Check if user has email notifications enabled
     */
    private function userWantsEmail(User $user, string $type): bool
    {
        // Check user's notification preferences
        // For now, return true - implement preferences later
        return true;
    }
}
