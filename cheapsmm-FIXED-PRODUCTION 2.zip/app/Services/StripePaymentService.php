<?php

namespace App\Services;

use App\Models\{Payment, User, PaymentMethod};
use Stripe\{Stripe, Checkout\Session};
use Illuminate\Support\Facades\DB;

class StripePaymentService
{
    protected $emailService;

    public function __construct(EmailService $emailService)
    {
        Stripe::setApiKey(config('services.stripe.secret'));
        $this->emailService = $emailService;
    }

    public function createCheckoutSession(User $user, float $amount, array $metadata = [])
    {
        try {
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $this->getStripeMethodId(),
                'amount' => $amount,
                'currency' => 'USD',
                'status' => 'pending',
                'transaction_id' => 'stripe_' . uniqid(),
                'metadata' => $metadata
            ]);

            $session = Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => [
                            'name' => 'Add Funds - ' . config('app.name'),
                        ],
                        'unit_amount' => $amount * 100,
                    ],
                    'quantity' => 1,
                ]],
                'mode' => 'payment',
                'success_url' => route('user.payments.success') . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('user.payments.create'),
                'customer_email' => $user->email,
                'metadata' => [
                    'payment_id' => $payment->id,
                    'user_id' => $user->id
                ]
            ]);

            $payment->update(['transaction_id' => $session->id]);

            return [
                'session_id' => $session->id,
                'payment_id' => $payment->id
            ];

        } catch (\Exception $e) {
            \Log::error('Stripe checkout session error: ' . $e->getMessage());
            throw new \Exception('Failed to create payment session: ' . $e->getMessage());
        }
    }

    public function handleSuccess(string $sessionId)
    {
        try {
            $session = Session::retrieve($sessionId);
            $payment = Payment::where('transaction_id', $sessionId)->firstOrFail();

            if ($payment->status === 'completed') {
                return $payment;
            }

            DB::transaction(function() use ($payment, $session) {
                $payment->update([
                    'status' => 'completed',
                    'paid_at' => now()
                ]);

                $bonus = $this->calculateBonus($payment->amount);
                $totalCredit = $payment->amount + $bonus;

                $payment->user->increment('balance', $totalCredit);

                $payment->user->transactions()->create([
                    'type' => 'credit',
                    'amount' => $totalCredit,
                    'balance_before' => $payment->user->balance - $totalCredit,
                    'balance_after' => $payment->user->balance,
                    'description' => "Payment received via Stripe" . ($bonus > 0 ? " (includes ${$bonus} bonus)" : ""),
                    'reference_type' => 'payment',
                    'reference_id' => $payment->id
                ]);

                // Send payment success email
                $this->emailService->sendPaymentSuccess($payment);
            });

            return $payment;

        } catch (\Exception $e) {
            \Log::error('Stripe payment success handling error: ' . $e->getMessage());
            throw new \Exception('Failed to process payment: ' . $e->getMessage());
        }
    }

    public function handleWebhook(array $payload)
    {
        $event = $payload['type'];
        $session = $payload['data']['object'];

        switch ($event) {
            case 'checkout.session.completed':
                $this->handleSuccess($session['id']);
                break;

            case 'checkout.session.expired':
            case 'checkout.session.async_payment_failed':
                $payment = Payment::where('transaction_id', $session['id'])->first();
                if ($payment) {
                    $payment->update(['status' => 'failed']);
                }
                break;
        }
    }

    public function calculateBonus(float $amount): float
    {
        if ($amount >= 500) {
            return $amount * 0.15;
        } elseif ($amount >= 100) {
            return $amount * 0.10;
        } elseif ($amount >= 50) {
            return $amount * 0.05;
        }
        return 0;
    }

    private function getStripeMethodId()
    {
        return PaymentMethod::where('code', 'stripe')->value('id') ?? 1;
    }

    public function handleFailedPayment(Payment $payment, string $reason)
    {
        $payment->update([
            'status' => 'failed',
            'metadata' => array_merge($payment->metadata ?? [], ['failure_reason' => $reason])
        ]);
    }

    public function createRefund(Payment $payment, float $amount = null)
    {
        try {
            $refundAmount = $amount ?? $payment->amount;

            $refund = \Stripe\Refund::create([
                'payment_intent' => $payment->transaction_id,
                'amount' => $refundAmount * 100
            ]);

            $payment->user->decrement('balance', $refundAmount);

            $payment->user->transactions()->create([
                'type' => 'debit',
                'amount' => $refundAmount,
                'balance_before' => $payment->user->balance + $refundAmount,
                'balance_after' => $payment->user->balance,
                'description' => "Refund for payment #{$payment->id}",
                'reference_type' => 'refund',
                'reference_id' => $payment->id
            ]);

            return $refund;

        } catch (\Exception $e) {
            \Log::error('Stripe refund error: ' . $e->getMessage());
            throw new \Exception('Failed to process refund: ' . $e->getMessage());
        }
    }
}
