<?php

namespace App\Services;

use App\Models\Currency;
use Illuminate\Support\Facades\{Cache, Http, Log};

class CurrencyService
{
    protected $baseCurrency = 'USD';

    /**
     * Get all active currencies
     */
    public function getActiveCurrencies()
    {
        return Cache::remember('active_currencies', 3600, function() {
            return Currency::where('status', 'active')
                ->orderBy('sort_order')
                ->get();
        });
    }

    /**
     * Get current user's selected currency
     */
    public function getCurrentCurrency(): Currency
    {
        $currencyCode = session('currency', $this->baseCurrency);
        
        return Cache::remember("currency_{$currencyCode}", 3600, function() use ($currencyCode) {
            return Currency::where('code', $currencyCode)->first() 
                ?? Currency::where('code', $this->baseCurrency)->first();
        });
    }

    /**
     * Set user's selected currency
     */
    public function setCurrency(string $code): bool
    {
        $currency = Currency::where('code', $code)->where('status', 'active')->first();
        
        if ($currency) {
            session(['currency' => $code]);
            return true;
        }
        
        return false;
    }

    /**
     * Convert amount from base currency to target currency
     */
    public function convert(float $amount, string $toCurrency = null): float
    {
        if (!$toCurrency) {
            $toCurrency = session('currency', $this->baseCurrency);
        }

        if ($toCurrency === $this->baseCurrency) {
            return $amount;
        }

        $currency = Currency::where('code', $toCurrency)->first();
        
        if (!$currency) {
            return $amount;
        }

        return $amount * $currency->exchange_rate;
    }

    /**
     * Convert amount from any currency to base currency
     */
    public function convertToBase(float $amount, string $fromCurrency): float
    {
        if ($fromCurrency === $this->baseCurrency) {
            return $amount;
        }

        $currency = Currency::where('code', $fromCurrency)->first();
        
        if (!$currency || $currency->exchange_rate == 0) {
            return $amount;
        }

        return $amount / $currency->exchange_rate;
    }

    /**
     * Format amount with currency symbol
     */
    public function format(float $amount, string $currencyCode = null): string
    {
        if (!$currencyCode) {
            $currencyCode = session('currency', $this->baseCurrency);
        }

        $currency = Currency::where('code', $currencyCode)->first();
        
        if (!$currency) {
            return '$' . number_format($amount, 2);
        }

        $formatted = number_format($amount, $currency->decimal_places);

        if ($currency->symbol_position === 'before') {
            return $currency->symbol . $formatted;
        }

        return $formatted . ' ' . $currency->symbol;
    }

    /**
     * Convert and format amount
     */
    public function convertAndFormat(float $amount, string $toCurrency = null): string
    {
        $converted = $this->convert($amount, $toCurrency);
        return $this->format($converted, $toCurrency);
    }

    /**
     * Update exchange rates from API
     */
    public function updateExchangeRates(): array
    {
        try {
            $apiKey = config('services.exchange_rate.api_key');
            
            // Using exchangerate-api.com (free tier available)
            $response = Http::get("https://v6.exchangerate-api.com/v6/{$apiKey}/latest/{$this->baseCurrency}");

            if (!$response->successful()) {
                throw new \Exception('Failed to fetch exchange rates');
            }

            $data = $response->json();
            $rates = $data['conversion_rates'] ?? [];

            $updated = [];
            $failed = [];

            foreach (Currency::where('status', 'active')->get() as $currency) {
                if (isset($rates[$currency->code])) {
                    $currency->update([
                        'exchange_rate' => $rates[$currency->code],
                        'last_updated' => now()
                    ]);
                    $updated[] = $currency->code;
                } else {
                    $failed[] = $currency->code;
                }
            }

            // Clear cache
            Cache::forget('active_currencies');

            Log::info('Exchange rates updated', [
                'updated' => $updated,
                'failed' => $failed
            ]);

            return [
                'success' => true,
                'updated' => count($updated),
                'failed' => count($failed),
                'updated_currencies' => $updated
            ];

        } catch (\Exception $e) {
            Log::error('Exchange rate update failed: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get exchange rate for a currency
     */
    public function getExchangeRate(string $currencyCode): float
    {
        if ($currencyCode === $this->baseCurrency) {
            return 1.0;
        }

        $currency = Currency::where('code', $currencyCode)->first();
        
        return $currency ? $currency->exchange_rate : 1.0;
    }

    /**
     * Get popular currencies for quick access
     */
    public function getPopularCurrencies()
    {
        return Currency::where('status', 'active')
            ->where('is_popular', true)
            ->orderBy('sort_order')
            ->get();
    }

    /**
     * Get currency by IP geolocation
     */
    public function getCurrencyByIP(string $ip): ?Currency
    {
        try {
            // Use ipapi.co for geolocation (free tier available)
            $response = Http::get("https://ipapi.co/{$ip}/currency/");
            
            if ($response->successful()) {
                $currencyCode = trim($response->body());
                return Currency::where('code', $currencyCode)
                    ->where('status', 'active')
                    ->first();
            }
        } catch (\Exception $e) {
            Log::warning('Failed to detect currency by IP: ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Auto-detect and set currency based on user's location
     */
    public function autoDetectCurrency(string $ip): void
    {
        if (!session()->has('currency')) {
            $currency = $this->getCurrencyByIP($ip);
            
            if ($currency) {
                $this->setCurrency($currency->code);
                Log::info("Auto-detected currency: {$currency->code} for IP: {$ip}");
            }
        }
    }
}
