<?php

namespace App\Services\PaymentGateways;

use App\Models\Payment;
use Illuminate\Support\Facades\Http;

class FlutterwaveService
{
    protected $publicKey;
    protected $secretKey;
    protected $apiUrl = 'https://api.flutterwave.com/v3';

    public function __construct()
    {
        $this->publicKey = config('services.flutterwave.public_key');
        $this->secretKey = config('services.flutterwave.secret_key');
    }

    /**
     * Initialize payment
     */
    public function initializePayment(Payment $payment): array
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->secretKey,
        ])->post($this->apiUrl . '/payments', [
            'tx_ref' => 'PAY-' . $payment->id,
            'amount' => $payment->amount,
            'currency' => 'USD',
            'redirect_url' => route('user.payments.callback'),
            'customer' => [
                'email' => $payment->user->email,
                'name' => $payment->user->name,
            ],
            'customizations' => [
                'title' => 'Balance Top-up',
                'description' => 'Add funds to account',
            ],
            'meta' => [
                'payment_id' => $payment->id,
                'user_id' => $payment->user_id,
            ],
        ]);

        return $response->json();
    }

    /**
     * Verify transaction
     */
    public function verifyTransaction(string $transactionId): array
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->secretKey,
        ])->get($this->apiUrl . '/transactions/' . $transactionId . '/verify');

        return $response->json();
    }
}
