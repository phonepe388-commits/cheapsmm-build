<?php

namespace App\Services\PaymentGateways;

use App\Models\Payment;

class PerfectMoneyService
{
    protected $accountId;
    protected $passphrase;
    protected $alternatePassphrase;

    public function __construct()
    {
        $this->accountId = config('services.perfectmoney.account_id');
        $this->passphrase = config('services.perfectmoney.passphrase');
        $this->alternatePassphrase = config('services.perfectmoney.alternate_passphrase');
    }

    /**
     * Generate payment form data
     */
    public function getPaymentFormData(Payment $payment): array
    {
        return [
            'PAYEE_ACCOUNT' => $this->accountId,
            'PAYEE_NAME' => config('app.name'),
            'PAYMENT_ID' => $payment->id,
            'PAYMENT_AMOUNT' => $payment->amount,
            'PAYMENT_UNITS' => 'USD',
            'STATUS_URL' => route('webhooks.perfectmoney'),
            'PAYMENT_URL' => route('user.payments.success'),
            'PAYMENT_URL_METHOD' => 'POST',
            'NOPAYMENT_URL' => route('user.payments.cancel'),
            'NOPAYMENT_URL_METHOD' => 'POST',
            'SUGGESTED_MEMO' => 'Balance top-up',
            'BAGGAGE_FIELDS' => 'user_id',
            'user_id' => $payment->user_id,
        ];
    }

    /**
     * Verify payment hash
     */
    public function verifyPayment(array $data): bool
    {
        $string = $data['PAYMENT_ID'] . ':' . 
                 $data['PAYEE_ACCOUNT'] . ':' .
                 $data['PAYMENT_AMOUNT'] . ':' .
                 $data['PAYMENT_UNITS'] . ':' .
                 $data['PAYMENT_BATCH_NUM'] . ':' .
                 $data['PAYER_ACCOUNT'] . ':' .
                 strtoupper(md5($this->alternatePassphrase)) . ':' .
                 $data['TIMESTAMPGMT'];

        $hash = strtoupper(md5($string));
        
        return $hash === $data['V2_HASH'];
    }
}
