<?php

namespace App\Services\PaymentGateways;

use App\Models\Payment;
use Illuminate\Support\Facades\Http;

class CoinbaseCommerceService
{
    protected $apiKey;
    protected $apiUrl = 'https://api.commerce.coinbase.com';

    public function __construct()
    {
        $this->apiKey = config('services.coinbase.api_key');
    }

    /**
     * Create payment charge
     */
    public function createCharge(Payment $payment): array
    {
        $response = Http::withHeaders([
            'X-CC-Api-Key' => $this->apiKey,
            'X-CC-Version' => '2018-03-22',
        ])->post($this->apiUrl . '/charges', [
            'name' => 'Balance Top-up',
            'description' => 'Add funds to account',
            'pricing_type' => 'fixed_price',
            'local_price' => [
                'amount' => $payment->amount,
                'currency' => 'USD'
            ],
            'metadata' => [
                'payment_id' => $payment->id,
                'user_id' => $payment->user_id
            ],
            'redirect_url' => route('user.payments.callback'),
            'cancel_url' => route('user.payments.index')
        ]);

        return $response->json();
    }

    /**
     * Verify webhook signature
     */
    public function verifyWebhook(string $signature, string $payload): bool
    {
        $webhookSecret = config('services.coinbase.webhook_secret');
        $computedSignature = hash_hmac('sha256', $payload, $webhookSecret);
        
        return hash_equals($computedSignature, $signature);
    }
}
