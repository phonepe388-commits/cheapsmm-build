<?php

namespace App\Services\PaymentGateways;

use App\Models\Payment;

class SkrillService
{
    protected $merchantEmail;
    protected $secretWord;
    protected $apiUrl = 'https://www.moneybookers.com/app/payment.pl';

    public function __construct()
    {
        $this->merchantEmail = config('services.skrill.merchant_email');
        $this->secretWord = config('services.skrill.secret_word');
    }

    /**
     * Generate payment form data
     */
    public function getPaymentFormData(Payment $payment): array
    {
        return [
            'pay_to_email' => $this->merchantEmail,
            'transaction_id' => $payment->id,
            'return_url' => route('user.payments.success'),
            'cancel_url' => route('user.payments.cancel'),
            'status_url' => route('webhooks.skrill'),
            'language' => 'EN',
            'amount' => $payment->amount,
            'currency' => 'USD',
            'detail1_description' => 'Payment ID',
            'detail1_text' => $payment->id,
            'merchant_fields' => 'user_id',
            'user_id' => $payment->user_id,
        ];
    }

    /**
     * Verify status response
     */
    public function verifyStatusResponse(array $data): bool
    {
        $concatFields = $data['merchant_id'] . 
                       $data['transaction_id'] . 
                       strtoupper(md5($this->secretWord)) . 
                       $data['mb_amount'] . 
                       $data['mb_currency'] . 
                       $data['status'];
        
        $expectedSignature = strtoupper(md5($concatFields));
        
        return $expectedSignature === $data['md5sig'];
    }
}
