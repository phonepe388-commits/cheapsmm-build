<?php

namespace App\Services\PaymentGateways;

use App\Models\{Payment, User, PaymentMethod};
use App\Services\EmailService;
use Illuminate\Support\Facades\{DB, Log, Http};

class PayPalService
{
    protected $emailService;
    protected $baseUrl;
    protected $clientId;
    protected $clientSecret;

    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
        $this->baseUrl = config('services.paypal.mode') === 'live' 
            ? 'https://api-m.paypal.com' 
            : 'https://api-m.sandbox.paypal.com';
        $this->clientId = config('services.paypal.client_id');
        $this->clientSecret = config('services.paypal.client_secret');
    }

    /**
     * Get PayPal access token
     */
    private function getAccessToken(): string
    {
        try {
            $response = Http::withBasicAuth($this->clientId, $this->clientSecret)
                ->asForm()
                ->post("{$this->baseUrl}/v1/oauth2/token", [
                    'grant_type' => 'client_credentials'
                ]);

            if ($response->successful()) {
                return $response->json()['access_token'];
            }

            throw new \Exception('Failed to get PayPal access token');
        } catch (\Exception $e) {
            Log::error('PayPal auth error: ' . $e->getMessage());
            throw new \Exception('PayPal authentication failed');
        }
    }

    /**
     * Create PayPal order
     */
    public function createOrder(User $user, float $amount, array $metadata = []): array
    {
        try {
            // Create payment record
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $this->getPayPalMethodId(),
                'amount' => $amount,
                'currency' => 'USD',
                'status' => 'pending',
                'transaction_id' => 'paypal_' . uniqid(),
                'metadata' => $metadata
            ]);

            $token = $this->getAccessToken();

            // Create PayPal order
            $response = Http::withToken($token)
                ->post("{$this->baseUrl}/v2/checkout/orders", [
                    'intent' => 'CAPTURE',
                    'purchase_units' => [[
                        'reference_id' => $payment->id,
                        'description' => 'Add Funds - ' . config('app.name'),
                        'amount' => [
                            'currency_code' => 'USD',
                            'value' => number_format($amount, 2, '.', '')
                        ]
                    ]],
                    'application_context' => [
                        'brand_name' => config('app.name'),
                        'landing_page' => 'BILLING',
                        'user_action' => 'PAY_NOW',
                        'return_url' => route('user.payments.paypal.success'),
                        'cancel_url' => route('user.payments.create')
                    ]
                ]);

            if (!$response->successful()) {
                throw new \Exception('PayPal order creation failed: ' . $response->body());
            }

            $orderData = $response->json();

            // Update payment with PayPal order ID
            $payment->update([
                'transaction_id' => $orderData['id'],
                'metadata' => array_merge($metadata, ['paypal_order' => $orderData])
            ]);

            // Get approval URL
            $approvalUrl = collect($orderData['links'])
                ->firstWhere('rel', 'approve')['href'] ?? null;

            return [
                'payment_id' => $payment->id,
                'order_id' => $orderData['id'],
                'approval_url' => $approvalUrl
            ];

        } catch (\Exception $e) {
            Log::error('PayPal order creation error: ' . $e->getMessage());
            throw new \Exception('Failed to create PayPal order: ' . $e->getMessage());
        }
    }

    /**
     * Capture PayPal payment
     */
    public function capturePayment(string $orderId): Payment
    {
        try {
            $token = $this->getAccessToken();

            // Capture the payment
            $response = Http::withToken($token)
                ->post("{$this->baseUrl}/v2/checkout/orders/{$orderId}/capture");

            if (!$response->successful()) {
                throw new \Exception('PayPal capture failed: ' . $response->body());
            }

            $captureData = $response->json();

            // Find payment record
            $payment = Payment::where('transaction_id', $orderId)->firstOrFail();

            if ($payment->status === 'completed') {
                return $payment;
            }

            // Check capture status
            if ($captureData['status'] !== 'COMPLETED') {
                throw new \Exception('PayPal payment not completed');
            }

            // Process the payment
            DB::transaction(function() use ($payment, $captureData) {
                $payment->update([
                    'status' => 'completed',
                    'paid_at' => now(),
                    'metadata' => array_merge(
                        $payment->metadata ?? [], 
                        ['paypal_capture' => $captureData]
                    )
                ]);

                // Calculate bonus
                $bonus = $this->calculateBonus($payment->amount);
                $totalCredit = $payment->amount + $bonus;

                // Update user balance
                $payment->user->increment('balance', $totalCredit);

                // Create transaction record
                $payment->user->transactions()->create([
                    'type' => 'credit',
                    'amount' => $totalCredit,
                    'balance_before' => $payment->user->balance - $totalCredit,
                    'balance_after' => $payment->user->balance,
                    'description' => "Payment received via PayPal" . ($bonus > 0 ? " (includes ${$bonus} bonus)" : ""),
                    'reference_type' => 'payment',
                    'reference_id' => $payment->id
                ]);

                // Send success email
                $this->emailService->sendPaymentSuccess($payment);
            });

            return $payment;

        } catch (\Exception $e) {
            Log::error('PayPal capture error: ' . $e->getMessage());
            throw new \Exception('Failed to capture PayPal payment: ' . $e->getMessage());
        }
    }

    /**
     * Handle PayPal webhook
     */
    public function handleWebhook(array $payload): void
    {
        try {
            $eventType = $payload['event_type'] ?? '';
            $resource = $payload['resource'] ?? [];

            switch ($eventType) {
                case 'CHECKOUT.ORDER.APPROVED':
                    // Order approved by customer
                    $orderId = $resource['id'] ?? null;
                    if ($orderId) {
                        Log::info("PayPal order approved: {$orderId}");
                    }
                    break;

                case 'PAYMENT.CAPTURE.COMPLETED':
                    // Payment captured successfully
                    $captureId = $resource['id'] ?? null;
                    Log::info("PayPal capture completed: {$captureId}");
                    break;

                case 'PAYMENT.CAPTURE.DENIED':
                case 'PAYMENT.CAPTURE.DECLINED':
                    // Payment failed
                    $orderId = $resource['supplementary_data']['related_ids']['order_id'] ?? null;
                    if ($orderId) {
                        $payment = Payment::where('transaction_id', $orderId)->first();
                        if ($payment) {
                            $payment->update(['status' => 'failed']);
                        }
                    }
                    break;

                case 'PAYMENT.CAPTURE.REFUNDED':
                    // Payment refunded
                    $this->handleRefundWebhook($resource);
                    break;
            }

        } catch (\Exception $e) {
            Log::error('PayPal webhook error: ' . $e->getMessage());
        }
    }

    /**
     * Create refund
     */
    public function createRefund(Payment $payment, float $amount = null): array
    {
        try {
            $refundAmount = $amount ?? $payment->amount;
            $token = $this->getAccessToken();

            // Get capture ID from payment metadata
            $captureId = $payment->metadata['paypal_capture']['purchase_units'][0]['payments']['captures'][0]['id'] ?? null;

            if (!$captureId) {
                throw new \Exception('PayPal capture ID not found');
            }

            // Create refund
            $response = Http::withToken($token)
                ->post("{$this->baseUrl}/v2/payments/captures/{$captureId}/refund", [
                    'amount' => [
                        'value' => number_format($refundAmount, 2, '.', ''),
                        'currency_code' => 'USD'
                    ]
                ]);

            if (!$response->successful()) {
                throw new \Exception('PayPal refund failed: ' . $response->body());
            }

            $refundData = $response->json();

            // Update user balance
            $payment->user->decrement('balance', $refundAmount);

            // Create transaction record
            $payment->user->transactions()->create([
                'type' => 'debit',
                'amount' => $refundAmount,
                'balance_before' => $payment->user->balance + $refundAmount,
                'balance_after' => $payment->user->balance,
                'description' => "Refund for PayPal payment #{$payment->id}",
                'reference_type' => 'refund',
                'reference_id' => $payment->id
            ]);

            return $refundData;

        } catch (\Exception $e) {
            Log::error('PayPal refund error: ' . $e->getMessage());
            throw new \Exception('Failed to process PayPal refund: ' . $e->getMessage());
        }
    }

    /**
     * Calculate bonus based on amount
     */
    private function calculateBonus(float $amount): float
    {
        if ($amount >= 500) {
            return $amount * 0.15; // 15% bonus
        } elseif ($amount >= 100) {
            return $amount * 0.10; // 10% bonus
        } elseif ($amount >= 50) {
            return $amount * 0.05; // 5% bonus
        }
        return 0;
    }

    /**
     * Get PayPal payment method ID
     */
    private function getPayPalMethodId(): int
    {
        return PaymentMethod::where('code', 'paypal')->value('id') ?? 2;
    }

    /**
     * Handle refund webhook
     */
    private function handleRefundWebhook(array $resource): void
    {
        // Implementation for refund webhook
        Log::info('PayPal refund webhook received', $resource);
    }

    /**
     * Verify webhook signature
     */
    public function verifyWebhookSignature(array $headers, string $body): bool
    {
        // PayPal webhook signature verification
        // Implementation depends on PayPal's webhook security
        return true; // Simplified for now
    }
}
