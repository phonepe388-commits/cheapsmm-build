<?php

namespace App\Services\PaymentGateways;

use App\Models\{Payment, User, PaymentMethod};
use App\Services\EmailService;
use Illuminate\Support\Facades\{DB, Log, Http};

class RazorpayService
{
    protected $emailService;
    protected $keyId;
    protected $keySecret;
    protected $baseUrl = 'https://api.razorpay.com/v1';

    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
        $this->keyId = config('services.razorpay.key_id');
        $this->keySecret = config('services.razorpay.key_secret');
    }

    /**
     * Create Razorpay order
     */
    public function createOrder(User $user, float $amount, array $metadata = []): array
    {
        try {
            // Create payment record
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $this->getRazorpayMethodId(),
                'amount' => $amount,
                'currency' => 'USD',
                'status' => 'pending',
                'transaction_id' => 'razorpay_' . uniqid(),
                'metadata' => $metadata
            ]);

            // Create Razorpay order
            $response = Http::withBasicAuth($this->keyId, $this->keySecret)
                ->post("{$this->baseUrl}/orders", [
                    'amount' => $amount * 100, // Amount in cents
                    'currency' => 'USD',
                    'receipt' => 'payment_' . $payment->id,
                    'notes' => [
                        'user_id' => $user->id,
                        'payment_id' => $payment->id,
                        'user_email' => $user->email
                    ]
                ]);

            if (!$response->successful()) {
                throw new \Exception('Razorpay order creation failed: ' . $response->body());
            }

            $orderData = $response->json();

            // Update payment with Razorpay order ID
            $payment->update([
                'transaction_id' => $orderData['id'],
                'metadata' => array_merge($metadata, ['razorpay_order' => $orderData])
            ]);

            return [
                'payment_id' => $payment->id,
                'order_id' => $orderData['id'],
                'key_id' => $this->keyId,
                'amount' => $orderData['amount'],
                'currency' => $orderData['currency'],
                'name' => config('app.name'),
                'description' => 'Add Funds',
                'prefill' => [
                    'name' => $user->name,
                    'email' => $user->email
                ]
            ];

        } catch (\Exception $e) {
            Log::error('Razorpay order creation error: ' . $e->getMessage());
            throw new \Exception('Failed to create Razorpay order: ' . $e->getMessage());
        }
    }

    /**
     * Verify and capture payment
     */
    public function verifyPayment(string $orderId, string $paymentId, string $signature): Payment
    {
        try {
            // Verify signature
            $expectedSignature = hash_hmac('sha256', $orderId . '|' . $paymentId, $this->keySecret);

            if ($signature !== $expectedSignature) {
                throw new \Exception('Invalid Razorpay signature');
            }

            // Fetch payment details
            $response = Http::withBasicAuth($this->keyId, $this->keySecret)
                ->get("{$this->baseUrl}/payments/{$paymentId}");

            if (!$response->successful()) {
                throw new \Exception('Failed to fetch payment details');
            }

            $paymentData = $response->json();

            // Check payment status
            if ($paymentData['status'] !== 'captured' && $paymentData['status'] !== 'authorized') {
                throw new \Exception('Payment not successful');
            }

            // Find payment record
            $payment = Payment::where('transaction_id', $orderId)->firstOrFail();

            if ($payment->status === 'completed') {
                return $payment;
            }

            // Capture if authorized (auto-capture is usually enabled)
            if ($paymentData['status'] === 'authorized') {
                $this->capturePayment($paymentId, $paymentData['amount']);
            }

            // Process the payment
            DB::transaction(function() use ($payment, $paymentData) {
                $payment->update([
                    'status' => 'completed',
                    'paid_at' => now(),
                    'metadata' => array_merge(
                        $payment->metadata ?? [],
                        ['razorpay_payment' => $paymentData]
                    )
                ]);

                // Calculate bonus
                $bonus = $this->calculateBonus($payment->amount);
                $totalCredit = $payment->amount + $bonus;

                // Update user balance
                $payment->user->increment('balance', $totalCredit);

                // Create transaction record
                $payment->user->transactions()->create([
                    'type' => 'credit',
                    'amount' => $totalCredit,
                    'balance_before' => $payment->user->balance - $totalCredit,
                    'balance_after' => $payment->user->balance,
                    'description' => "Payment received via Razorpay" . ($bonus > 0 ? " (includes ${$bonus} bonus)" : ""),
                    'reference_type' => 'payment',
                    'reference_id' => $payment->id
                ]);

                // Send success email
                $this->emailService->sendPaymentSuccess($payment);
            });

            return $payment;

        } catch (\Exception $e) {
            Log::error('Razorpay verification error: ' . $e->getMessage());
            throw new \Exception('Failed to verify Razorpay payment: ' . $e->getMessage());
        }
    }

    /**
     * Capture authorized payment
     */
    private function capturePayment(string $paymentId, int $amount): void
    {
        Http::withBasicAuth($this->keyId, $this->keySecret)
            ->post("{$this->baseUrl}/payments/{$paymentId}/capture", [
                'amount' => $amount
            ]);
    }

    /**
     * Handle Razorpay webhook
     */
    public function handleWebhook(array $payload): void
    {
        try {
            $event = $payload['event'] ?? '';
            $paymentEntity = $payload['payload']['payment']['entity'] ?? [];

            switch ($event) {
                case 'payment.captured':
                    // Payment captured successfully
                    Log::info("Razorpay payment captured: {$paymentEntity['id']}");
                    break;

                case 'payment.failed':
                    // Payment failed
                    $orderId = $paymentEntity['order_id'] ?? null;
                    if ($orderId) {
                        $payment = Payment::where('transaction_id', $orderId)->first();
                        if ($payment) {
                            $payment->update([
                                'status' => 'failed',
                                'metadata' => array_merge(
                                    $payment->metadata ?? [],
                                    ['failure_reason' => $paymentEntity['error_description'] ?? 'Unknown']
                                )
                            ]);
                        }
                    }
                    break;

                case 'refund.created':
                case 'refund.processed':
                    $this->handleRefundWebhook($paymentEntity);
                    break;
            }

        } catch (\Exception $e) {
            Log::error('Razorpay webhook error: ' . $e->getMessage());
        }
    }

    /**
     * Create refund
     */
    public function createRefund(Payment $payment, float $amount = null): array
    {
        try {
            $refundAmount = ($amount ?? $payment->amount) * 100; // Convert to cents

            // Get payment ID from metadata
            $paymentId = $payment->metadata['razorpay_payment']['id'] ?? null;

            if (!$paymentId) {
                throw new \Exception('Razorpay payment ID not found');
            }

            // Create refund
            $response = Http::withBasicAuth($this->keyId, $this->keySecret)
                ->post("{$this->baseUrl}/payments/{$paymentId}/refund", [
                    'amount' => $refundAmount
                ]);

            if (!$response->successful()) {
                throw new \Exception('Razorpay refund failed: ' . $response->body());
            }

            $refundData = $response->json();

            // Update user balance
            $refundAmountUSD = $refundAmount / 100;
            $payment->user->decrement('balance', $refundAmountUSD);

            // Create transaction record
            $payment->user->transactions()->create([
                'type' => 'debit',
                'amount' => $refundAmountUSD,
                'balance_before' => $payment->user->balance + $refundAmountUSD,
                'balance_after' => $payment->user->balance,
                'description' => "Refund for Razorpay payment #{$payment->id}",
                'reference_type' => 'refund',
                'reference_id' => $payment->id
            ]);

            return $refundData;

        } catch (\Exception $e) {
            Log::error('Razorpay refund error: ' . $e->getMessage());
            throw new \Exception('Failed to process Razorpay refund: ' . $e->getMessage());
        }
    }

    /**
     * Calculate bonus based on amount
     */
    private function calculateBonus(float $amount): float
    {
        if ($amount >= 500) {
            return $amount * 0.15;
        } elseif ($amount >= 100) {
            return $amount * 0.10;
        } elseif ($amount >= 50) {
            return $amount * 0.05;
        }
        return 0;
    }

    /**
     * Get Razorpay payment method ID
     */
    private function getRazorpayMethodId(): int
    {
        return PaymentMethod::where('code', 'razorpay')->value('id') ?? 3;
    }

    /**
     * Handle refund webhook
     */
    private function handleRefundWebhook(array $entity): void
    {
        Log::info('Razorpay refund webhook received', $entity);
    }

    /**
     * Verify webhook signature
     */
    public function verifyWebhookSignature(string $signature, string $body): bool
    {
        $expectedSignature = hash_hmac('sha256', $body, config('services.razorpay.webhook_secret'));
        return hash_equals($expectedSignature, $signature);
    }
}
