<?php

namespace App\Services\PaymentGateways;

use App\Models\Payment;

class PayeerService
{
    protected $merchantId;
    protected $secretKey;

    public function __construct()
    {
        $this->merchantId = config('services.payeer.merchant_id');
        $this->secretKey = config('services.payeer.secret_key');
    }

    /**
     * Generate payment form data
     */
    public function getPaymentFormData(Payment $payment): array
    {
        $orderDescription = base64_encode('Balance top-up #' . $payment->id);
        
        $signString = $this->merchantId . ':' . 
                     $payment->id . ':' . 
                     $payment->amount . ':' .
                     'USD:' . 
                     $orderDescription . ':' .
                     $this->secretKey;
        
        return [
            'm_shop' => $this->merchantId,
            'm_orderid' => $payment->id,
            'm_amount' => number_format($payment->amount, 2, '.', ''),
            'm_curr' => 'USD',
            'm_desc' => $orderDescription,
            'm_sign' => strtoupper(hash('sha256', $signString)),
            'm_params' => base64_encode(json_encode(['user_id' => $payment->user_id])),
        ];
    }

    /**
     * Verify IPN notification
     */
    public function verifyIPN(array $data): bool
    {
        $signString = $data['m_operation_id'] . ':' .
                     $data['m_operation_ps'] . ':' .
                     $data['m_operation_date'] . ':' .
                     $data['m_operation_pay_date'] . ':' .
                     $data['m_shop'] . ':' .
                     $data['m_orderid'] . ':' .
                     $data['m_amount'] . ':' .
                     $data['m_curr'] . ':' .
                     $data['m_desc'] . ':' .
                     $data['m_status'] . ':' .
                     $this->secretKey;

        $sign = strtoupper(hash('sha256', $signString));
        
        return $sign === $data['m_sign'] && $data['m_status'] === 'success';
    }
}
