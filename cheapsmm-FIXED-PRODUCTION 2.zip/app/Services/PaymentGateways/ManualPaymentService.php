<?php

namespace App\Services\PaymentGateways;

use App\Models\{Payment, User, PaymentMethod};
use App\Services\EmailService;
use Illuminate\Support\Facades\{DB, Log};

class ManualPaymentService
{
    protected $emailService;

    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * Create manual payment request
     */
    public function createPaymentRequest(User $user, float $amount, string $method, array $details = []): Payment
    {
        try {
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $this->getManualMethodId($method),
                'amount' => $amount,
                'currency' => 'USD',
                'status' => 'pending',
                'transaction_id' => 'manual_' . uniqid(),
                'metadata' => [
                    'manual_method' => $method,
                    'payment_details' => $details,
                    'submitted_at' => now()->toDateTimeString(),
                    'requires_approval' => true
                ]
            ]);

            // Notify admins
            $this->notifyAdmins($payment);

            return $payment;

        } catch (\Exception $e) {
            Log::error('Manual payment request error: ' . $e->getMessage());
            throw new \Exception('Failed to create payment request: ' . $e->getMessage());
        }
    }

    /**
     * Submit bank transfer proof
     */
    public function submitBankTransferProof(User $user, float $amount, array $data): Payment
    {
        $validated = [
            'transaction_ref' => $data['transaction_ref'] ?? null,
            'sender_name' => $data['sender_name'] ?? $user->name,
            'sender_bank' => $data['sender_bank'] ?? null,
            'transfer_date' => $data['transfer_date'] ?? now()->toDateString(),
            'receipt_file' => $data['receipt_file'] ?? null, // File path after upload
            'notes' => $data['notes'] ?? null
        ];

        return $this->createPaymentRequest($user, $amount, 'bank_transfer', $validated);
    }

    /**
     * Admin approves manual payment
     */
    public function approvePayment(Payment $payment, int $adminId, string $notes = null): Payment
    {
        try {
            if ($payment->status === 'completed') {
                throw new \Exception('Payment already approved');
            }

            if ($payment->status === 'rejected') {
                throw new \Exception('Cannot approve rejected payment');
            }

            DB::transaction(function() use ($payment, $adminId, $notes) {
                // Update payment status
                $payment->update([
                    'status' => 'completed',
                    'paid_at' => now(),
                    'metadata' => array_merge($payment->metadata ?? [], [
                        'approved_by' => $adminId,
                        'approved_at' => now()->toDateTimeString(),
                        'admin_notes' => $notes
                    ])
                ]);

                // Calculate bonus
                $bonus = $this->calculateBonus($payment->amount);
                $totalCredit = $payment->amount + $bonus;

                // Update user balance
                $payment->user->increment('balance', $totalCredit);

                // Create transaction record
                $payment->user->transactions()->create([
                    'type' => 'credit',
                    'amount' => $totalCredit,
                    'balance_before' => $payment->user->balance - $totalCredit,
                    'balance_after' => $payment->user->balance,
                    'description' => "Manual payment approved" . ($bonus > 0 ? " (includes ${$bonus} bonus)" : ""),
                    'reference_type' => 'payment',
                    'reference_id' => $payment->id
                ]);

                // Log activity
                \App\Models\ActivityLog::create([
                    'user_id' => $payment->user_id,
                    'admin_id' => $adminId,
                    'action' => 'manual_payment_approved',
                    'description' => "Manual payment #{$payment->id} approved for ${$payment->amount}",
                    'metadata' => ['payment_id' => $payment->id]
                ]);

                // Send success email
                $this->emailService->sendPaymentSuccess($payment);

                // Notify user
                $payment->user->notifications()->create([
                    'type' => 'payment_approved',
                    'title' => 'Payment Approved',
                    'message' => "Your payment of ${$payment->amount} has been approved and added to your account.",
                    'data' => ['payment_id' => $payment->id]
                ]);
            });

            return $payment->fresh();

        } catch (\Exception $e) {
            Log::error('Manual payment approval error: ' . $e->getMessage());
            throw new \Exception('Failed to approve payment: ' . $e->getMessage());
        }
    }

    /**
     * Admin rejects manual payment
     */
    public function rejectPayment(Payment $payment, int $adminId, string $reason): Payment
    {
        try {
            if ($payment->status === 'completed') {
                throw new \Exception('Cannot reject completed payment');
            }

            $payment->update([
                'status' => 'rejected',
                'metadata' => array_merge($payment->metadata ?? [], [
                    'rejected_by' => $adminId,
                    'rejected_at' => now()->toDateTimeString(),
                    'rejection_reason' => $reason
                ])
            ]);

            // Log activity
            \App\Models\ActivityLog::create([
                'user_id' => $payment->user_id,
                'admin_id' => $adminId,
                'action' => 'manual_payment_rejected',
                'description' => "Manual payment #{$payment->id} rejected: {$reason}",
                'metadata' => ['payment_id' => $payment->id]
            ]);

            // Notify user
            $payment->user->notifications()->create([
                'type' => 'payment_rejected',
                'title' => 'Payment Rejected',
                'message' => "Your payment of ${$payment->amount} was rejected. Reason: {$reason}",
                'data' => ['payment_id' => $payment->id, 'reason' => $reason]
            ]);

            return $payment;

        } catch (\Exception $e) {
            Log::error('Manual payment rejection error: ' . $e->getMessage());
            throw new \Exception('Failed to reject payment: ' . $e->getMessage());
        }
    }

    /**
     * Get pending manual payments for admin review
     */
    public function getPendingPayments()
    {
        return Payment::whereIn('payment_method_id', function($query) {
                $query->select('id')
                    ->from('payment_methods')
                    ->where('type', 'manual');
            })
            ->where('status', 'pending')
            ->with(['user', 'paymentMethod'])
            ->latest()
            ->get();
    }

    /**
     * Calculate bonus based on amount
     */
    private function calculateBonus(float $amount): float
    {
        if ($amount >= 500) {
            return $amount * 0.15;
        } elseif ($amount >= 100) {
            return $amount * 0.10;
        } elseif ($amount >= 50) {
            return $amount * 0.05;
        }
        return 0;
    }

    /**
     * Get manual payment method ID by code
     */
    private function getManualMethodId(string $method): int
    {
        return PaymentMethod::where('code', $method)->value('id') 
            ?? PaymentMethod::where('type', 'manual')->value('id') 
            ?? 10;
    }

    /**
     * Notify admins of new payment request
     */
    private function notifyAdmins(Payment $payment): void
    {
        $admins = \App\Models\Admin::where('status', 'active')->get();

        foreach ($admins as $admin) {
            $admin->notifications()->create([
                'type' => 'manual_payment_pending',
                'title' => 'New Payment Request',
                'message' => "{$payment->user->name} submitted a payment of ${$payment->amount} for review",
                'data' => ['payment_id' => $payment->id]
            ]);
        }
    }

    /**
     * Get payment instructions for manual methods
     */
    public function getPaymentInstructions(string $method): array
    {
        $instructions = [
            'bank_transfer' => [
                'title' => 'Bank Transfer Instructions',
                'steps' => [
                    'Transfer the amount to our bank account',
                    'Use your User ID as reference',
                    'Upload the transfer receipt',
                    'Wait for admin approval (usually 1-24 hours)'
                ],
                'bank_details' => [
                    'Bank Name' => setting('bank_name', 'Your Bank'),
                    'Account Name' => setting('bank_account_name', 'Company Name'),
                    'Account Number' => setting('bank_account_number', '1234567890'),
                    'Swift Code' => setting('bank_swift_code', 'BANKUS33'),
                    'IBAN' => setting('bank_iban', 'US12345678901234567890')
                ]
            ],
            'cash_deposit' => [
                'title' => 'Cash Deposit Instructions',
                'steps' => [
                    'Deposit cash at any branch',
                    'Get deposit receipt',
                    'Upload receipt with deposit slip',
                    'Enter deposit reference number'
                ]
            ],
            'western_union' => [
                'title' => 'Western Union Instructions',
                'steps' => [
                    'Send money via Western Union',
                    'Use MTCN as reference',
                    'Upload transfer receipt',
                    'Provide sender details'
                ]
            ]
        ];

        return $instructions[$method] ?? [];
    }
}
