<?php
namespace App\Services;
use App\Models\Language;

class LanguageService
{
    public function setLanguage($code) {
        $language = Language::where('code', $code)->where('is_active', true)->first();
        if ($language) {
            session(['locale' => $code]);
            app()->setLocale($code);
            return true;
        }
        return false;
    }
    
    public function getActive() {
        return Language::where('is_active', true)->get();
    }
}
