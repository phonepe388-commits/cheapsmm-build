<?php

namespace App\Services;

use App\Models\{User, Order, Service};

class AIService
{
    /**
     * Get service recommendations for user
     */
    public function getServiceRecommendations(User $user, int $limit = 5): array
    {
        // Get user's order history
        $orderedServices = $user->orders()
            ->select('service_id', \DB::raw('COUNT(*) as count'))
            ->groupBy('service_id')
            ->pluck('count', 'service_id');

        // Find similar services
        $recommendations = [];
        
        foreach ($orderedServices as $serviceId => $count) {
            $service = Service::find($serviceId);
            
            if ($service) {
                // Find services in same category
                $similar = Service::where('category_id', $service->category_id)
                    ->where('id', '!=', $serviceId)
                    ->whereNotIn('id', $orderedServices->keys())
                    ->limit(2)
                    ->get();

                foreach ($similar as $s) {
                    $recommendations[] = [
                        'service' => $s,
                        'reason' => 'Similar to ' . $service->name,
                        'score' => 0.8
                    ];
                }
            }
        }

        // Add trending services
        $trending = Service::withCount(['orders' => function($q) {
            $q->where('created_at', '>', now()->subDays(7));
        }])
        ->orderByDesc('orders_count')
        ->limit(3)
        ->get();

        foreach ($trending as $service) {
            $recommendations[] = [
                'service' => $service,
                'reason' => 'Trending this week',
                'score' => 0.7
            ];
        }

        // Sort by score and limit
        usort($recommendations, fn($a, $b) => $b['score'] <=> $a['score']);
        
        return array_slice($recommendations, 0, $limit);
    }

    /**
     * Detect suspicious activity
     */
    public function detectSuspiciousActivity(User $user): array
    {
        $flags = [];

        // Check for rapid orders
        $recentOrders = $user->orders()
            ->where('created_at', '>', now()->subHour())
            ->count();

        if ($recentOrders > 50) {
            $flags[] = [
                'type' => 'rapid_orders',
                'severity' => 'high',
                'message' => "User placed {$recentOrders} orders in last hour"
            ];
        }

        // Check for unusual spending
        $avgSpending = $user->orders()->avg('charge');
        $recentSpending = $user->orders()
            ->where('created_at', '>', now()->subDay())
            ->sum('charge');

        if ($avgSpending > 0 && $recentSpending > ($avgSpending * 10)) {
            $flags[] = [
                'type' => 'unusual_spending',
                'severity' => 'medium',
                'message' => "Spending 10x above average"
            ];
        }

        // Check for multiple failed payments
        $failedPayments = $user->payments()
            ->where('status', 'failed')
            ->where('created_at', '>', now()->subDay())
            ->count();

        if ($failedPayments > 5) {
            $flags[] = [
                'type' => 'multiple_failures',
                'severity' => 'medium',
                'message' => "{$failedPayments} failed payments in 24h"
            ];
        }

        return $flags;
    }

    /**
     * Predict order completion time
     */
    public function predictCompletionTime(Service $service): int
    {
        // Get average completion time for this service
        $avgMinutes = Order::where('service_id', $service->id)
            ->where('status', 'completed')
            ->whereNotNull('completed_at')
            ->get()
            ->avg(function($order) {
                return $order->created_at->diffInMinutes($order->completed_at);
            });

        return $avgMinutes ?: 60; // Default to 60 minutes
    }

    /**
     * Calculate customer churn risk
     */
    public function calculateChurnRisk(User $user): array
    {
        $lastOrder = $user->orders()->latest()->first();
        $totalOrders = $user->orders()->count();
        
        $risk = 'low';
        $score = 0;

        // No recent activity
        if (!$lastOrder || $lastOrder->created_at->lt(now()->subDays(30))) {
            $score += 40;
        }

        // Low order count
        if ($totalOrders < 5) {
            $score += 30;
        }

        // Low balance
        if ($user->balance < 10) {
            $score += 20;
        }

        // Failed payments
        if ($user->payments()->where('status', 'failed')->count() > 2) {
            $score += 10;
        }

        if ($score >= 70) {
            $risk = 'high';
        } elseif ($score >= 40) {
            $risk = 'medium';
        }

        return [
            'risk' => $risk,
            'score' => $score,
            'recommendations' => $this->getRetentionRecommendations($score)
        ];
    }

    /**
     * Get retention recommendations
     */
    private function getRetentionRecommendations(int $score): array
    {
        $recommendations = [];

        if ($score >= 40) {
            $recommendations[] = 'Send promotional discount code';
            $recommendations[] = 'Reach out with personalized email';
        }

        if ($score >= 70) {
            $recommendations[] = 'Offer special retention deal';
            $recommendations[] = 'Schedule call with account manager';
        }

        return $recommendations;
    }
}
