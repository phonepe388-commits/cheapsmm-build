<?php

namespace App\Services;

use App\Models\{ChildPanel, ChildPanelServicePricing, ChildPanelUser, Order, Service};
use Illuminate\Support\Facades\DB;

class ChildPanelService
{
    /**
     * Create new child panel
     */
    public function createPanel(array $data): ChildPanel
    {
        $panel = ChildPanel::create([
            'user_id' => $data['user_id'],
            'name' => $data['name'],
            'subdomain' => $data['subdomain'] ?? $this->generateSubdomain($data['name']),
            'domain' => $data['domain'] ?? null,
            'markup_percentage' => $data['markup_percentage'] ?? 20.00,
            'currency' => $data['currency'] ?? 'USD',
            'language' => $data['language'] ?? 'en',
            'status' => 'active',
        ]);

        // Create default pricing for all active services
        $this->createDefaultPricing($panel);

        return $panel;
    }

    /**
     * Generate unique subdomain
     */
    private function generateSubdomain(string $name): string
    {
        $base = \Str::slug($name);
        $unique = $base . '-' . strtoupper(substr(uniqid(), -6));
        
        return $unique;
    }

    /**
     * Create default pricing for all services
     */
    public function createDefaultPricing(ChildPanel $panel): void
    {
        $services = Service::where('status', 'active')->get();
        $markup = $panel->markup_percentage;

        foreach ($services as $service) {
            $markedUpPrice = $service->price_per_1000 * (1 + ($markup / 100));

            ChildPanelServicePricing::create([
                'child_panel_id' => $panel->id,
                'service_id' => $service->id,
                'price_per_1000' => round($markedUpPrice, 2),
                'min_quantity' => $service->min_quantity,
                'max_quantity' => $service->max_quantity,
                'status' => 'active',
            ]);
        }
    }

    /**
     * Update service pricing
     */
    public function updateServicePricing(ChildPanel $panel, int $serviceId, float $price): void
    {
        ChildPanelServicePricing::updateOrCreate(
            [
                'child_panel_id' => $panel->id,
                'service_id' => $serviceId,
            ],
            [
                'price_per_1000' => $price,
            ]
        );
    }

    /**
     * Process order from child panel
     * 
     * CRITICAL: This deducts from BOTH child user AND panel owner
     */
    public function processOrder(ChildPanel $panel, ChildPanelUser $childUser, array $orderData): Order
    {
        return DB::transaction(function () use ($panel, $childUser, $orderData) {
            // Get service and pricing
            $service = Service::findOrFail($orderData['service_id']);
            $pricing = ChildPanelServicePricing::where('child_panel_id', $panel->id)
                ->where('service_id', $service->id)
                ->firstOrFail();

            // Calculate charges
            $childUserCharge = ($orderData['quantity'] / 1000) * $pricing->price_per_1000;
            $panelOwnerCost = ($orderData['quantity'] / 1000) * $service->price_per_1000;

            // CRITICAL: Check BOTH balances
            if ($childUser->balance < $childUserCharge) {
                throw new \Exception('Insufficient balance in child user account');
            }

            if ($panel->balance < $panelOwnerCost) {
                throw new \Exception('Insufficient balance in child panel');
            }

            // CRITICAL: Deduct from child user
            $childUser->decrement('balance', $childUserCharge);

            // CRITICAL: Deduct from panel owner
            $deducted = $panel->deductBalance($panelOwnerCost);
            if (!$deducted) {
                throw new \Exception('Failed to deduct from panel balance');
            }

            // Create order
            $order = Order::create([
                'user_id' => $panel->user_id, // Panel owner
                'child_panel_id' => $panel->id,
                'child_panel_user_id' => $childUser->id,
                'service_id' => $service->id,
                'link' => $orderData['link'],
                'quantity' => $orderData['quantity'],
                'charge' => $panelOwnerCost, // Owner's cost
                'status' => 'pending',
            ]);

            // Record profit for panel owner
            $profit = $childUserCharge - $panelOwnerCost;
            $panel->increment('balance', $profit);

            return $order;
        });
    }

    /**
     * Get panel statistics
     */
    public function getStatistics(ChildPanel $panel): array
    {
        return [
            'total_users' => $panel->users()->count(),
            'total_orders' => Order::where('child_panel_id', $panel->id)->count(),
            'total_revenue' => Order::where('child_panel_id', $panel->id)->sum('charge'),
            'balance' => $panel->balance,
        ];
    }
}
