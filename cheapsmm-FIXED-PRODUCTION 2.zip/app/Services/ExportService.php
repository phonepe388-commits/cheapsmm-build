<?php

namespace App\Services;

use App\Models\{Order, Payment, User, Transaction};
use Illuminate\Support\Collection;

class ExportService
{
    /**
     * Export orders to CSV
     */
    public function exportOrders($query, string $format = 'csv'): string
    {
        $orders = $query->with(['user', 'service'])->get();

        if ($format === 'csv') {
            return $this->generateOrdersCsv($orders);
        }

        // Future: Excel format using PhpSpreadsheet
        return $this->generateOrdersCsv($orders);
    }

    /**
     * Generate CSV for orders
     */
    private function generateOrdersCsv(Collection $orders): string
    {
        $csv = "Order ID,User,Email,Service,Link,Quantity,Start Count,Remains,Charge,Status,Created At,Completed At\n";

        foreach ($orders as $order) {
            $csv .= sprintf(
                "%d,%s,%s,%s,%s,%d,%d,%d,%.2f,%s,%s,%s\n",
                $order->id,
                $this->escapeCsv($order->user->name ?? 'N/A'),
                $this->escapeCsv($order->user->email ?? 'N/A'),
                $this->escapeCsv($order->service->name ?? 'N/A'),
                $this->escapeCsv($order->link),
                $order->quantity,
                $order->start_count ?? 0,
                $order->remain ?? 0,
                $order->charge,
                $order->status,
                $order->created_at->format('Y-m-d H:i:s'),
                $order->completed_at ? $order->completed_at->format('Y-m-d H:i:s') : 'N/A'
            );
        }

        return $csv;
    }

    /**
     * Export payments to CSV
     */
    public function exportPayments($query, string $format = 'csv'): string
    {
        $payments = $query->with(['user', 'paymentMethod'])->get();

        if ($format === 'csv') {
            return $this->generatePaymentsCsv($payments);
        }

        return $this->generatePaymentsCsv($payments);
    }

    /**
     * Generate CSV for payments
     */
    private function generatePaymentsCsv(Collection $payments): string
    {
        $csv = "Payment ID,User,Email,Payment Method,Amount,Currency,Transaction ID,Status,Created At,Paid At\n";

        foreach ($payments as $payment) {
            $csv .= sprintf(
                "%d,%s,%s,%s,%.2f,%s,%s,%s,%s,%s\n",
                $payment->id,
                $this->escapeCsv($payment->user->name ?? 'N/A'),
                $this->escapeCsv($payment->user->email ?? 'N/A'),
                $this->escapeCsv($payment->paymentMethod->name ?? 'N/A'),
                $payment->amount,
                $payment->currency ?? 'USD',
                $this->escapeCsv($payment->transaction_id ?? 'N/A'),
                $payment->status,
                $payment->created_at->format('Y-m-d H:i:s'),
                $payment->paid_at ? $payment->paid_at->format('Y-m-d H:i:s') : 'N/A'
            );
        }

        return $csv;
    }

    /**
     * Export users to CSV
     */
    public function exportUsers($query, string $format = 'csv'): string
    {
        $users = $query->get();

        if ($format === 'csv') {
            return $this->generateUsersCsv($users);
        }

        return $this->generateUsersCsv($users);
    }

    /**
     * Generate CSV for users
     */
    private function generateUsersCsv(Collection $users): string
    {
        $csv = "User ID,Name,Email,Balance,Total Spent,Total Orders,Status,Registered At,Last Login\n";

        foreach ($users as $user) {
            $csv .= sprintf(
                "%d,%s,%s,%.2f,%.2f,%d,%s,%s,%s\n",
                $user->id,
                $this->escapeCsv($user->name),
                $this->escapeCsv($user->email),
                $user->balance ?? 0,
                $user->orders()->sum('charge') ?? 0,
                $user->orders()->count() ?? 0,
                $user->status ?? 'active',
                $user->created_at->format('Y-m-d H:i:s'),
                $user->last_login_at ? $user->last_login_at->format('Y-m-d H:i:s') : 'Never'
            );
        }

        return $csv;
    }

    /**
     * Export transactions to CSV
     */
    public function exportTransactions($query, string $format = 'csv'): string
    {
        $transactions = $query->with('user')->get();

        if ($format === 'csv') {
            return $this->generateTransactionsCsv($transactions);
        }

        return $this->generateTransactionsCsv($transactions);
    }

    /**
     * Generate CSV for transactions
     */
    private function generateTransactionsCsv(Collection $transactions): string
    {
        $csv = "Transaction ID,User,Type,Amount,Balance Before,Balance After,Description,Created At\n";

        foreach ($transactions as $transaction) {
            $csv .= sprintf(
                "%d,%s,%s,%.2f,%.2f,%.2f,%s,%s\n",
                $transaction->id,
                $this->escapeCsv($transaction->user->name ?? 'N/A'),
                $transaction->type,
                $transaction->amount,
                $transaction->balance_before ?? 0,
                $transaction->balance_after ?? 0,
                $this->escapeCsv($transaction->description ?? ''),
                $transaction->created_at->format('Y-m-d H:i:s')
            );
        }

        return $csv;
    }

    /**
     * Generate summary report
     */
    public function generateSummaryReport(array $filters = []): array
    {
        $dateFrom = $filters['date_from'] ?? now()->subMonth();
        $dateTo = $filters['date_to'] ?? now();

        // Orders statistics
        $ordersQuery = Order::whereBetween('created_at', [$dateFrom, $dateTo]);
        $orderStats = [
            'total_orders' => $ordersQuery->count(),
            'total_revenue' => $ordersQuery->sum('charge'),
            'completed_orders' => $ordersQuery->where('status', 'completed')->count(),
            'pending_orders' => $ordersQuery->where('status', 'pending')->count(),
            'cancelled_orders' => $ordersQuery->where('status', 'cancelled')->count(),
            'average_order_value' => $ordersQuery->avg('charge') ?? 0
        ];

        // Payments statistics
        $paymentsQuery = Payment::whereBetween('created_at', [$dateFrom, $dateTo]);
        $paymentStats = [
            'total_payments' => $paymentsQuery->count(),
            'total_deposited' => $paymentsQuery->where('status', 'completed')->sum('amount'),
            'pending_payments' => $paymentsQuery->where('status', 'pending')->count(),
            'average_payment' => $paymentsQuery->where('status', 'completed')->avg('amount') ?? 0
        ];

        // User statistics
        $userStats = [
            'new_users' => User::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'active_users' => User::where('status', 'active')->count(),
            'total_users' => User::count()
        ];

        // Top services
        $topServices = Order::whereBetween('created_at', [$dateFrom, $dateTo])
            ->select('service_id')
            ->selectRaw('COUNT(*) as order_count')
            ->selectRaw('SUM(charge) as total_revenue')
            ->groupBy('service_id')
            ->orderByDesc('order_count')
            ->limit(10)
            ->with('service')
            ->get();

        return [
            'period' => [
                'from' => $dateFrom->format('Y-m-d'),
                'to' => $dateTo->format('Y-m-d')
            ],
            'orders' => $orderStats,
            'payments' => $paymentStats,
            'users' => $userStats,
            'top_services' => $topServices
        ];
    }

    /**
     * Export summary report to CSV
     */
    public function exportSummaryReport(array $report): string
    {
        $csv = "SUMMARY REPORT\n";
        $csv .= "Period: {$report['period']['from']} to {$report['period']['to']}\n\n";

        $csv .= "ORDERS\n";
        $csv .= "Metric,Value\n";
        foreach ($report['orders'] as $key => $value) {
            $csv .= sprintf("%s,%.2f\n", ucfirst(str_replace('_', ' ', $key)), $value);
        }

        $csv .= "\nPAYMENTS\n";
        $csv .= "Metric,Value\n";
        foreach ($report['payments'] as $key => $value) {
            $csv .= sprintf("%s,%.2f\n", ucfirst(str_replace('_', ' ', $key)), $value);
        }

        $csv .= "\nUSERS\n";
        $csv .= "Metric,Value\n";
        foreach ($report['users'] as $key => $value) {
            $csv .= sprintf("%s,%d\n", ucfirst(str_replace('_', ' ', $key)), $value);
        }

        $csv .= "\nTOP SERVICES\n";
        $csv .= "Service,Orders,Revenue\n";
        foreach ($report['top_services'] as $service) {
            $csv .= sprintf(
                "%s,%d,%.2f\n",
                $this->escapeCsv($service->service->name ?? 'N/A'),
                $service->order_count,
                $service->total_revenue
            );
        }

        return $csv;
    }

    /**
     * Escape CSV values
     */
    private function escapeCsv(string $value): string
    {
        // Escape quotes and wrap in quotes if contains comma, quote, or newline
        if (strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
            return '"' . str_replace('"', '""', $value) . '"';
        }

        return $value;
    }

    /**
     * Get filename for export
     */
    public function getFilename(string $type, string $format = 'csv'): string
    {
        $date = now()->format('Y-m-d_His');
        return "{$type}_export_{$date}.{$format}";
    }
}
