<?php

namespace App\Services;

use App\Models\{Coupon, User};
use Carbon\Carbon;

class CouponService
{
    /**
     * Validate and apply coupon
     */
    public function validateCoupon(string $code, User $user, float $amount): array
    {
        $coupon = Coupon::where('code', strtoupper($code))
            ->where('status', 'active')
            ->first();

        if (!$coupon) {
            return [
                'valid' => false,
                'error' => 'Invalid coupon code'
            ];
        }

        // Check expiry
        if ($coupon->expires_at && Carbon::now()->greaterThan($coupon->expires_at)) {
            return [
                'valid' => false,
                'error' => 'Coupon has expired'
            ];
        }

        // Check usage limit
        if ($coupon->max_uses && $coupon->uses >= $coupon->max_uses) {
            return [
                'valid' => false,
                'error' => 'Coupon usage limit reached'
            ];
        }

        // Check per-user limit
        if ($coupon->max_uses_per_user) {
            $userUses = $coupon->usageLogs()
                ->where('user_id', $user->id)
                ->count();

            if ($userUses >= $coupon->max_uses_per_user) {
                return [
                    'valid' => false,
                    'error' => 'You have already used this coupon the maximum number of times'
                ];
            }
        }

        // Check minimum amount
        if ($coupon->min_amount && $amount < $coupon->min_amount) {
            return [
                'valid' => false,
                'error' => "Minimum amount required: $" . number_format($coupon->min_amount, 2)
            ];
        }

        // Calculate discount
        $discount = $this->calculateDiscount($coupon, $amount);

        return [
            'valid' => true,
            'coupon' => $coupon,
            'discount' => $discount,
            'final_amount' => max(0, $amount - $discount)
        ];
    }

    /**
     * Calculate discount amount
     */
    public function calculateDiscount(Coupon $coupon, float $amount): float
    {
        if ($coupon->type === 'percentage') {
            $discount = ($amount * $coupon->value) / 100;
            
            // Apply max discount if set
            if ($coupon->max_discount && $discount > $coupon->max_discount) {
                $discount = $coupon->max_discount;
            }
            
            return $discount;
        }

        // Fixed amount
        return min($coupon->value, $amount);
    }

    /**
     * Apply coupon to transaction
     */
    public function applyCoupon(Coupon $coupon, User $user, float $amount, string $type = 'order'): void
    {
        // Increment usage
        $coupon->increment('uses');

        // Log usage
        $coupon->usageLogs()->create([
            'user_id' => $user->id,
            'discount_amount' => $this->calculateDiscount($coupon, $amount),
            'original_amount' => $amount,
            'usage_type' => $type
        ]);

        // Log activity
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'coupon_used',
            'description' => "Used coupon: {$coupon->code}",
            'metadata' => [
                'coupon_id' => $coupon->id,
                'discount' => $this->calculateDiscount($coupon, $amount)
            ]
        ]);
    }

    /**
     * Generate random coupon code
     */
    public static function generateCode(int $length = 8): string
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';

        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }

        // Ensure uniqueness
        if (Coupon::where('code', $code)->exists()) {
            return self::generateCode($length);
        }

        return $code;
    }

    /**
     * Get active coupons for user
     */
    public function getActiveCoupons(User $user = null): \Illuminate\Database\Eloquent\Collection
    {
        $query = Coupon::where('status', 'active')
            ->where(function($q) {
                $q->whereNull('expires_at')
                  ->orWhere('expires_at', '>', Carbon::now());
            })
            ->where(function($q) {
                $q->whereNull('max_uses')
                  ->orWhereRaw('uses < max_uses');
            });

        if ($user) {
            // Filter out coupons user has maxed out
            $query->where(function($q) use ($user) {
                $q->whereNull('max_uses_per_user')
                  ->orWhereDoesntHave('usageLogs', function($q2) use ($user) {
                      $q2->where('user_id', $user->id)
                         ->havingRaw('COUNT(*) >= max_uses_per_user');
                  });
            });
        }

        return $query->orderBy('created_at', 'desc')->get();
    }
}
