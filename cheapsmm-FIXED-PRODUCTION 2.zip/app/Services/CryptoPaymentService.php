<?php

namespace App\Services;

use App\Models\{Payment, User};

class CryptoPaymentService
{
    /**
     * Supported cryptocurrencies
     */
    private $supported = [
        'BTC' => ['name' => 'Bitcoin', 'decimals' => 8],
        'ETH' => ['name' => 'Ethereum', 'decimals' => 18],
        'USDT' => ['name' => 'Tether', 'decimals' => 6],
        'BNB' => ['name' => 'Binance Coin', 'decimals' => 18],
    ];

    /**
     * Get payment address for cryptocurrency
     */
    public function getPaymentAddress(string $crypto): string
    {
        // In production, generate unique address for each payment
        // This is placeholder - integrate with actual wallet API
        $addresses = [
            'BTC' => config('crypto.btc_address', '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'),
            'ETH' => config('crypto.eth_address', '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb'),
            'USDT' => config('crypto.usdt_address', '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb'),
            'BNB' => config('crypto.bnb_address', '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb'),
        ];

        return $addresses[$crypto] ?? '';
    }

    /**
     * Create crypto payment
     */
    public function createPayment(User $user, float $amount, string $crypto): Payment
    {
        $cryptoAmount = $this->convertToCrypto($amount, $crypto);

        return Payment::create([
            'user_id' => $user->id,
            'payment_method_id' => null, // Crypto payment
            'amount' => $amount,
            'currency' => 'USD',
            'crypto_currency' => $crypto,
            'crypto_amount' => $cryptoAmount,
            'crypto_address' => $this->getPaymentAddress($crypto),
            'status' => 'pending',
            'transaction_id' => 'crypto_' . uniqid()
        ]);
    }

    /**
     * Convert USD to cryptocurrency
     */
    private function convertToCrypto(float $usdAmount, string $crypto): float
    {
        // Mock conversion rates - integrate with actual API like CoinGecko
        $rates = [
            'BTC' => 43000,
            'ETH' => 2300,
            'USDT' => 1,
            'BNB' => 310,
        ];

        return $usdAmount / ($rates[$crypto] ?? 1);
    }

    /**
     * Verify payment (webhook from payment processor)
     */
    public function verifyPayment(string $transactionId, string $txHash): bool
    {
        $payment = Payment::where('transaction_id', $transactionId)->first();

        if (!$payment) {
            return false;
        }

        // Verify on blockchain (integrate with block explorer API)
        // For now, mark as completed
        $payment->update([
            'status' => 'completed',
            'crypto_tx_hash' => $txHash
        ]);

        // Add funds to user
        $payment->user->increment('balance', $payment->amount);

        return true;
    }

    /**
     * Get supported cryptocurrencies
     */
    public function getSupportedCurrencies(): array
    {
        return $this->supported;
    }
}
