<?php

namespace App\Services;

use App\Models\Backup;
use Illuminate\Support\Facades\{DB, Storage};
use ZipArchive;

class BackupService
{
    /**
     * Create database backup
     */
    public function createDatabaseBackup(): Backup
    {
        $filename = 'backup_' . now()->format('Y-m-d_H-i-s') . '.sql';
        $path = storage_path('app/backups/' . $filename);

        // Ensure backup directory exists
        if (!file_exists(storage_path('app/backups'))) {
            mkdir(storage_path('app/backups'), 0755, true);
        }

        // Get database connection details
        $host = config('database.connections.mysql.host');
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');

        // Create mysqldump command
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s %s > %s',
            escapeshellarg($host),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($path)
        );

        // Execute backup
        exec($command, $output, $returnCode);

        if ($returnCode !== 0) {
            throw new \Exception('Database backup failed');
        }

        // Get file size
        $size = filesize($path);

        // Create backup record
        return Backup::create([
            'type' => 'database',
            'filename' => $filename,
            'path' => $path,
            'size' => $size,
            'status' => 'completed'
        ]);
    }

    /**
     * Create files backup
     */
    public function createFilesBackup(): Backup
    {
        $filename = 'files_backup_' . now()->format('Y-m-d_H-i-s') . '.zip';
        $path = storage_path('app/backups/' . $filename);

        // Ensure backup directory exists
        if (!file_exists(storage_path('app/backups'))) {
            mkdir(storage_path('app/backups'), 0755, true);
        }

        $zip = new ZipArchive();
        
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new \Exception('Cannot create zip file');
        }

        // Add storage files
        $this->addDirectoryToZip(storage_path('app/public'), $zip, 'storage');
        
        // Add .env file
        if (file_exists(base_path('.env'))) {
            $zip->addFile(base_path('.env'), '.env');
        }

        $zip->close();

        // Get file size
        $size = filesize($path);

        return Backup::create([
            'type' => 'files',
            'filename' => $filename,
            'path' => $path,
            'size' => $size,
            'status' => 'completed'
        ]);
    }

    /**
     * Add directory to zip recursively
     */
    private function addDirectoryToZip(string $dir, ZipArchive $zip, string $zipPath = ''): void
    {
        if (!is_dir($dir)) {
            return;
        }

        $files = scandir($dir);

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $filePath = $dir . '/' . $file;
            $relativePath = $zipPath . '/' . $file;

            if (is_dir($filePath)) {
                $this->addDirectoryToZip($filePath, $zip, $relativePath);
            } else {
                $zip->addFile($filePath, $relativePath);
            }
        }
    }

    /**
     * Restore database from backup
     */
    public function restoreDatabase(Backup $backup): bool
    {
        if ($backup->type !== 'database') {
            throw new \Exception('Not a database backup');
        }

        if (!file_exists($backup->path)) {
            throw new \Exception('Backup file not found');
        }

        $host = config('database.connections.mysql.host');
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');

        $command = sprintf(
            'mysql --host=%s --user=%s --password=%s %s < %s',
            escapeshellarg($host),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($backup->path)
        );

        exec($command, $output, $returnCode);

        return $returnCode === 0;
    }

    /**
     * Delete old backups
     */
    public function deleteOldBackups(int $daysToKeep = 30): int
    {
        $oldBackups = Backup::where('created_at', '<', now()->subDays($daysToKeep))->get();
        $deleted = 0;

        foreach ($oldBackups as $backup) {
            if (file_exists($backup->path)) {
                unlink($backup->path);
            }
            $backup->delete();
            $deleted++;
        }

        return $deleted;
    }
}
