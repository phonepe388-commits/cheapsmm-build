<?php

namespace App\Services;

use App\Models\{User, Order, ReferralEarning};
use Illuminate\Support\Facades\DB;

class ReferralService
{
    /**
     * Process referral commission for an order
     */
    public function processCommission(Order $order): ?ReferralEarning
    {
        $user = $order->user;

        // Check if user has a referrer
        if (!$user->referred_by) {
            return null;
        }

        $referrer = User::find($user->referred_by);

        if (!$referrer || $referrer->status !== 'active') {
            return null;
        }

        // Calculate commission (10% default)
        $commissionRate = 0.10;
        $commissionAmount = $order->charge * $commissionRate;

        // Create referral earning record
        $earning = ReferralEarning::create([
            'referrer_id' => $referrer->id,
            'referred_user_id' => $user->id,
            'order_id' => $order->id,
            'amount' => $commissionAmount,
            'rate' => $commissionRate,
            'status' => 'pending'
        ]);

        // Log activity
        \App\Models\ActivityLog::create([
            'user_id' => $referrer->id,
            'action' => 'referral_earning',
            'description' => "Earned " . number_format($commissionAmount, 2) . " from referral order #{$order->id}",
            'metadata' => [
                'order_id' => $order->id,
                'referred_user_id' => $user->id,
                'amount' => $commissionAmount
            ]
        ]);

        return $earning;
    }

    /**
     * Generate unique referral code
     */
    public static function generateReferralCode(): string
    {
        do {
            $code = strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
        } while (User::where('referral_code', $code)->exists());

        return $code;
    }

    /**
     * Track referral signup
     */
    public function trackSignup(User $newUser, string $referralCode): bool
    {
        $referrer = User::where('referral_code', $referralCode)
            ->where('status', 'active')
            ->first();

        if (!$referrer) {
            return false;
        }

        // Update new user's referred_by field
        $newUser->update(['referred_by' => $referrer->id]);

        // Log activity for referrer
        \App\Models\ActivityLog::create([
            'user_id' => $referrer->id,
            'action' => 'new_referral',
            'description' => "New referral signup: {$newUser->email}",
            'metadata' => [
                'referred_user_id' => $newUser->id,
                'referred_user_email' => $newUser->email
            ]
        ]);

        return true;
    }

    /**
     * Get referral statistics
     */
    public function getStats(User $user): array
    {
        return [
            'total_referrals' => $user->referrals()->count(),
            'active_referrals' => $user->referrals()->where('status', 'active')->count(),
            'total_earned' => $user->referralEarnings()->sum('amount'),
            'pending_earnings' => $user->referralEarnings()->where('status', 'pending')->sum('amount'),
            'paid_earnings' => $user->referralEarnings()->where('status', 'paid')->sum('amount'),
            'this_month_earnings' => $user->referralEarnings()
                ->whereMonth('created_at', now()->month)
                ->sum('amount'),
            'referrals_this_month' => $user->referrals()
                ->whereMonth('created_at', now()->month)
                ->count()
        ];
    }
}
