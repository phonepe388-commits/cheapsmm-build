<?php

namespace App\Services;

use App\Models\{ServiceReview, Testimonial, Leaderboard, User, Achievement, DailyReward};

class SocialFeaturesService
{
    /**
     * Submit service review
     */
    public function submitReview(User $user, int $serviceId, int $rating, ?string $comment): ServiceReview
    {
        return ServiceReview::create([
            'user_id' => $user->id,
            'service_id' => $serviceId,
            'rating' => $rating,
            'comment' => $comment,
            'status' => 'pending'
        ]);
    }

    /**
     * Get leaderboard data
     */
    public function getLeaderboard(string $type = 'monthly', int $limit = 10): array
    {
        $query = User::query();

        switch ($type) {
            case 'daily':
                $query->whereHas('orders', function($q) {
                    $q->whereDate('created_at', today());
                })->withSum(['orders' => function($q) {
                    $q->whereDate('created_at', today());
                }], 'charge');
                break;

            case 'weekly':
                $query->whereHas('orders', function($q) {
                    $q->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                })->withSum(['orders' => function($q) {
                    $q->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                }], 'charge');
                break;

            case 'monthly':
            default:
                $query->withSum('orders', 'charge');
                break;
        }

        return $query->orderByDesc('orders_sum_charge')
            ->limit($limit)
            ->get()
            ->toArray();
    }

    /**
     * Award achievement
     */
    public function awardAchievement(User $user, string $achievementType): ?Achievement
    {
        $achievements = [
            'first_order' => ['name' => 'First Order', 'description' => 'Placed your first order', 'reward' => 5],
            'big_spender' => ['name' => 'Big Spender', 'description' => 'Spent over $1000', 'reward' => 50],
            'loyal_customer' => ['name' => 'Loyal Customer', 'description' => '100+ orders', 'reward' => 100],
        ];

        if (!isset($achievements[$achievementType])) {
            return null;
        }

        $existing = Achievement::where('user_id', $user->id)
            ->where('type', $achievementType)
            ->first();

        if ($existing) {
            return null; // Already awarded
        }

        $achievement = Achievement::create([
            'user_id' => $user->id,
            'type' => $achievementType,
            'name' => $achievements[$achievementType]['name'],
            'description' => $achievements[$achievementType]['description'],
            'reward_amount' => $achievements[$achievementType]['reward']
        ]);

        // Add reward to balance
        $user->increment('balance', $achievement->reward_amount);

        return $achievement;
    }

    /**
     * Claim daily reward
     */
    public function claimDailyReward(User $user): ?DailyReward
    {
        $lastReward = DailyReward::where('user_id', $user->id)
            ->whereDate('claimed_at', today())
            ->first();

        if ($lastReward) {
            return null; // Already claimed today
        }

        $streak = $this->calculateStreak($user);
        $rewardAmount = min(1 + ($streak * 0.5), 10); // Max $10

        $reward = DailyReward::create([
            'user_id' => $user->id,
            'amount' => $rewardAmount,
            'streak_days' => $streak + 1,
            'claimed_at' => now()
        ]);

        $user->increment('balance', $rewardAmount);

        return $reward;
    }

    /**
     * Calculate login streak
     */
    private function calculateStreak(User $user): int
    {
        $lastReward = DailyReward::where('user_id', $user->id)
            ->latest('claimed_at')
            ->first();

        if (!$lastReward) {
            return 0;
        }

        if ($lastReward->claimed_at->isYesterday()) {
            return $lastReward->streak_days;
        }

        return 0; // Streak broken
    }
}
