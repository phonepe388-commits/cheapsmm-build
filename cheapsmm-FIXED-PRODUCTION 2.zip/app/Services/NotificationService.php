<?php
namespace App\Services;
use App\Models\Notification;
class NotificationService {
    public function send($user, $type, $title, $message, $data = []) {
        return Notification::create([
            'user_id' => $user->id,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'data' => $data
        ]);
    }
}
