<?php
namespace App\Services;

class ChatbotService
{
    public function getResponse($message) {
        // Predefined responses
        $responses = [
            'hello' => 'Hi! How can I help you today?',
            'price' => 'Our prices start from $0.50 per 1000. Check services page!',
            'payment' => 'We accept Stripe, PayPal, Razorpay, and bank transfer.',
            'support' => 'Please create a support ticket and we will help you soon!'
        ];
        
        $message = strtolower($message);
        foreach ($responses as $key => $response) {
            if (str_contains($message, $key)) {
                return $response;
            }
        }
        
        return 'I am sorry, I did not understand. Please contact support.';
    }
}
