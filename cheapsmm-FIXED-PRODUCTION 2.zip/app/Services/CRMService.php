<?php

namespace App\Services;

use App\Models\{User, CustomerSegment, CustomerTag, Campaign};
use Illuminate\Support\Facades\{DB, Mail};

class CRMService
{
    /**
     * Segment users based on criteria
     */
    public function segmentUsers(array $criteria): array
    {
        $query = User::query();

        // Spending level
        if (isset($criteria['spending_min'])) {
            $query->whereHas('orders', function($q) use ($criteria) {
                $q->havingRaw('SUM(charge) >= ?', [$criteria['spending_min']]);
            });
        }

        // Last order date
        if (isset($criteria['last_order_days'])) {
            $query->whereHas('orders', function($q) use ($criteria) {
                $q->where('created_at', '>=', now()->subDays($criteria['last_order_days']));
            });
        }

        // Order count
        if (isset($criteria['min_orders'])) {
            $query->has('orders', '>=', $criteria['min_orders']);
        }

        // Status
        if (isset($criteria['status'])) {
            $query->where('status', $criteria['status']);
        }

        // Balance
        if (isset($criteria['balance_min'])) {
            $query->where('balance', '>=', $criteria['balance_min']);
        }

        return $query->get()->toArray();
    }

    /**
     * Create customer segment
     */
    public function createSegment(string $name, array $criteria): CustomerSegment
    {
        return CustomerSegment::create([
            'name' => $name,
            'criteria' => $criteria,
            'user_count' => count($this->segmentUsers($criteria))
        ]);
    }

    /**
     * Tag users
     */
    public function tagUser(User $user, string $tagName): void
    {
        $tag = CustomerTag::firstOrCreate(['name' => $tagName]);
        
        if (!$user->tags()->where('customer_tag_id', $tag->id)->exists()) {
            $user->tags()->attach($tag->id);
        }
    }

    /**
     * Send campaign to segment
     */
    public function sendCampaign(Campaign $campaign, CustomerSegment $segment): int
    {
        $users = $this->segmentUsers($segment->criteria);
        $sent = 0;

        foreach ($users as $userData) {
            $user = User::find($userData['id']);
            
            try {
                Mail::raw($campaign->message, function($message) use ($user, $campaign) {
                    $message->to($user->email)
                           ->subject($campaign->subject);
                });

                $campaign->increment('sent_count');
                $sent++;
            } catch (\Exception $e) {
                \Log::error("Campaign send failed for user {$user->id}: " . $e->getMessage());
            }
        }

        return $sent;
    }

    /**
     * Get customer lifetime value
     */
    public function getCustomerLifetimeValue(User $user): float
    {
        return $user->orders()->sum('charge');
    }

    /**
     * Get customer insights
     */
    public function getCustomerInsights(User $user): array
    {
        return [
            'lifetime_value' => $this->getCustomerLifetimeValue($user),
            'total_orders' => $user->orders()->count(),
            'average_order_value' => $user->orders()->avg('charge'),
            'last_order_date' => $user->orders()->latest()->first()?->created_at,
            'days_since_last_order' => $user->orders()->latest()->first()?->created_at?->diffInDays(now()),
            'favorite_service' => $user->orders()
                ->select('service_id', DB::raw('COUNT(*) as count'))
                ->groupBy('service_id')
                ->orderByDesc('count')
                ->first()?->service_id,
            'total_spent' => $user->payments()->where('status', 'completed')->sum('amount'),
            'current_balance' => $user->balance,
            'tags' => $user->tags->pluck('name')->toArray()
        ];
    }
}
