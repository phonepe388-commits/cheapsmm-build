<?php

namespace App\Services;

use App\Models\{Order, User, Payment, Service};

class AdvancedExportService
{
    /**
     * Export with filters
     */
    public function export(string $type, array $filters, string $format = 'csv'): string
    {
        switch ($type) {
            case 'orders':
                $data = $this->exportOrders($filters);
                break;
            case 'users':
                $data = $this->exportUsers($filters);
                break;
            case 'payments':
                $data = $this->exportPayments($filters);
                break;
            default:
                throw new \Exception('Invalid export type');
        }

        return $this->generateFile($data, $format);
    }

    /**
     * Export orders with filters
     */
    private function exportOrders(array $filters): array
    {
        $query = Order::with(['user', 'service']);

        if (isset($filters['date_from'])) {
            $query->where('created_at', '>=', $filters['date_from']);
        }

        if (isset($filters['date_to'])) {
            $query->where('created_at', '<=', $filters['date_to']);
        }

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (isset($filters['service_id'])) {
            $query->where('service_id', $filters['service_id']);
        }

        return $query->get()->map(function($order) {
            return [
                'ID' => $order->id,
                'User' => $order->user->name,
                'Service' => $order->service->name,
                'Link' => $order->link,
                'Quantity' => $order->quantity,
                'Charge' => $order->charge,
                'Status' => $order->status,
                'Created' => $order->created_at->format('Y-m-d H:i:s')
            ];
        })->toArray();
    }

    /**
     * Export users with filters
     */
    private function exportUsers(array $filters): array
    {
        $query = User::withCount('orders')->withSum('orders', 'charge');

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (isset($filters['min_orders'])) {
            $query->has('orders', '>=', $filters['min_orders']);
        }

        return $query->get()->map(function($user) {
            return [
                'ID' => $user->id,
                'Name' => $user->name,
                'Email' => $user->email,
                'Balance' => $user->balance,
                'Total Orders' => $user->orders_count,
                'Total Spent' => $user->orders_sum_charge,
                'Status' => $user->status,
                'Registered' => $user->created_at->format('Y-m-d')
            ];
        })->toArray();
    }

    /**
     * Export payments with filters
     */
    private function exportPayments(array $filters): array
    {
        $query = Payment::with('user');

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (isset($filters['date_from'])) {
            $query->where('created_at', '>=', $filters['date_from']);
        }

        return $query->get()->map(function($payment) {
            return [
                'ID' => $payment->id,
                'User' => $payment->user->name,
                'Amount' => $payment->amount,
                'Method' => $payment->paymentMethod->name ?? 'N/A',
                'Status' => $payment->status,
                'Transaction ID' => $payment->transaction_id,
                'Date' => $payment->created_at->format('Y-m-d H:i:s')
            ];
        })->toArray();
    }

    /**
     * Generate export file
     */
    private function generateFile(array $data, string $format): string
    {
        $filename = 'export_' . time() . '.' . $format;
        $path = storage_path('app/exports/' . $filename);

        // Ensure directory exists
        if (!file_exists(storage_path('app/exports'))) {
            mkdir(storage_path('app/exports'), 0755, true);
        }

        if ($format === 'csv') {
            $fp = fopen($path, 'w');
            
            // Headers
            if (!empty($data)) {
                fputcsv($fp, array_keys($data[0]));
            }

            // Data
            foreach ($data as $row) {
                fputcsv($fp, $row);
            }

            fclose($fp);
        }

        return $path;
    }
}
