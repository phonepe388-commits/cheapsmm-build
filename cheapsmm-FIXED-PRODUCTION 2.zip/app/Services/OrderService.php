<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Service;
use App\Models\User;
use App\Exceptions\InsufficientBalanceException;
use App\Exceptions\ServiceNotAvailableException;
use Illuminate\Support\Facades\DB;

class OrderService
{
    /**
     * Create a new order
     * 
     * @param User $user
     * @param array $data
     * @return Order
     */
    public function createOrder(User $user, array $data)
    {
        // Validate service availability
        $service = Service::findOrFail($data['service_id']);
        
        if (!$service->isAvailable()) {
            throw new ServiceNotAvailableException('Service is not available');
        }

        // Calculate charge
        $charge = $service->getPriceForUser($user, $data['quantity']);

        // Check user balance
        if (!$user->hasSufficientBalance($charge)) {
            throw new InsufficientBalanceException('Insufficient balance');
        }

        // Create order in transaction
        return DB::transaction(function () use ($user, $service, $data, $charge) {
            // Deduct balance
            $user->deductBalance($charge, "Order #TBD for {$service->name}", 'order');

            // Create order
            $order = Order::create([
                'user_id' => $user->id,
                'service_id' => $service->id,
                'api_provider_id' => $service->api_provider_id,
                'type' => $data['type'] ?? 'single',
                'link' => $data['link'],
                'quantity' => $data['quantity'],
                'charge' => $charge,
                'currency' => $user->currency->code,
                'status' => 'pending',
                'is_dripfeed' => $data['is_dripfeed'] ?? false,
                'dripfeed_runs' => $data['dripfeed_runs'] ?? null,
                'dripfeed_interval' => $data['dripfeed_interval'] ?? null,
                'is_subscription' => $data['is_subscription'] ?? false,
                'subscription_username' => $data['subscription_username'] ?? null,
                'subscription_posts' => $data['subscription_posts'] ?? null,
                'subscription_delay' => $data['subscription_delay'] ?? null,
                'subscription_min' => $data['subscription_min'] ?? null,
                'subscription_max' => $data['subscription_max'] ?? null,
                'custom_comments' => $data['custom_comments'] ?? null,
            ]);

            // Update transaction description with order ID
            $user->transactions()->latest()->first()->update([
                'description' => "Order #{$order->id} for {$service->name}",
                'reference_id' => $order->id,
            ]);

            // Log order creation
            $order->history()->create([
                'status' => 'pending',
                'quantity' => $order->quantity,
                'remains' => $order->quantity,
                'note' => 'Order created',
            ]);

            // Submit to API provider (queue this)
            dispatch(new \App\Jobs\ProcessOrder($order));

            // Process referral commission if applicable
            $this->processReferralCommission($order);

            return $order;
        });
    }

    /**
     * Process referral commission after order creation
     */
    protected function processReferralCommission(Order $order)
    {
        $referralService = app(\App\Services\ReferralService::class);
        $referralService->processCommission($order);
    }

    /**
     * Create mass order
     */
    public function createMassOrder(User $user, array $data)
    {
        $orders = [];
        $totalCharge = 0;

        // Parse links (CSV or newline separated)
        $links = $this->parseLinks($data['links']);

        $service = Service::findOrFail($data['service_id']);

        // Calculate total charge
        foreach ($links as $link) {
            $totalCharge += $service->getPriceForUser($user, $data['quantity']);
        }

        // Check balance
        if (!$user->hasSufficientBalance($totalCharge)) {
            throw new InsufficientBalanceException('Insufficient balance');
        }

        // Create orders
        return DB::transaction(function () use ($user, $service, $links, $data, $totalCharge) {
            $orders = [];

            foreach ($links as $link) {
                $orderData = array_merge($data, [
                    'type' => 'mass',
                    'link' => $link,
                ]);

                $orders[] = $this->createOrder($user, $orderData);
            }

            return $orders;
        });
    }

    /**
     * Process order - submit to API provider
     */
    public function processOrder(Order $order)
    {
        $apiProvider = $order->apiProvider;

        if (!$apiProvider || !$apiProvider->isActive()) {
            $order->updateStatus('cancelled', 'API provider not available');
            $order->user->addBalance($order->charge, "Refund for order #{$order->id}");
            return false;
        }

        try {
            // Submit to API
            $response = $this->submitToAPI($order);

            if ($response['success']) {
                $order->api_order_id = $response['order_id'];
                $order->status = 'processing';
                $order->api_response = $response;
                $order->save();

                $order->history()->create([
                    'status' => 'processing',
                    'quantity' => $order->quantity,
                    'remains' => $order->quantity,
                    'note' => 'Order submitted to API provider',
                ]);

                return true;
            } else {
                throw new \Exception($response['error'] ?? 'API submission failed');
            }
        } catch (\Exception $e) {
            // Refund and cancel order
            $order->updateStatus('cancelled', $e->getMessage());
            $order->user->addBalance(
                $order->charge,
                "Refund for failed order #{$order->id}",
                'refund',
                $order->id
            );

            return false;
        }
    }

    /**
     * Check order status from API
     */
    public function checkOrderStatus(Order $order)
    {
        if (!$order->api_order_id) {
            return false;
        }

        $apiProvider = $order->apiProvider;

        try {
            $response = $this->checkAPIStatus($order);

            if ($response['success']) {
                $apiStatus = $response['status'];
                
                // Map API status to our status
                $newStatus = $this->mapAPIStatus($apiStatus);

                if ($order->status !== $newStatus) {
                    $order->updateStatus($newStatus);
                }

                // Update progress
                if (isset($response['start_count']) && isset($response['remains'])) {
                    $order->updateProgress($response['start_count'], $response['remains']);
                }

                return true;
            }
        } catch (\Exception $e) {
            \Log::error('Error checking order status: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Cancel order
     */
    public function cancelOrder(Order $order)
    {
        if (!$order->is_cancellable) {
            throw new \Exception('Order cannot be cancelled');
        }

        return DB::transaction(function () use ($order) {
            // Try to cancel on API if already submitted
            if ($order->api_order_id) {
                try {
                    $this->cancelOnAPI($order);
                } catch (\Exception $e) {
                    // Log but continue with local cancellation
                    \Log::warning('Could not cancel order on API: ' . $e->getMessage());
                }
            }

            $order->cancel('Cancelled by user');

            return $order;
        });
    }

    /**
     * Request refill
     */
    public function requestRefill(Order $order)
    {
        return $order->requestRefill();
    }

    /**
     * Process dripfeed run
     */
    public function processDripfeedRun(Order $order)
    {
        if (!$order->is_dripfeed) {
            return false;
        }

        // Create a new order for this run
        $runQuantity = $order->quantity / $order->dripfeed_runs;

        $runOrder = $this->createOrder($order->user, [
            'service_id' => $order->service_id,
            'link' => $order->link,
            'quantity' => $runQuantity,
            'type' => 'single',
        ]);

        $order->processDripfeedRun();

        return $runOrder;
    }

    // ========================================================================
    // PRIVATE HELPER METHODS
    // ========================================================================

    /**
     * Submit order to API provider
     */
    private function submitToAPI(Order $order)
    {
        // This will be implemented with actual API provider logic
        // For now, return mock response
        return [
            'success' => true,
            'order_id' => 'API_' . time(),
        ];
    }

    /**
     * Check status from API provider
     */
    private function checkAPIStatus(Order $order)
    {
        // This will be implemented with actual API provider logic
        return [
            'success' => true,
            'status' => 'completed',
            'start_count' => 1000,
            'remains' => 0,
        ];
    }

    /**
     * Cancel order on API provider
     */
    private function cancelOnAPI(Order $order)
    {
        // Implementation depends on API provider
        return true;
    }

    /**
     * Map API status to internal status
     */
    private function mapAPIStatus($apiStatus)
    {
        $statusMap = [
            'Pending' => 'pending',
            'Processing' => 'processing',
            'In progress' => 'in_progress',
            'Completed' => 'completed',
            'Partial' => 'partial',
            'Canceled' => 'cancelled',
            'Refunded' => 'refunded',
        ];

        return $statusMap[$apiStatus] ?? 'pending';
    }

    /**
     * Parse links from CSV or newline separated text
     */
    private function parseLinks($linksText)
    {
        // Split by newlines or commas
        $links = preg_split('/[\r\n,]+/', $linksText);
        
        // Clean and filter
        $links = array_map('trim', $links);
        $links = array_filter($links);
        
        return array_values($links);
    }
}

    /**
     * Process referral commission after order creation
     */
    protected function processReferralCommission(Order $order)
    {
        $referralService = app(\App\Services\ReferralService::class);
        $referralService->processCommission($order);
    }
}
