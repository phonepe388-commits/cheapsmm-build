<?php

namespace App\Services;

use App\Models\{Payment, User};
use PDF; // Assuming DOMPDF or similar

class InvoiceService
{
    /**
     * Generate invoice PDF
     */
    public function generateInvoice(Payment $payment): string
    {
        $data = [
            'payment' => $payment,
            'user' => $payment->user,
            'invoice_number' => 'INV-' . str_pad($payment->id, 6, '0', STR_PAD_LEFT),
            'date' => $payment->created_at->format('M d, Y'),
            'company' => [
                'name' => config('app.name'),
                'address' => config('app.company_address', '123 Business St'),
                'email' => config('app.company_email', 'billing@company.com'),
                'phone' => config('app.company_phone', '+1234567890')
            ]
        ];

        $html = view('invoices.payment', $data)->render();

        // Generate PDF filename
        $filename = 'invoice_' . $data['invoice_number'] . '.pdf';
        $path = storage_path('app/invoices/' . $filename);

        // Ensure directory exists
        if (!file_exists(storage_path('app/invoices'))) {
            mkdir(storage_path('app/invoices'), 0755, true);
        }

        // Save HTML as PDF (simplified - use actual PDF library in production)
        file_put_contents($path, $html);

        return $path;
    }

    /**
     * Generate monthly statement
     */
    public function generateMonthlyStatement(User $user, int $year, int $month): array
    {
        $startDate = \Carbon\Carbon::create($year, $month, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();

        $orders = $user->orders()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->with('service')
            ->get();

        $payments = $user->payments()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'completed')
            ->get();

        return [
            'user' => $user,
            'period' => $startDate->format('F Y'),
            'orders' => $orders,
            'payments' => $payments,
            'total_spent' => $orders->sum('charge'),
            'total_deposited' => $payments->sum('amount'),
            'opening_balance' => $this->getBalanceAt($user, $startDate),
            'closing_balance' => $user->balance
        ];
    }

    /**
     * Get user balance at specific date
     */
    private function getBalanceAt(User $user, $date): float
    {
        $totalDeposited = $user->payments()
            ->where('status', 'completed')
            ->where('created_at', '<', $date)
            ->sum('amount');

        $totalSpent = $user->orders()
            ->where('created_at', '<', $date)
            ->sum('charge');

        return $totalDeposited - $totalSpent;
    }
}
