<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoyaltyPoint extends Model {
    protected $fillable = ['user_id', 'points', 'lifetime_points', 'tier_level'];
    public function user() { return $this->belongsTo(User::class); }
}
