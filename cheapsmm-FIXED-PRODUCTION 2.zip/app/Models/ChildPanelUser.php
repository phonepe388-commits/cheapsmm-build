<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChildPanelUser extends Model
{
    protected $fillable = [
        'child_panel_id',
        'email',
        'name',
        'password',
        'balance',
        'status',
        'api_key',
        'last_login_at'
    ];

    protected $casts = [
        'balance' => 'decimal:2',
        'last_login_at' => 'datetime'
    ];

    protected $hidden = ['password'];

    public function childPanel()
    {
        return $this->belongsTo(ChildPanel::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'child_panel_user_id');
    }
}
