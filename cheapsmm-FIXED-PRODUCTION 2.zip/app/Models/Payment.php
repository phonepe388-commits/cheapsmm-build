<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'payment_method_id',
        'transaction_id',
        'amount',
        'currency',
        'bonus_amount',
        'total_amount',
        'status',
        'payment_details',
        'gateway_response',
        'notes',
        'processed_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'bonus_amount' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'payment_details' => 'array',
        'gateway_response' => 'array',
        'processed_at' => 'datetime',
    ];

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class);
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    public function scopeFailed($query)
    {
        return $query->where('status', 'failed');
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Mark payment as completed
     */
    public function markAsCompleted()
    {
        $this->status = 'completed';
        $this->processed_at = now();
        $this->save();

        // Add balance to user
        $this->user->addBalance(
            $this->total_amount,
            "Payment received via {$this->paymentMethod->name}",
            'payment',
            $this->id
        );

        // Send notification
        $this->user->notifications()->create([
            'type' => 'payment_received',
            'title' => 'Payment Received',
            'message' => "Your payment of {$this->total_amount} has been received.",
            'data' => ['payment_id' => $this->id],
        ]);

        return $this;
    }

    /**
     * Calculate bonus amount
     */
    public function calculateBonus()
    {
        $bonusPercentage = setting('payment_bonus_percentage', 0);
        return round(($this->amount * $bonusPercentage) / 100, 2);
    }
}
