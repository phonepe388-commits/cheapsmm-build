<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChildPanelServicePricing extends Model
{
    protected $fillable = [
        'child_panel_id',
        'service_id',
        'price_per_1000',
        'min_quantity',
        'max_quantity',
        'status'
    ];

    protected $casts = [
        'price_per_1000' => 'decimal:2'
    ];

    public function childPanel()
    {
        return $this->belongsTo(ChildPanel::class);
    }

    public function service()
    {
        return $this->belongsTo(Service::class);
    }
}
