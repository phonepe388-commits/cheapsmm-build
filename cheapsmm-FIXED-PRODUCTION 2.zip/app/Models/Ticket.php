<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'subject',
        'priority',
        'status',
        'assigned_to',
        'closed_at',
    ];

    protected $casts = [
        'closed_at' => 'datetime',
    ];

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function messages()
    {
        return $this->hasMany(TicketMessage::class)->orderBy('created_at');
    }

    public function assignedAdmin()
    {
        return $this->belongsTo(Admin::class, 'assigned_to');
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    public function scopeOpen($query)
    {
        return $query->where('status', 'open');
    }

    public function scopeClosed($query)
    {
        return $query->where('status', 'closed');
    }

    public function scopePriority($query, $priority)
    {
        return $query->where('priority', $priority);
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Reply to ticket
     */
    public function reply($message, $isAdmin = false, $attachments = null)
    {
        $reply = $this->messages()->create([
            'user_id' => $isAdmin ? null : auth()->id(),
            'admin_id' => $isAdmin ? auth()->id() : null,
            'message' => $message,
            'attachments' => $attachments,
        ]);

        // Update ticket status
        if ($this->status === 'closed') {
            $this->status = 'open';
            $this->save();
        }

        return $reply;
    }

    /**
     * Close ticket
     */
    public function close()
    {
        $this->status = 'closed';
        $this->closed_at = now();
        $this->save();

        return $this;
    }
}
