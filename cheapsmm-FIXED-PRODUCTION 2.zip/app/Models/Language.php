<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $fillable = ['code', 'name', 'flag', 'is_default', 'is_rtl'];
    protected $casts = ['is_default' => 'boolean', 'is_rtl' => 'boolean'];
}
