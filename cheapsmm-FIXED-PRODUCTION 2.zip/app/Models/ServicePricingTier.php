<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ServicePricingTier extends Model {
    protected $fillable = ['service_id', 'user_tier_id', 'price'];
    protected $casts = ['price' => 'decimal:4'];
    public function service() { return $this->belongsTo(Service::class); }
    public function userTier() { return $this->belongsTo(UserTier::class); }
}
