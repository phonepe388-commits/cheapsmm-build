<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ApiProvider extends Model
{
    protected $fillable = ['name', 'api_url', 'api_key', 'type', 'balance', 'status'];
    protected $casts = ['balance' => 'decimal:2'];

    public function services() {
        return $this->hasMany(Service::class);
    }
    
    public function apiLogs() {
        return $this->hasMany(ApiLog::class);
    }

    public function isActive() {
        return $this->status === 'active';
    }
}
