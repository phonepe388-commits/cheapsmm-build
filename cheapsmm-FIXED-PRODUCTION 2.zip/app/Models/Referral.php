<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Referral extends Model
{
    protected $fillable = ['referrer_id', 'referred_id', 'commission_percentage', 'total_earned'];
    protected $casts = ['commission_percentage' => 'decimal:2', 'total_earned' => 'decimal:2'];

    public function referrer() {
        return $this->belongsTo(User::class, 'referrer_id');
    }

    public function referred() {
        return $this->belongsTo(User::class, 'referred_id');
    }
}
