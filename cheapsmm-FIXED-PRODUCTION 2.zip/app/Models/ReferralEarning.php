<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ReferralEarning extends Model {
    protected $guarded = [];
}
