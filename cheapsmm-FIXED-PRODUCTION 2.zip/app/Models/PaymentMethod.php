<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PaymentMethod extends Model
{
    protected $fillable = ['name', 'type', 'credentials', 'min_amount', 'max_amount', 'fee_type', 'fee_value', 'bonus_percentage', 'status'];
    protected $casts = ['credentials' => 'encrypted:array', 'min_amount' => 'decimal:2', 'max_amount' => 'decimal:2'];
}
