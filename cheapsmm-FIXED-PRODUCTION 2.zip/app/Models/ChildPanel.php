<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChildPanel extends Model
{
    protected $fillable = [
        'user_id',
        'name',
        'domain',
        'subdomain',
        'logo',
        'favicon',
        'primary_color',
        'secondary_color',
        'balance',
        'credit_limit',
        'markup_percentage',
        'status',
        'settings',
        'custom_css',
        'custom_footer',
        'support_email',
        'support_phone',
        'currency',
        'language',
        'timezone',
        'ssl_enabled',
        'api_enabled'
    ];

    protected $casts = [
        'balance' => 'decimal:2',
        'credit_limit' => 'decimal:2',
        'markup_percentage' => 'decimal:2',
        'settings' => 'array',
        'ssl_enabled' => 'boolean',
        'api_enabled' => 'boolean'
    ];

    /**
     * Owner of the child panel
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Child panel users
     */
    public function childUsers()
    {
        return $this->hasMany(ChildPanelUser::class);
    }

    /**
     * Orders placed through this child panel
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Service pricing for this child panel
     */
    public function servicePricing()
    {
        return $this->hasMany(ChildPanelServicePricing::class);
    }

    /**
     * Calculate service price with markup
     */
    public function getServicePrice($basePrice)
    {
        return $basePrice * (1 + ($this->markup_percentage / 100));
    }

    /**
     * Check if panel is active
     */
    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    /**
     * Get panel URL
     */
    public function getUrl(): string
    {
        if ($this->domain) {
            return ($this->ssl_enabled ? 'https://' : 'http://') . $this->domain;
        }
        
        if ($this->subdomain) {
            return ($this->ssl_enabled ? 'https://' : 'http://') . $this->subdomain . '.cheapsmm.fun';
        }

        return '#';
    }

    /**
     * Deduct balance from child panel
     */
    public function deductBalance($amount): bool
    {
        if ($this->balance + $this->credit_limit >= $amount) {
            $this->decrement('balance', $amount);
            return true;
        }
        return false;
    }

    /**
     * Add balance to child panel
     */
    public function addBalance($amount): void
    {
        $this->increment('balance', $amount);
    }
}
