<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
        'avatar',
        'balance',
        'currency_id',
        'language_id',
        'timezone',
        'user_tier_id',
        'kyc_status',
        'kyc_documents',
        'referral_code',
        'referred_by',
        'two_factor_enabled',
        'status',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'phone_verified_at' => 'datetime',
        'password' => 'hashed',
        'kyc_documents' => 'array',
        'two_factor_enabled' => 'boolean',
        'balance' => 'decimal:2',
        'last_login_at' => 'datetime',
    ];

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            // Generate unique referral code
            if (empty($user->referral_code)) {
                $user->referral_code = strtoupper(substr(md5(uniqid()), 0, 10));
            }
        });
    }

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    /**
     * User belongs to a tier
     */
    public function tier()
    {
        return $this->belongsTo(UserTier::class, 'user_tier_id');
    }

    /**
     * User belongs to a currency
     */
    public function currency()
    {
        return $this->belongsTo(Currency::class);
    }

    /**
     * User belongs to a language
     */
    public function language()
    {
        return $this->belongsTo(Language::class);
    }

    /**
     * User has many orders
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    /**
     * User has many payments
     */
    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * User has many tickets
     */
    public function tickets()
    {
        return $this->hasMany(Ticket::class);
    }

    /**
     * User has many transactions
     */
    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    /**
     * User has many notifications
     */
    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    /**
     * User has many sessions
     */
    public function sessions()
    {
        return $this->hasMany(UserSession::class);
    }

    /**
     * User has many login history records
     */
    public function loginHistory()
    {
        return $this->hasMany(UserLoginHistory::class);
    }

    /**
     * User has one child panel
     */
    public function childPanel()
    {
        return $this->hasOne(ChildPanel::class);
    }

    /**
     * User has many API clients
     */
    public function apiClients()
    {
        return $this->hasMany(ApiClient::class);
    }

    /**
     * User has many webhooks
     */
    public function webhooks()
    {
        return $this->hasMany(Webhook::class);
    }

    /**
     * User has one loyalty points account
     */
    public function loyaltyPoints()
    {
        return $this->hasOne(LoyaltyPoint::class);
    }

    /**
     * User has many loyalty transactions
     */
    public function loyaltyTransactions()
    {
        return $this->hasMany(LoyaltyTransaction::class);
    }

    /**
     * User has one level (gamification)
     */
    public function level()
    {
        return $this->hasOne(UserLevel::class);
    }

    /**
     * User has many achievements
     */
    public function achievements()
    {
        return $this->belongsToMany(Achievement::class, 'user_achievements')
                    ->withPivot('progress', 'completed_at')
                    ->withTimestamps();
    }

    /**
     * User has many daily rewards
     */
    public function dailyRewards()
    {
        return $this->hasMany(DailyReward::class);
    }

    /**
     * User has many service reviews
     */
    public function reviews()
    {
        return $this->hasMany(ServiceReview::class);
    }

    /**
     * User who referred this user
     */
    public function referrer()
    {
        return $this->belongsTo(User::class, 'referred_by');
    }

    /**
     * Users referred by this user
     */
    public function referrals()
    {
        return $this->hasMany(Referral::class, 'referrer_id');
    }

    /**
     * Users this user has referred
     */
    public function referredUsers()
    {
        return $this->hasMany(User::class, 'referred_by');
    }

    /**
     * User has many tags
     */
    public function tags()
    {
        return $this->belongsToMany(CustomerTag::class, 'customer_tag_assignments');
    }

    /**
     * User has many notes (from admin)
     */
    public function notes()
    {
        return $this->hasMany(CustomerNote::class);
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    /**
     * Scope for active users only
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    /**
     * Scope for suspended users
     */
    public function scopeSuspended($query)
    {
        return $query->where('status', 'suspended');
    }

    /**
     * Scope for banned users
     */
    public function scopeBanned($query)
    {
        return $query->where('status', 'banned');
    }

    /**
     * Scope for verified users
     */
    public function scopeVerified($query)
    {
        return $query->whereNotNull('email_verified_at');
    }

    /**
     * Scope for users with 2FA enabled
     */
    public function scopeWithTwoFactor($query)
    {
        return $query->where('two_factor_enabled', true);
    }

    /**
     * Scope for KYC verified users
     */
    public function scopeKycVerified($query)
    {
        return $query->where('kyc_status', 'verified');
    }

    // ========================================================================
    // ACCESSORS & MUTATORS
    // ========================================================================

    /**
     * Get formatted balance
     */
    public function getFormattedBalanceAttribute()
    {
        return $this->currency->symbol . number_format($this->balance, 2);
    }

    /**
     * Check if user is active
     */
    public function getIsActiveAttribute()
    {
        return $this->status === 'active';
    }

    /**
     * Check if user is suspended
     */
    public function getIsSuspendedAttribute()
    {
        return $this->status === 'suspended';
    }

    /**
     * Check if user is banned
     */
    public function getIsBannedAttribute()
    {
        return $this->status === 'banned';
    }

    /**
     * Check if email is verified
     */
    public function getIsEmailVerifiedAttribute()
    {
        return !is_null($this->email_verified_at);
    }

    /**
     * Check if KYC is verified
     */
    public function getIsKycVerifiedAttribute()
    {
        return $this->kyc_status === 'verified';
    }

    /**
     * Get initials
     */
    public function getInitialsAttribute()
    {
        $names = explode(' ', $this->name);
        $initials = '';
        foreach ($names as $name) {
            $initials .= strtoupper(substr($name, 0, 1));
        }
        return $initials;
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Add balance to user account
     */
    public function addBalance($amount, $description = null, $referenceType = null, $referenceId = null)
    {
        $balanceBefore = $this->balance;
        $this->balance += $amount;
        $this->save();

        // Log transaction
        $this->transactions()->create([
            'type' => 'credit',
            'amount' => $amount,
            'currency' => $this->currency->code,
            'balance_before' => $balanceBefore,
            'balance_after' => $this->balance,
            'description' => $description,
            'reference_type' => $referenceType,
            'reference_id' => $referenceId,
        ]);

        return $this;
    }

    /**
     * Deduct balance from user account
     */
    public function deductBalance($amount, $description = null, $referenceType = null, $referenceId = null)
    {
        if ($this->balance < $amount) {
            throw new \Exception('Insufficient balance');
        }

        $balanceBefore = $this->balance;
        $this->balance -= $amount;
        $this->save();

        // Log transaction
        $this->transactions()->create([
            'type' => 'debit',
            'amount' => $amount,
            'currency' => $this->currency->code,
            'balance_before' => $balanceBefore,
            'balance_after' => $this->balance,
            'description' => $description,
            'reference_type' => $referenceType,
            'reference_id' => $referenceId,
        ]);

        return $this;
    }

    /**
     * Check if user has sufficient balance
     */
    public function hasSufficientBalance($amount)
    {
        return $this->balance >= $amount;
    }

    /**
     * Get total spent amount
     */
    public function getTotalSpent()
    {
        return $this->orders()->where('status', 'completed')->sum('charge');
    }

    /**
     * Get total orders count
     */
    public function getTotalOrders()
    {
        return $this->orders()->count();
    }

    /**
     * Get pending orders count
     */
    public function getPendingOrders()
    {
        return $this->orders()->whereIn('status', ['pending', 'processing', 'in_progress'])->count();
    }

    /**
     * Update tier based on spending
     */
    public function updateTier()
    {
        $totalSpent = $this->getTotalSpent();
        
        $tier = UserTier::where('min_spend', '<=', $totalSpent)
                        ->where(function($query) use ($totalSpent) {
                            $query->where('max_spend', '>=', $totalSpent)
                                  ->orWhereNull('max_spend');
                        })
                        ->orderBy('min_spend', 'desc')
                        ->first();

        if ($tier && $tier->id !== $this->user_tier_id) {
            $this->user_tier_id = $tier->id;
            $this->save();
        }

        return $this;
    }

    /**
     * Enable two-factor authentication
     */
    public function enableTwoFactor($secret)
    {
        $this->two_factor_secret = encrypt($secret);
        $this->two_factor_enabled = true;
        $this->save();

        return $this;
    }

    /**
     * Disable two-factor authentication
     */
    public function disableTwoFactor()
    {
        $this->two_factor_secret = null;
        $this->two_factor_enabled = false;
        $this->save();

        return $this;
    }

    /**
     * Log user login
     */
    public function logLogin($ipAddress, $userAgent, $location = null, $status = 'success')
    {
        $this->loginHistory()->create([
            'ip_address' => $ipAddress,
            'user_agent' => $userAgent,
            'location' => $location,
            'status' => $status,
        ]);

        if ($status === 'success') {
            $this->last_login_at = now();
            $this->last_login_ip = $ipAddress;
            $this->save();
        }

        return $this;
    }
}

    /**
     * Relationship: User has many referral earnings
     */
    public function referralEarnings()
    {
        return $this->hasMany(ReferralEarning::class, 'referrer_id');
    }

    /**
     * Boot method to auto-generate referral code
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            if (!$user->referral_code) {
                $user->referral_code = \App\Services\ReferralService::generateReferralCode();
            }
        });
    }
}

    // Note: Add 'language' to the $fillable array in User model:
    // protected $fillable = [..., 'language'];
}

    // Add to User model:
    public function tags()
    {
        return $this->belongsToMany(CustomerTag::class, 'user_tags');
    }
}

    /**
     * Child panels owned by this user
     */
    public function childPanels()
    {
        return $this->hasMany(ChildPanel::class);
    }
}
