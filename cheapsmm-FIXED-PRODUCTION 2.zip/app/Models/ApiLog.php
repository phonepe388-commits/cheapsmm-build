<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ApiLog extends Model {
    protected $fillable = ['api_provider_id', 'endpoint', 'method', 'request_data', 'response_data', 'status_code', 'execution_time'];
    protected $casts = ['request_data' => 'array', 'response_data' => 'array'];
}
