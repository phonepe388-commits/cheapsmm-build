<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Refill extends Model {
    protected $fillable = ['original_order_id', 'refill_order_id', 'user_id', 'service_id', 'link', 'quantity', 'status', 'reason'];
    public function originalOrder() { return $this->belongsTo(Order::class, 'original_order_id'); }
    public function user() { return $this->belongsTo(User::class); }
}
