<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $fillable = [
        'code',
        'description',
        'type',
        'value',
        'min_amount',
        'max_discount',
        'max_uses',
        'max_uses_per_user',
        'uses',
        'expires_at',
        'status'
    ];

    protected $casts = [
        'value' => 'decimal:2',
        'min_amount' => 'decimal:2',
        'max_discount' => 'decimal:2',
        'expires_at' => 'datetime'
    ];

    /**
     * Relationship: Coupon has many usage logs
     */
    public function usageLogs()
    {
        return $this->hasMany(CouponUsageLog::class);
    }

    /**
     * Check if coupon is valid
     */
    public function isValid($amount = 0): bool
    {
        if ($this->status !== 'active') return false;
        if ($this->expires_at && $this->expires_at->isPast()) return false;
        if ($this->max_uses && $this->uses >= $this->max_uses) return false;
        if ($this->min_amount && $amount < $this->min_amount) return false;
        return true;
    }

    /**
     * Calculate discount
     */
    public function calculateDiscount($amount): float
    {
        if ($this->type === 'percentage') {
            $discount = ($amount * $this->value) / 100;
            if ($this->max_discount && $discount > $this->max_discount) {
                return $this->max_discount;
            }
            return $discount;
        }
        return min($this->value, $amount);
    }
}
