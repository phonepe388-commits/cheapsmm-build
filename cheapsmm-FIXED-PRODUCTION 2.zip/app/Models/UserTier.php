<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class UserTier extends Model
{
    protected $fillable = ['name', 'min_spend', 'max_spend', 'discount_percentage'];
    protected $casts = ['min_spend' => 'decimal:2', 'max_spend' => 'decimal:2', 'discount_percentage' => 'decimal:2'];

    public function users() {
        return $this->hasMany(User::class);
    }
}
