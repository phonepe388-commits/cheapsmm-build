<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class OrderHistory extends Model {
    protected $fillable = ['order_id', 'status', 'quantity', 'remains', 'note'];
    public function order() { return $this->belongsTo(Order::class); }
}
