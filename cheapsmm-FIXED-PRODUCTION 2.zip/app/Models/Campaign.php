<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    protected $fillable = ['name', 'subject', 'message', 'segment_id', 'sent_count', 'status'];

    public function segment()
    {
        return $this->belongsTo(CustomerSegment::class, 'segment_id');
    }
}
