<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class TicketMessage extends Model {
    protected $fillable = ['ticket_id', 'user_id', 'admin_id', 'message', 'attachments'];
    protected $casts = ['attachments' => 'array'];
    public function ticket() { return $this->belongsTo(Ticket::class); }
}
