<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'parent_id',
        'name',
        'slug',
        'description',
        'icon',
        'display_order',
        'status',
    ];

    protected $casts = [
        'status' => 'string',
    ];

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    public function parent()
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Category::class, 'parent_id')->orderBy('display_order');
    }

    public function services()
    {
        return $this->hasMany(Service::class);
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeParents($query)
    {
        return $query->whereNull('parent_id');
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Get all services including from subcategories
     */
    public function getAllServices()
    {
        $services = $this->services;
        
        foreach ($this->children as $child) {
            $services = $services->merge($child->getAllServices());
        }
        
        return $services;
    }

    /**
     * Get breadcrumb path
     */
    public function getBreadcrumb()
    {
        $breadcrumb = [$this];
        $category = $this;
        
        while ($category->parent) {
            $breadcrumb[] = $category->parent;
            $category = $category->parent;
        }
        
        return array_reverse($breadcrumb);
    }
}
