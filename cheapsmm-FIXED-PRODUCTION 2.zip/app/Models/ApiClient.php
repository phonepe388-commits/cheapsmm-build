<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApiClient extends Model
{
    protected $fillable = [
        'user_id',
        'api_key',
        'api_secret',
        'name',
        'rate_limit',
        'status',
        'requests_count',
        'last_used_at'
    ];

    protected $casts = [
        'last_used_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    /**
     * Relationship: API client belongs to user
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Check if API client is rate limited
     */
    public function isRateLimited(): bool
    {
        // Rate limit: 1000 requests per hour
        $limit = $this->rate_limit ?? 1000;
        $window = 3600; // 1 hour in seconds

        $key = "api_rate_limit:{$this->id}";
        $current = cache()->get($key, 0);

        if ($current >= $limit) {
            return true;
        }

        cache()->put($key, $current + 1, $window);
        return false;
    }

    /**
     * Generate new API key
     */
    public static function generateApiKey(): string
    {
        return bin2hex(random_bytes(32));
    }

    /**
     * Generate API secret
     */
    public static function generateApiSecret(): string
    {
        return bin2hex(random_bytes(32));
    }
}
