<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CouponUsageLog extends Model
{
    protected $fillable = [
        'coupon_id',
        'user_id',
        'discount_amount',
        'original_amount',
        'usage_type'
    ];

    protected $casts = [
        'discount_amount' => 'decimal:2',
        'original_amount' => 'decimal:2'
    ];

    public function coupon()
    {
        return $this->belongsTo(Coupon::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
