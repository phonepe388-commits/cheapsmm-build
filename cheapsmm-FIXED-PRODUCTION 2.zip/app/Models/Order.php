<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'service_id',
        'api_provider_id',
        'api_order_id',
        'type',
        'link',
        'quantity',
        'start_counter',
        'remains',
        'charge',
        'currency',
        'status',
        'is_dripfeed',
        'dripfeed_runs',
        'dripfeed_interval',
        'dripfeed_completed_runs',
        'is_subscription',
        'subscription_username',
        'subscription_posts',
        'subscription_delay',
        'subscription_min',
        'subscription_max',
        'subscription_expiry',
        'subscription_status',
        'custom_comments',
        'refill_id',
        'notes',
        'api_response',
        'error_message',
        'completed_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'charge' => 'decimal:2',
        'is_dripfeed' => 'boolean',
        'is_subscription' => 'boolean',
        'subscription_expiry' => 'date',
        'api_response' => 'array',
        'completed_at' => 'datetime',
    ];

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    /**
     * Order belongs to a user
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Order belongs to a service
     */
    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    /**
     * Order belongs to an API provider
     */
    public function apiProvider()
    {
        return $this->belongsTo(ApiProvider::class);
    }

    /**
     * Order has many history records
     */
    public function history()
    {
        return $this->hasMany(OrderHistory::class);
    }

    /**
     * Order has one refill
     */
    public function refill()
    {
        return $this->hasOne(Refill::class, 'original_order_id');
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    /**
     * Scope for pending orders
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope for processing orders
     */
    public function scopeProcessing($query)
    {
        return $query->where('status', 'processing');
    }

    /**
     * Scope for in progress orders
     */
    public function scopeInProgress($query)
    {
        return $query->where('status', 'in_progress');
    }

    /**
     * Scope for completed orders
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    /**
     * Scope for cancelled orders
     */
    public function scopeCancelled($query)
    {
        return $query->where('status', 'cancelled');
    }

    /**
     * Scope for single orders
     */
    public function scopeSingle($query)
    {
        return $query->where('type', 'single');
    }

    /**
     * Scope for mass orders
     */
    public function scopeMass($query)
    {
        return $query->where('type', 'mass');
    }

    /**
     * Scope for dripfeed orders
     */
    public function scopeDripfeed($query)
    {
        return $query->where('is_dripfeed', true);
    }

    /**
     * Scope for subscription orders
     */
    public function scopeSubscription($query)
    {
        return $query->where('is_subscription', true);
    }

    /**
     * Scope for active subscriptions
     */
    public function scopeActiveSubscriptions($query)
    {
        return $query->where('is_subscription', true)
                     ->where('subscription_status', 'active');
    }

    // ========================================================================
    // ACCESSORS & MUTATORS
    // ========================================================================

    /**
     * Get formatted charge
     */
    public function getFormattedChargeAttribute()
    {
        return '$' . number_format($this->charge, 2);
    }

    /**
     * Get completion percentage
     */
    public function getCompletionPercentageAttribute()
    {
        if ($this->quantity == 0) {
            return 0;
        }

        $delivered = $this->quantity - $this->remains;
        return round(($delivered / $this->quantity) * 100, 2);
    }

    /**
     * Check if order is pending
     */
    public function getIsPendingAttribute()
    {
        return $this->status === 'pending';
    }

    /**
     * Check if order is processing
     */
    public function getIsProcessingAttribute()
    {
        return in_array($this->status, ['processing', 'in_progress']);
    }

    /**
     * Check if order is completed
     */
    public function getIsCompletedAttribute()
    {
        return $this->status === 'completed';
    }

    /**
     * Check if order is cancellable
     */
    public function getIsCancellableAttribute()
    {
        return in_array($this->status, ['pending', 'processing']);
    }

    /**
     * Check if order is refundable
     */
    public function getIsRefundableAttribute()
    {
        return $this->service->refill_enabled && 
               in_array($this->status, ['completed', 'partial']);
    }

    /**
     * Get status badge color
     */
    public function getStatusColorAttribute()
    {
        return match($this->status) {
            'pending' => 'yellow',
            'processing' => 'blue',
            'in_progress' => 'blue',
            'completed' => 'green',
            'partial' => 'orange',
            'cancelled' => 'red',
            'refunded' => 'gray',
            default => 'gray',
        };
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Update order status
     */
    public function updateStatus($newStatus, $note = null)
    {
        $oldStatus = $this->status;
        $this->status = $newStatus;

        if ($newStatus === 'completed') {
            $this->completed_at = now();
            $this->remains = 0;
        }

        $this->save();

        // Log status change
        $this->history()->create([
            'status' => $newStatus,
            'quantity' => $this->quantity,
            'remains' => $this->remains,
            'note' => $note ?? "Status changed from {$oldStatus} to {$newStatus}",
        ]);

        // Send notification to user
        $this->user->notifications()->create([
            'type' => 'order_status_updated',
            'title' => 'Order Status Updated',
            'message' => "Your order #{$this->id} status has been updated to {$newStatus}",
            'data' => [
                'order_id' => $this->id,
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
            ],
        ]);

        return $this;
    }

    /**
     * Update order progress
     */
    public function updateProgress($startCounter, $remains)
    {
        $this->start_counter = $startCounter;
        $this->remains = $remains;
        $this->save();

        // Log progress update
        $this->history()->create([
            'status' => $this->status,
            'quantity' => $this->quantity,
            'remains' => $remains,
            'note' => "Progress updated: {$this->completionPercentage}% complete",
        ]);

        return $this;
    }

    /**
     * Cancel order
     */
    public function cancel($reason = null)
    {
        if (!$this->is_cancellable) {
            throw new \Exception('This order cannot be cancelled');
        }

        $this->updateStatus('cancelled', $reason ?? 'Order cancelled by user');

        // Refund user
        $this->user->addBalance(
            $this->charge,
            "Refund for cancelled order #{$this->id}",
            'order',
            $this->id
        );

        return $this;
    }

    /**
     * Request refill
     */
    public function requestRefill()
    {
        if (!$this->is_refundable) {
            throw new \Exception('This order is not eligible for refill');
        }

        if ($this->refill) {
            throw new \Exception('Refill already requested for this order');
        }

        $refill = $this->refill()->create([
            'user_id' => $this->user_id,
            'service_id' => $this->service_id,
            'link' => $this->link,
            'quantity' => $this->quantity,
            'status' => 'pending',
            'auto_refill' => false,
        ]);

        return $refill;
    }

    /**
     * Process dripfeed run
     */
    public function processDripfeedRun()
    {
        if (!$this->is_dripfeed) {
            throw new \Exception('This is not a dripfeed order');
        }

        $this->dripfeed_completed_runs++;
        $this->save();

        return $this;
    }

    /**
     * Check if dripfeed is complete
     */
    public function isDripfeedComplete()
    {
        return $this->is_dripfeed && 
               $this->dripfeed_completed_runs >= $this->dripfeed_runs;
    }

    /**
     * Process subscription post
     */
    public function processSubscriptionPost()
    {
        if (!$this->is_subscription) {
            throw new \Exception('This is not a subscription order');
        }

        if ($this->subscription_posts > 0) {
            $this->subscription_posts--;
            $this->save();
        }

        if ($this->subscription_posts === 0) {
            $this->subscription_status = 'completed';
            $this->updateStatus('completed');
        }

        return $this;
    }

    /**
     * Pause subscription
     */
    public function pauseSubscription()
    {
        if (!$this->is_subscription) {
            throw new \Exception('This is not a subscription order');
        }

        $this->subscription_status = 'paused';
        $this->save();

        return $this;
    }

    /**
     * Resume subscription
     */
    public function resumeSubscription()
    {
        if (!$this->is_subscription) {
            throw new \Exception('This is not a subscription order');
        }

        $this->subscription_status = 'active';
        $this->save();

        return $this;
    }

    /**
     * Get time since order placed
     */
    public function getTimeSinceOrder()
    {
        return $this->created_at->diffForHumans();
    }

    /**
     * Submit to API provider
     */
    public function submitToProvider()
    {
        // This will be implemented in OrderService
        // Returns the API order ID
    }

    /**
     * Check status from API provider
     */
    public function checkStatusFromProvider()
    {
        // This will be implemented in OrderService
        // Updates order status and progress
    }
}
