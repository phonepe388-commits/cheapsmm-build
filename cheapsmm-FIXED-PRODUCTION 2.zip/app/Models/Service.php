<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Service extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'category_id',
        'api_provider_id',
        'api_service_id',
        'name',
        'description',
        'type',
        'price',
        'min_quantity',
        'max_quantity',
        'average_time',
        'refill_enabled',
        'refill_period',
        'cancel_enabled',
        'is_package',
        'is_secret',
        'is_subscription',
        'dripfeed_enabled',
        'display_order',
        'status',
        'custom_rate',
    ];

    protected $casts = [
        'price' => 'decimal:4',
        'custom_rate' => 'decimal:4',
        'refill_enabled' => 'boolean',
        'cancel_enabled' => 'boolean',
        'is_package' => 'boolean',
        'is_secret' => 'boolean',
        'is_subscription' => 'boolean',
        'dripfeed_enabled' => 'boolean',
    ];

    // ========================================================================
    // RELATIONSHIPS
    // ========================================================================

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function apiProvider()
    {
        return $this->belongsTo(ApiProvider::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function pricingTiers()
    {
        return $this->hasMany(ServicePricingTier::class);
    }

    public function reviews()
    {
        return $this->hasMany(ServiceReview::class);
    }

    // ========================================================================
    // SCOPES
    // ========================================================================

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeInactive($query)
    {
        return $query->where('status', 'inactive');
    }

    public function scopePopular($query)
    {
        return $query->withCount('orders')
                     ->orderBy('orders_count', 'desc');
    }

    public function scopeByCategory($query, $categoryId)
    {
        return $query->where('category_id', $categoryId);
    }

    public function scopeSecret($query)
    {
        return $query->where('is_secret', true);
    }

    public function scopePublic($query)
    {
        return $query->where('is_secret', false);
    }

    // ========================================================================
    // METHODS
    // ========================================================================

    /**
     * Calculate price for user with tier discount
     */
    public function getPriceForUser(User $user, $quantity)
    {
        $basePrice = $this->price;

        // Check if user has tier-specific pricing
        $tierPricing = $this->pricingTiers()
                           ->where('user_tier_id', $user->user_tier_id)
                           ->first();

        if ($tierPricing) {
            $basePrice = $tierPricing->price;
        }

        // Apply tier discount
        if ($user->tier && $user->tier->discount_percentage > 0) {
            $discount = ($basePrice * $user->tier->discount_percentage) / 100;
            $basePrice = $basePrice - $discount;
        }

        return round($basePrice * ($quantity / 1000), 2);
    }

    /**
     * Get average rating
     */
    public function getAverageRating()
    {
        return $this->reviews()
                    ->where('status', 'approved')
                    ->avg('rating');
    }

    /**
     * Get total orders count
     */
    public function getTotalOrders()
    {
        return $this->orders()->count();
    }

    /**
     * Get completed orders count
     */
    public function getCompletedOrders()
    {
        return $this->orders()->where('status', 'completed')->count();
    }

    /**
     * Check if service is available
     */
    public function isAvailable()
    {
        return $this->status === 'active' && 
               $this->apiProvider && 
               $this->apiProvider->status === 'active';
    }

    /**
     * Child panel pricing for this service
     */
    public function childPanelPricing()
    {
        return $this->hasMany(ChildPanelServicePricing::class);
    }
}
