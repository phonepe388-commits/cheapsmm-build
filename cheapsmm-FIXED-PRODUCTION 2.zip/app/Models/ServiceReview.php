<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ServiceReview extends Model {
    protected $fillable = ['service_id', 'user_id', 'order_id', 'rating', 'review', 'status'];
    public function service() { return $this->belongsTo(Service::class); }
    public function user() { return $this->belongsTo(User::class); }
}
