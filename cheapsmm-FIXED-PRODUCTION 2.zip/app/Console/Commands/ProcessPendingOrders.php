<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Models\Order;
use App\Services\OrderService;

class ProcessPendingOrders extends Command
{
    protected $signature = 'orders:process-pending';
    protected $description = 'Process pending orders';
    
    public function handle(OrderService $orderService) {
        $orders = Order::where('status', 'pending')->limit(100)->get();
        foreach ($orders as $order) {
            try {
                $orderService->processOrder($order);
            } catch (\Exception $e) {
                $this->error("Order {$order->id} failed: " . $e->getMessage());
            }
        }
        $this->info("Processed " . $orders->count() . " orders");
    }
}
