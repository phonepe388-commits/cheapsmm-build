<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Models\Order;

class CheckOrderStatus extends Command
{
    protected $signature = 'orders:check-status';
    protected $description = 'Check status of in-progress orders';
    
    public function handle() {
        $orders = Order::where('status', 'in_progress')->get();
        foreach ($orders as $order) {
            // Check with API provider
            if ($order->apiProvider) {
                $status = $order->apiProvider->checkOrderStatus($order->provider_order_id);
                $order->update(['status' => $status]);
            }
        }
        $this->info("Checked " . $orders->count() . " orders");
    }
}
