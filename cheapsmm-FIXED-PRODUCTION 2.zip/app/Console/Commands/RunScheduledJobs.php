<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\{
    CheckOrdersStatusJob,
    ProcessDripfeedOrders,
    GenerateDailyStatistics,
    SendLowBalanceAlerts,
    CleanupInactiveUsers,
    UpdateExchangeRates
};

class RunScheduledJobs extends Command
{
    protected $signature = 'schedule:run-all {--job=}';
    protected $description = 'Run all scheduled jobs or a specific job';

    public function handle()
    {
        $job = $this->option('job');

        if ($job) {
            $this->runSpecificJob($job);
        } else {
            $this->runAllJobs();
        }
    }

    private function runAllJobs()
    {
        $this->info('Running all scheduled jobs...');

        $this->runJob('order-status', CheckOrdersStatusJob::class);
        $this->runJob('dripfeed', ProcessDripfeedOrders::class);
        $this->runJob('exchange-rates', UpdateExchangeRates::class);
        $this->runJob('low-balance', SendLowBalanceAlerts::class);

        $this->info('All jobs completed!');
    }

    private function runSpecificJob(string $jobName)
    {
        $jobs = [
            'order-status' => CheckOrdersStatusJob::class,
            'dripfeed' => ProcessDripfeedOrders::class,
            'statistics' => GenerateDailyStatistics::class,
            'low-balance' => SendLowBalanceAlerts::class,
            'cleanup' => CleanupInactiveUsers::class,
            'exchange-rates' => UpdateExchangeRates::class,
        ];

        if (!isset($jobs[$jobName])) {
            $this->error("Unknown job: {$jobName}");
            $this->info("Available jobs: " . implode(', ', array_keys($jobs)));
            return;
        }

        $this->runJob($jobName, $jobs[$jobName]);
    }

    private function runJob(string $name, string $jobClass)
    {
        $this->info("Running {$name}...");
        
        try {
            dispatch(new $jobClass());
            $this->info("✓ {$name} completed");
        } catch (\Exception $e) {
            $this->error("✗ {$name} failed: " . $e->getMessage());
        }
    }
}
