<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Models\Backup;

class BackupDatabase extends Command
{
    protected $signature = 'backup:database';
    protected $description = 'Backup database';
    
    public function handle() {
        $filename = 'backup_' . date('Y-m-d_His') . '.sql';
        $path = storage_path('app/backups/' . $filename);
        
        $command = sprintf(
            'mysqldump -u%s -p%s %s > %s',
            config('database.connections.mysql.username'),
            config('database.connections.mysql.password'),
            config('database.connections.mysql.database'),
            $path
        );
        
        exec($command);
        
        Backup::create([
            'type' => 'database',
            'filename' => $filename,
            'size' => filesize($path),
            'path' => $path,
            'status' => 'completed'
        ]);
        
        $this->info("Backup created: " . $filename);
    }
}
