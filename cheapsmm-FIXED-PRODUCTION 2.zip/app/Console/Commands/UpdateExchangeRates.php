<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Services\CurrencyService;

class UpdateExchangeRates extends Command
{
    protected $signature = 'currency:update-rates';
    protected $description = 'Update currency exchange rates';
    
    public function handle(CurrencyService $currencyService) {
        $currencyService->updateExchangeRates();
        $this->info("Exchange rates updated");
    }
}
