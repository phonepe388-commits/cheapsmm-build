<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule)
    {
        // Check order status every 5 minutes
        $schedule->job(new \App\Jobs\CheckOrdersStatusJob)
            ->everyFiveMinutes()
            ->name('check-orders-status')
            ->withoutOverlapping();

        // Process dripfeed orders every 10 minutes
        $schedule->job(new \App\Jobs\ProcessDripfeedOrders)
            ->everyTenMinutes()
            ->name('process-dripfeed')
            ->withoutOverlapping();

        // Update exchange rates every 6 hours
        $schedule->job(new \App\Jobs\UpdateExchangeRates)
            ->everySixHours()
            ->name('update-exchange-rates');

        // Send low balance alerts daily at 9 AM
        $schedule->job(new \App\Jobs\SendLowBalanceAlerts)
            ->dailyAt('09:00')
            ->name('low-balance-alerts');

        // Generate daily statistics at 12:30 AM
        $schedule->job(new \App\Jobs\GenerateDailyStatistics)
            ->dailyAt('00:30')
            ->name('daily-statistics');

        // Cleanup inactive users weekly on Sunday at 2 AM
        $schedule->job(new \App\Jobs\CleanupInactiveUsers)
            ->weekly()
            ->sundays()
            ->at('02:00')
            ->name('cleanup-inactive-users');

        // Create automated database backup daily at 3 AM
        $schedule->job(new \App\Jobs\CreateAutomatedBackup)
            ->dailyAt('03:00')
            ->name('automated-backup');
    }

    /**
     * Register the commands for the application.
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
