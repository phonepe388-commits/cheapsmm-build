<?php

namespace App\Jobs;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\Log;

class CleanupInactiveUsers implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        Log::info('Cleaning up inactive users...');

        // Delete users who never verified email after 30 days
        $unverifiedUsers = User::whereNull('email_verified_at')
            ->where('created_at', '<', now()->subDays(30))
            ->get();

        $deleted = 0;

        foreach ($unverifiedUsers as $user) {
            // Only delete if no orders or balance
            if ($user->orders()->count() === 0 && $user->balance == 0) {
                $user->delete();
                $deleted++;
            }
        }

        // Mark inactive users (no login for 90 days)
        $inactive = User::where('last_login_at', '<', now()->subDays(90))
            ->where('status', 'active')
            ->update(['status' => 'inactive']);

        Log::info("Cleanup completed. Deleted: {$deleted}, Marked inactive: {$inactive}");
    }
}
