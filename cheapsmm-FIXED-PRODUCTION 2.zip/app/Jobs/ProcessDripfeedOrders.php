<?php

namespace App\Jobs;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\Log;

class ProcessDripfeedOrders implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        Log::info('Processing dripfeed orders...');

        $orders = Order::where('is_dripfeed', true)
            ->where('status', 'pending')
            ->where('dripfeed_runs', '>', 0)
            ->get();

        $processed = 0;

        foreach ($orders as $order) {
            try {
                $this->processDripfeedRun($order);
                $processed++;
            } catch (\Exception $e) {
                Log::error("Error processing dripfeed order #{$order->id}: " . $e->getMessage());
            }
        }

        Log::info("Dripfeed processing completed. Processed: {$processed} orders");
    }

    private function processDripfeedRun(Order $order): void
    {
        // Calculate quantity per run
        $quantityPerRun = ceil($order->quantity / $order->dripfeed_runs);
        
        // Create sub-order for this run
        $subOrder = Order::create([
            'user_id' => $order->user_id,
            'service_id' => $order->service_id,
            'parent_order_id' => $order->id,
            'link' => $order->link,
            'quantity' => $quantityPerRun,
            'charge' => 0, // Already charged in parent order
            'status' => 'pending',
            'is_dripfeed' => false
        ]);

        // Decrement remaining runs
        $order->decrement('dripfeed_runs');

        // Update parent order status if all runs complete
        if ($order->dripfeed_runs <= 0) {
            $order->update(['status' => 'completed']);
        }

        Log::info("Created dripfeed run #{$subOrder->id} for order #{$order->id}");
    }
}
