<?php

namespace App\Jobs;

use App\Models\User;
use App\Mail\LowBalanceAlert;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{Mail, Log};

class SendLowBalanceAlerts implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        Log::info('Checking for low balance users...');

        $threshold = 10.00; // Alert when balance below $10

        $users = User::where('balance', '<', $threshold)
            ->where('balance', '>', 0)
            ->where('status', 'active')
            ->whereDoesntHave('notifications', function($query) {
                $query->where('type', 'low_balance')
                      ->where('created_at', '>', now()->subDay());
            })
            ->get();

        $sent = 0;

        foreach ($users as $user) {
            try {
                Mail::to($user->email)->send(new LowBalanceAlert($user));
                
                // Log notification
                $user->notifications()->create([
                    'type' => 'low_balance',
                    'title' => 'Low Balance Alert',
                    'message' => "Your balance is low: $" . number_format($user->balance, 2),
                    'read' => false
                ]);

                $sent++;
            } catch (\Exception $e) {
                Log::error("Error sending low balance alert to user #{$user->id}: " . $e->getMessage());
            }
        }

        Log::info("Low balance alerts sent: {$sent}");
    }
}
