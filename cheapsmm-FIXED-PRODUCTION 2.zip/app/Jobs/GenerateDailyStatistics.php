<?php

namespace App\Jobs;

use App\Models\{Order, User, Payment};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\{DB, Log};

class GenerateDailyStatistics implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        Log::info('Generating daily statistics...');

        $yesterday = now()->subDay();

        $stats = [
            'date' => $yesterday->format('Y-m-d'),
            'total_orders' => Order::whereDate('created_at', $yesterday)->count(),
            'completed_orders' => Order::whereDate('created_at', $yesterday)
                ->where('status', 'completed')->count(),
            'total_revenue' => Order::whereDate('created_at', $yesterday)->sum('charge'),
            'new_users' => User::whereDate('created_at', $yesterday)->count(),
            'total_payments' => Payment::whereDate('created_at', $yesterday)
                ->where('status', 'completed')->sum('amount'),
        ];

        // Store in database or cache
        DB::table('daily_statistics')->insert([
            'date' => $stats['date'],
            'data' => json_encode($stats),
            'created_at' => now()
        ]);

        Log::info('Daily statistics generated', $stats);
    }
}
