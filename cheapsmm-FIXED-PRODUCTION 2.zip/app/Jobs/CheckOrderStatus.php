<?php
namespace App\Jobs;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
class CheckOrderStatus implements ShouldQueue {
    use Queueable;
    public function __construct(public Order $order) {}
    public function handle(OrderService $orderService) {
        $orderService->checkOrderStatus($this->order);
    }
}
