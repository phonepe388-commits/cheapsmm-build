<?php
namespace App\Jobs;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
class ProcessOrder implements ShouldQueue {
    use Queueable, InteractsWithQueue, SerializesModels;
    public function __construct(public Order $order) {}
    public function handle(OrderService $orderService) {
        $orderService->processOrder($this->order);
    }
}
