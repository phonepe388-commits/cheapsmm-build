<?php

namespace App\Jobs;

use App\Services\BackupService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\Log;

class CreateAutomatedBackup implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(BackupService $backupService)
    {
        Log::info('Creating automated backup...');

        try {
            // Create database backup
            $backup = $backupService->createDatabaseBackup();
            Log::info("Database backup created: {$backup->filename}");

            // Delete old backups (keep 30 days)
            $deleted = $backupService->deleteOldBackups(30);
            Log::info("Deleted {$deleted} old backups");

        } catch (\Exception $e) {
            Log::error('Automated backup failed: ' . $e->getMessage());
        }
    }
}
