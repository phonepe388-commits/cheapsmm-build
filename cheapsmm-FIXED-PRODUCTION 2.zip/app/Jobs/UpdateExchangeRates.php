<?php

namespace App\Jobs;

use App\Services\CurrencyService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\Log;

class UpdateExchangeRates implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Execute the job.
     */
    public function handle(CurrencyService $currencyService): void
    {
        try {
            $updated = $currencyService->updateExchangeRates();

            Log::info("Exchange rates updated successfully. {$updated} currencies updated.");

            // Log to admin notifications
            \App\Models\Admin::where('status', 'active')->each(function($admin) use ($updated) {
                $admin->notifications()->create([
                    'type' => 'system',
                    'title' => 'Exchange Rates Updated',
                    'message' => "{$updated} currency exchange rates were updated successfully.",
                    'data' => ['updated_count' => $updated, 'updated_at' => now()]
                ]);
            });

        } catch (\Exception $e) {
            Log::error('Exchange rate update job failed: ' . $e->getMessage());

            // Notify admins of failure
            \App\Models\Admin::where('status', 'active')->each(function($admin) use ($e) {
                $admin->notifications()->create([
                    'type' => 'error',
                    'title' => 'Exchange Rate Update Failed',
                    'message' => 'Failed to update exchange rates: ' . $e->getMessage(),
                    'data' => ['error' => $e->getMessage()]
                ]);
            });

            throw $e;
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(\Throwable $exception): void
    {
        Log::error('Exchange rate update job failed permanently: ' . $exception->getMessage());
    }
}
