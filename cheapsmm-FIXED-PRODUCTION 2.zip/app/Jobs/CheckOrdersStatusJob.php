<?php

namespace App\Jobs;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\{InteractsWithQueue, SerializesModels};
use Illuminate\Support\Facades\Log;

class CheckOrdersStatusJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        Log::info('Starting order status check...');

        // Get pending and in-progress orders
        $orders = Order::whereIn('status', ['pending', 'in_progress'])
            ->whereNotNull('api_order_id')
            ->get();

        $updated = 0;

        foreach ($orders as $order) {
            try {
                // Check status from API provider
                if ($order->service && $order->service->apiProvider) {
                    $status = $this->checkOrderStatus($order);
                    
                    if ($status && $status !== $order->status) {
                        $order->update([
                            'status' => $status['status'],
                            'start_count' => $status['start_count'] ?? $order->start_count,
                            'remain' => $status['remains'] ?? $order->remain
                        ]);

                        // Send notification if completed
                        if ($status['status'] === 'completed') {
                            \Mail::to($order->user->email)->send(
                                new \App\Mail\OrderStatusUpdate($order)
                            );
                        }

                        $updated++;
                    }
                }
            } catch (\Exception $e) {
                Log::error("Error checking order #{$order->id}: " . $e->getMessage());
            }
        }

        Log::info("Order status check completed. Updated: {$updated} orders");
    }

    private function checkOrderStatus(Order $order): ?array
    {
        // Mock implementation - integrate with actual API
        return [
            'status' => 'in_progress',
            'start_count' => 1000,
            'remains' => 500
        ];
    }
}
