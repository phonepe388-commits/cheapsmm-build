<?php

use App\Services\CurrencyService;

if (!function_exists('currency')) {
    /**
     * Get currency service instance
     */
    function currency(): CurrencyService
    {
        return app(CurrencyService::class);
    }
}

if (!function_exists('convert_price')) {
    /**
     * Convert price to current currency
     */
    function convert_price(float $amount, string $toCurrency = null): float
    {
        return currency()->convert($amount, $toCurrency);
    }
}

if (!function_exists('format_price')) {
    /**
     * Format price with currency symbol
     */
    function format_price(float $amount, string $currencyCode = null): string
    {
        return currency()->format($amount, $currencyCode);
    }
}

if (!function_exists('price')) {
    /**
     * Convert and format price in one go
     */
    function price(float $amount, string $toCurrency = null): string
    {
        return currency()->convertAndFormat($amount, $toCurrency);
    }
}

if (!function_exists('current_currency')) {
    /**
     * Get current currency code
     */
    function current_currency(): string
    {
        return session('currency', 'USD');
    }
}

if (!function_exists('current_currency_symbol')) {
    /**
     * Get current currency symbol
     */
    function current_currency_symbol(): string
    {
        $curr = currency()->getCurrentCurrency();
        return $curr->symbol ?? '$';
    }
}
