<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\EmailService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    protected $emailService;

    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed'
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'referral_code' => $this->generateReferralCode(),
            'status' => 'active',
            'balance' => 0
        ]);

        // Send welcome email
        $this->emailService->sendWelcomeEmail($user);

        // Log activity
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'user_registered',
            'description' => 'New user registered',
            'ip_address' => $request->ip()
        ]);

        auth()->login($user);

        return redirect()->route('user.dashboard')
            ->with('success', 'Welcome! Check your email for getting started tips.');
    }

    /**
     * Generate unique referral code
     */
    private function generateReferralCode(): string
    {
        do {
            $code = strtoupper(substr(md5(uniqid()), 0, 8));
        } while (User::where('referral_code', $code)->exists());

        return $code;
    }
}

    /**
     * Handle referral code after registration
     */
    protected function registered(Request $request, $user)
    {
        // Check for referral code
        if ($request->has('ref')) {
            $referralService = app(\App\Services\ReferralService::class);
            $referralService->trackSignup($user, $request->ref);
        }
    }
}
