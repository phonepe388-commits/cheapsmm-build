<?php

namespace App\Http\Controllers;

use App\Models\{Blog, Page, FAQ};

class BlogController extends Controller
{
    public function index()
    {
        $posts = Blog::where('status', 'published')->latest()->paginate(12);
        return view('blog.index', compact('posts'));
    }

    public function show(Blog $blog)
    {
        if ($blog->status !== 'published') {
            abort(404);
        }

        return view('blog.show', compact('blog'));
    }

    public function page(Page $page)
    {
        if ($page->status !== 'published') {
            abort(404);
        }

        return view('blog.page', compact('page'));
    }

    public function faqs()
    {
        $faqs = FAQ::orderBy('order')->get();
        return view('blog.faqs', compact('faqs'));
    }
}
