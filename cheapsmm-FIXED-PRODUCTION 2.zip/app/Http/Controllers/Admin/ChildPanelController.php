<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ChildPanel;
use Illuminate\Http\Request;

class ChildPanelController extends Controller
{
    /**
     * Show all child panels
     */
    public function index(Request $request)
    {
        $query = ChildPanel::with('user')->withCount('childUsers', 'orders');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('domain', 'like', '%' . $request->search . '%')
                  ->orWhere('subdomain', 'like', '%' . $request->search . '%');
            });
        }

        $panels = $query->latest()->paginate(20);

        $stats = [
            'total' => ChildPanel::count(),
            'active' => ChildPanel::where('status', 'active')->count(),
            'inactive' => ChildPanel::where('status', 'inactive')->count(),
            'total_users' => \DB::table('child_panel_users')->count(),
            'total_revenue' => ChildPanel::sum('balance')
        ];

        return view('admin.child-panels.index', compact('panels', 'stats'));
    }

    /**
     * Show child panel details
     */
    public function show(ChildPanel $childPanel)
    {
        $childPanel->load(['user', 'childUsers', 'orders' => function($q) {
            $q->latest()->limit(20);
        }]);

        $stats = [
            'total_users' => $childPanel->childUsers()->count(),
            'total_orders' => $childPanel->orders()->count(),
            'total_revenue' => $childPanel->orders()->sum('charge'),
            'balance' => $childPanel->balance
        ];

        return view('admin.child-panels.show', compact('childPanel', 'stats'));
    }

    /**
     * Update child panel status
     */
    public function updateStatus(Request $request, ChildPanel $childPanel)
    {
        $validated = $request->validate([
            'status' => 'required|in:active,inactive,suspended'
        ]);

        $childPanel->update($validated);

        return back()->with('success', 'Child panel status updated!');
    }

    /**
     * Add/deduct balance
     */
    public function adjustBalance(Request $request, ChildPanel $childPanel)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric',
            'type' => 'required|in:add,deduct',
            'note' => 'nullable|string'
        ]);

        if ($validated['type'] === 'add') {
            $childPanel->addBalance($validated['amount']);
        } else {
            $childPanel->deductBalance($validated['amount']);
        }

        // Log the adjustment
        \Log::info("Admin adjusted child panel #{$childPanel->id} balance", $validated);

        return back()->with('success', 'Balance adjusted successfully!');
    }

    /**
     * Delete child panel
     */
    public function destroy(ChildPanel $childPanel)
    {
        if ($childPanel->childUsers()->count() > 0) {
            return back()->withErrors(['error' => 'Cannot delete panel with users']);
        }

        $childPanel->delete();

        return redirect()->route('admin.child-panels.index')
            ->with('success', 'Child panel deleted!');
    }
}
