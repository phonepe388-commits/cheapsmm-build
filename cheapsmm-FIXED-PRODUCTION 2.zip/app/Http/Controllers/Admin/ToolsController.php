<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{User, Order, Service};
use Illuminate\Http\Request;

class ToolsController extends Controller
{
    public function bulkUserUpdate(Request $request) {
        $validated = $request->validate([
            'user_ids' => 'required|array',
            'action' => 'required|in:activate,suspend,add_balance',
            'amount' => 'nullable|numeric'
        ]);
        
        $users = User::whereIn('id', $validated['user_ids']);
        
        switch ($validated['action']) {
            case 'activate':
                $users->update(['status' => 'active']);
                break;
            case 'suspend':
                $users->update(['status' => 'suspended']);
                break;
            case 'add_balance':
                foreach ($users->get() as $user) {
                    $user->increment('balance', $validated['amount']);
                }
                break;
        }
        
        return back()->with('success', 'Bulk action completed!');
    }
    
    public function dataCleanup() {
        // Delete old logs
        \DB::table('api_logs')->where('created_at', '<', now()->subDays(30))->delete();
        \DB::table('activity_logs')->where('created_at', '<', now()->subDays(90))->delete();
        return back()->with('success', 'Cleanup completed!');
    }
}
