<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Services\CurrencyService;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    protected $currencyService;

    public function __construct(CurrencyService $currencyService)
    {
        $this->currencyService = $currencyService;
    }

    /**
     * Display all currencies
     */
    public function index()
    {
        $currencies = Currency::orderBy('sort_order')->paginate(20);
        
        $stats = [
            'total' => Currency::count(),
            'active' => Currency::where('status', 'active')->count(),
            'last_update' => Currency::max('last_updated')
        ];

        return view('admin.currencies.index', compact('currencies', 'stats'));
    }

    /**
     * Show create form
     */
    public function create()
    {
        return view('admin.currencies.create');
    }

    /**
     * Store new currency
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'code' => 'required|string|size:3|unique:currencies',
            'name' => 'required|string|max:100',
            'symbol' => 'required|string|max:10',
            'symbol_position' => 'required|in:before,after',
            'exchange_rate' => 'required|numeric|min:0',
            'decimal_places' => 'required|integer|min:0|max:4',
            'is_popular' => 'boolean',
            'status' => 'required|in:active,inactive'
        ]);

        Currency::create($validated);

        return redirect()->route('admin.currencies.index')
            ->with('success', 'Currency created successfully');
    }

    /**
     * Show edit form
     */
    public function edit(Currency $currency)
    {
        return view('admin.currencies.edit', compact('currency'));
    }

    /**
     * Update currency
     */
    public function update(Request $request, Currency $currency)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'symbol' => 'required|string|max:10',
            'symbol_position' => 'required|in:before,after',
            'exchange_rate' => 'required|numeric|min:0',
            'decimal_places' => 'required|integer|min:0|max:4',
            'is_popular' => 'boolean',
            'status' => 'required|in:active,inactive',
            'sort_order' => 'nullable|integer'
        ]);

        $currency->update($validated);

        return redirect()->route('admin.currencies.index')
            ->with('success', 'Currency updated successfully');
    }

    /**
     * Delete currency
     */
    public function destroy(Currency $currency)
    {
        if ($currency->code === 'USD') {
            return back()->withErrors(['error' => 'Cannot delete base currency']);
        }

        $currency->delete();

        return redirect()->route('admin.currencies.index')
            ->with('success', 'Currency deleted successfully');
    }

    /**
     * Update all exchange rates
     */
    public function updateRates()
    {
        $result = $this->currencyService->updateExchangeRates();

        if ($result['success']) {
            return back()->with('success', "Updated {$result['updated']} currencies successfully");
        }

        return back()->withErrors(['error' => $result['error']]);
    }
}
