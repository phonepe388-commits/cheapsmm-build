<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{User, Order, Payment, Ticket, Service};
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // Overview stats
        $stats = [
            'total_users' => User::count(),
            'active_users' => User::where('status', 'active')->count(),
            'new_users_today' => User::whereDate('created_at', today())->count(),
            'new_users_week' => User::where('created_at', '>=', now()->subDays(7))->count(),
            
            'total_orders' => Order::count(),
            'pending_orders' => Order::where('status', 'pending')->count(),
            'processing_orders' => Order::where('status', 'processing')->count(),
            'completed_today' => Order::whereDate('completed_at', today())->count(),
            
            'total_revenue' => Payment::where('status', 'completed')->sum('amount'),
            'revenue_today' => Payment::where('status', 'completed')->whereDate('created_at', today())->sum('amount'),
            'revenue_week' => Payment::where('status', 'completed')->where('created_at', '>=', now()->subDays(7))->sum('amount'),
            'revenue_month' => Payment::where('status', 'completed')->whereMonth('created_at', now()->month)->sum('amount'),
            
            'open_tickets' => Ticket::where('status', '!=', 'closed')->count(),
            'active_services' => Service::where('status', 'active')->count()
        ];

        // Recent orders
        $recentOrders = Order::with(['user', 'service'])
            ->latest()
            ->limit(10)
            ->get();

        // Recent users
        $recentUsers = User::latest()->limit(10)->get();

        // Recent payments
        $recentPayments = Payment::with('user')
            ->latest()
            ->limit(10)
            ->get();

        // Revenue chart data (last 30 days)
        $revenueChart = Payment::where('status', 'completed')
            ->where('created_at', '>=', now()->subDays(30))
            ->selectRaw('DATE(created_at) as date, SUM(amount) as total')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Orders chart data (last 30 days)
        $ordersChart = Order::where('created_at', '>=', now()->subDays(30))
            ->selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Top services
        $topServices = Order::select('service_id', DB::raw('COUNT(*) as order_count'))
            ->groupBy('service_id')
            ->orderByDesc('order_count')
            ->with('service')
            ->limit(5)
            ->get();

        // Top users by spending
        $topUsers = User::withSum(['transactions' => function($q) {
                $q->where('type', 'debit');
            }], 'amount')
            ->orderByDesc('transactions_sum_amount')
            ->limit(5)
            ->get();

        return view('admin.dashboard.index', compact(
            'stats',
            'recentOrders',
            'recentUsers',
            'recentPayments',
            'revenueChart',
            'ordersChart',
            'topServices',
            'topUsers'
        ));
    }
}
