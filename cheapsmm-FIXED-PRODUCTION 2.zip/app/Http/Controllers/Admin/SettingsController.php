<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;

class SettingsController extends Controller
{
    public function index()
    {
        $settings = Setting::all()->pluck('value', 'key');
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'site_name' => 'required|string|max:255',
            'site_description' => 'nullable|string',
            'site_keywords' => 'nullable|string',
            'contact_email' => 'required|email',
            'support_email' => 'required|email',
            'currency_code' => 'required|string|size:3',
            'currency_symbol' => 'required|string|max:5',
            'timezone' => 'required|timezone',
            'date_format' => 'required|string',
            'time_format' => 'required|string',
            'min_deposit' => 'required|numeric|min:0',
            'max_deposit' => 'required|numeric|min:0',
            'min_order' => 'required|integer|min:1',
            'default_api_rate_limit' => 'required|integer|min:100',
            'enable_registration' => 'boolean',
            'enable_email_verification' => 'boolean',
            'enable_referrals' => 'boolean',
            'referral_percentage' => 'nullable|numeric|min:0|max:100',
            'enable_maintenance_mode' => 'boolean',
            'maintenance_message' => 'nullable|string'
        ]);

        foreach ($validated as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value, 'type' => $this->getSettingType($value)]
            );
        }

        Cache::forget('settings');

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'settings_updated',
            'description' => 'System settings updated',
            'ip_address' => $request->ip()
        ]);

        return back()->with('success', 'Settings updated successfully');
    }

    public function email()
    {
        $settings = Setting::all()->pluck('value', 'key');
        return view('admin.settings.email', compact('settings'));
    }

    public function updateEmail(Request $request)
    {
        $validated = $request->validate([
            'mail_mailer' => 'required|in:smtp,sendmail,mailgun,ses,postmark',
            'mail_host' => 'required_if:mail_mailer,smtp',
            'mail_port' => 'required_if:mail_mailer,smtp|nullable|integer',
            'mail_username' => 'nullable|string',
            'mail_password' => 'nullable|string',
            'mail_encryption' => 'nullable|in:tls,ssl',
            'mail_from_address' => 'required|email',
            'mail_from_name' => 'required|string'
        ]);

        foreach ($validated as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value, 'type' => 'string']
            );
        }

        Cache::forget('settings');

        return back()->with('success', 'Email settings updated successfully');
    }

    public function payment()
    {
        $settings = Setting::all()->pluck('value', 'key');
        return view('admin.settings.payment', compact('settings'));
    }

    public function updatePayment(Request $request)
    {
        $validated = $request->validate([
            'stripe_public_key' => 'nullable|string',
            'stripe_secret_key' => 'nullable|string',
            'stripe_webhook_secret' => 'nullable|string',
            'paypal_client_id' => 'nullable|string',
            'paypal_secret' => 'nullable|string',
            'paypal_mode' => 'nullable|in:sandbox,live',
            'razorpay_key_id' => 'nullable|string',
            'razorpay_key_secret' => 'nullable|string',
            'enable_stripe' => 'boolean',
            'enable_paypal' => 'boolean',
            'enable_razorpay' => 'boolean'
        ]);

        foreach ($validated as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value, 'type' => $this->getSettingType($value)]
            );
        }

        Cache::forget('settings');

        return back()->with('success', 'Payment settings updated successfully');
    }

    public function api()
    {
        $settings = Setting::all()->pluck('value', 'key');
        return view('admin.settings.api', compact('settings'));
    }

    public function updateApi(Request $request)
    {
        $validated = $request->validate([
            'enable_api' => 'boolean',
            'api_rate_limit' => 'required|integer|min:100',
            'api_token_expiry' => 'required|integer|min:1',
            'enable_api_documentation' => 'boolean'
        ]);

        foreach ($validated as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value, 'type' => $this->getSettingType($value)]
            );
        }

        Cache::forget('settings');

        return back()->with('success', 'API settings updated successfully');
    }

    public function cache()
    {
        return view('admin.settings.cache');
    }

    public function clearCache(Request $request)
    {
        $type = $request->input('type', 'all');

        switch ($type) {
            case 'application':
                Artisan::call('cache:clear');
                $message = 'Application cache cleared';
                break;
            case 'route':
                Artisan::call('route:clear');
                $message = 'Route cache cleared';
                break;
            case 'config':
                Artisan::call('config:clear');
                $message = 'Configuration cache cleared';
                break;
            case 'view':
                Artisan::call('view:clear');
                $message = 'View cache cleared';
                break;
            default:
                Artisan::call('cache:clear');
                Artisan::call('route:clear');
                Artisan::call('config:clear');
                Artisan::call('view:clear');
                $message = 'All caches cleared';
        }

        return back()->with('success', $message);
    }

    public function optimize()
    {
        Artisan::call('optimize');
        return back()->with('success', 'Application optimized successfully');
    }

    private function getSettingType($value)
    {
        if (is_bool($value)) return 'boolean';
        if (is_numeric($value)) return 'number';
        if (is_array($value)) return 'array';
        return 'string';
    }
}
