<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use App\Models\Service;
use App\Services\OrderService;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    /**
     * Display all orders
     */
    public function index(Request $request)
    {
        $query = Order::with(['user', 'service.category']);

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('id', $request->search)
                  ->orWhere('link', 'like', "%{$request->search}%")
                  ->orWhereHas('user', function($q) use ($request) {
                      $q->where('email', 'like', "%{$request->search}%")
                        ->orWhere('name', 'like', "%{$request->search}%");
                  });
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by service
        if ($request->filled('service_id')) {
            $query->where('service_id', $request->service_id);
        }

        // Filter by user
        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        // Filter by date range
        if ($request->filled('from')) {
            $query->whereDate('created_at', '>=', $request->from);
        }
        if ($request->filled('to')) {
            $query->whereDate('created_at', '<=', $request->to);
        }

        // Sort
        $sortBy = $request->input('sort_by', 'created_at');
        $sortDir = $request->input('sort_dir', 'desc');
        $query->orderBy($sortBy, $sortDir);

        $orders = $query->paginate(50);

        // Calculate stats
        $stats = [
            'total' => Order::count(),
            'pending' => Order::where('status', 'pending')->count(),
            'processing' => Order::where('status', 'processing')->count(),
            'completed' => Order::where('status', 'completed')->count(),
            'partial' => Order::where('status', 'partial')->count(),
            'cancelled' => Order::where('status', 'cancelled')->count(),
            'today_orders' => Order::whereDate('created_at', today())->count(),
            'today_revenue' => Order::whereDate('created_at', today())->sum('price')
        ];

        // Get services for filter
        $services = Service::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name']);

        return view('admin.orders.index', compact('orders', 'stats', 'services'));
    }

    /**
     * Show order details
     */
    public function show(Order $order)
    {
        $order->load(['user', 'service.category', 'histories']);

        // Get related orders from same user
        $relatedOrders = Order::where('user_id', $order->user_id)
            ->where('id', '!=', $order->id)
            ->latest()
            ->limit(10)
            ->get();

        return view('admin.orders.show', compact('order', 'relatedOrders'));
    }

    /**
     * Update order status
     */
    public function updateStatus(Request $request, Order $order)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,processing,completed,partial,cancelled,refunded',
            'admin_note' => 'nullable|string|max:1000'
        ]);

        $oldStatus = $order->status;

        // Update status
        $order->update([
            'status' => $validated['status'],
            'admin_note' => $validated['admin_note'] ?? $order->admin_note
        ]);

        // Add to order history
        $order->histories()->create([
            'status' => $validated['status'],
            'description' => $validated['admin_note'] ?? "Status changed from {$oldStatus} to {$validated['status']}",
            'created_by' => auth()->guard('admin')->id(),
            'is_admin' => true
        ]);

        // Handle refund if status is refunded
        if ($validated['status'] === 'refunded' && $oldStatus !== 'refunded') {
            $user = $order->user;
            $refundAmount = $order->price;

            // Add funds back to user
            $oldBalance = $user->balance;
            $user->increment('balance', $refundAmount);

            // Create transaction
            $user->transactions()->create([
                'type' => 'credit',
                'amount' => $refundAmount,
                'currency' => 'USD',
                'balance_before' => $oldBalance,
                'balance_after' => $oldBalance + $refundAmount,
                'description' => "Refund for order #{$order->id}",
                'reference_type' => 'order',
                'reference_id' => $order->id
            ]);

            // Notify user
            $user->notifications()->create([
                'type' => 'order_refunded',
                'title' => 'Order Refunded',
                'message' => "Your order #{$order->id} has been refunded. Amount: $" . number_format($refundAmount, 2),
                'data' => ['order_id' => $order->id, 'amount' => $refundAmount]
            ]);
        }

        // Notify user of status change
        $order->user->notifications()->create([
            'type' => 'order_status_updated',
            'title' => 'Order Status Updated',
            'message' => "Your order #{$order->id} status has been updated to: {$validated['status']}",
            'data' => ['order_id' => $order->id, 'status' => $validated['status']]
        ]);

        // Log activity
        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'order_status_updated',
            'description' => "Updated order #{$order->id} status from {$oldStatus} to {$validated['status']}",
            'ip_address' => $request->ip()
        ]);

        return back()->with('success', 'Order status updated successfully');
    }

    /**
     * Update order quantity/start count
     */
    public function updateQuantity(Request $request, Order $order)
    {
        $validated = $request->validate([
            'start_count' => 'nullable|integer|min:0',
            'remains' => 'nullable|integer|min:0'
        ]);

        $order->update($validated);

        // Add to order history
        $order->histories()->create([
            'status' => $order->status,
            'description' => 'Quantity updated by admin',
            'created_by' => auth()->guard('admin')->id(),
            'is_admin' => true
        ]);

        return back()->with('success', 'Order quantity updated successfully');
    }

    /**
     * Cancel order
     */
    public function cancel(Request $request, Order $order)
    {
        $validated = $request->validate([
            'reason' => 'nullable|string|max:500',
            'refund' => 'boolean'
        ]);

        if ($order->status === 'cancelled') {
            return back()->with('info', 'Order is already cancelled');
        }

        $order->update([
            'status' => 'cancelled',
            'admin_note' => $validated['reason'] ?? 'Cancelled by admin'
        ]);

        // Add to order history
        $order->histories()->create([
            'status' => 'cancelled',
            'description' => $validated['reason'] ?? 'Order cancelled by admin',
            'created_by' => auth()->guard('admin')->id(),
            'is_admin' => true
        ]);

        // Handle refund
        if ($request->boolean('refund', true)) {
            $user = $order->user;
            $refundAmount = $order->price;

            $oldBalance = $user->balance;
            $user->increment('balance', $refundAmount);

            $user->transactions()->create([
                'type' => 'credit',
                'amount' => $refundAmount,
                'currency' => 'USD',
                'balance_before' => $oldBalance,
                'balance_after' => $oldBalance + $refundAmount,
                'description' => "Refund for cancelled order #{$order->id}",
                'reference_type' => 'order',
                'reference_id' => $order->id
            ]);
        }

        // Notify user
        $order->user->notifications()->create([
            'type' => 'order_cancelled',
            'title' => 'Order Cancelled',
            'message' => "Your order #{$order->id} has been cancelled" . ($request->boolean('refund', true) ? ' and refunded' : ''),
            'data' => ['order_id' => $order->id]
        ]);

        return back()->with('success', 'Order cancelled successfully' . ($request->boolean('refund', true) ? ' and refunded' : ''));
    }

    /**
     * Bulk update orders
     */
    public function bulkUpdate(Request $request)
    {
        $validated = $request->validate([
            'order_ids' => 'required|array',
            'order_ids.*' => 'exists:orders,id',
            'action' => 'required|in:update_status,cancel,delete',
            'status' => 'required_if:action,update_status|in:pending,processing,completed,partial,cancelled',
            'refund' => 'boolean'
        ]);

        $orderIds = $validated['order_ids'];
        $action = $validated['action'];

        $updated = 0;

        foreach ($orderIds as $orderId) {
            $order = Order::find($orderId);
            if (!$order) continue;

            if ($action === 'update_status') {
                $order->update(['status' => $validated['status']]);
                $updated++;
            } elseif ($action === 'cancel') {
                if ($order->status !== 'cancelled') {
                    $order->update(['status' => 'cancelled']);
                    
                    if ($request->boolean('refund', false)) {
                        $user = $order->user;
                        $oldBalance = $user->balance;
                        $user->increment('balance', $order->price);
                        
                        $user->transactions()->create([
                            'type' => 'credit',
                            'amount' => $order->price,
                            'currency' => 'USD',
                            'balance_before' => $oldBalance,
                            'balance_after' => $oldBalance + $order->price,
                            'description' => "Refund for order #{$order->id}",
                            'reference_type' => 'order',
                            'reference_id' => $order->id
                        ]);
                    }
                    $updated++;
                }
            } elseif ($action === 'delete') {
                $order->delete();
                $updated++;
            }
        }

        return back()->with('success', "Successfully processed {$updated} orders");
    }

    /**
     * Export orders
     */
    public function export(Request $request)
    {
        $query = Order::with(['user', 'service']);

        // Apply same filters as index
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('from')) {
            $query->whereDate('created_at', '>=', $request->from);
        }
        if ($request->filled('to')) {
            $query->whereDate('created_at', '<=', $request->to);
        }

        $orders = $query->get();

        $filename = 'orders_' . now()->format('Y-m-d_His') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function() use ($orders) {
            $file = fopen('php://output', 'w');
            
            // Headers
            fputcsv($file, [
                'Order ID', 'User', 'Service', 'Link', 'Quantity',
                'Price', 'Status', 'Created At', 'Completed At'
            ]);

            // Data
            foreach ($orders as $order) {
                fputcsv($file, [
                    $order->id,
                    $order->user->email,
                    $order->service->name,
                    $order->link,
                    $order->quantity,
                    $order->price,
                    $order->status,
                    $order->created_at,
                    $order->completed_at
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}

    /**
     * Export all orders to CSV
     */
    public function export(Request $request, \App\Services\ExportService $exportService)
    {
        $query = Order::with(['user', 'service']);

        // Apply filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $csv = $exportService->exportOrders($query);
        $filename = $exportService->getFilename('orders_admin');

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
    }
