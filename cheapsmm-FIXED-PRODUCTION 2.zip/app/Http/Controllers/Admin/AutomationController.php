<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Artisan, Cache};

class AutomationController extends Controller
{
    /**
     * Show automation dashboard
     */
    public function index()
    {
        $jobs = $this->getScheduledJobs();
        $logs = $this->getRecentLogs();

        return view('admin.automation.index', compact('jobs', 'logs'));
    }

    /**
     * Run a specific job manually
     */
    public function runJob(Request $request)
    {
        $jobName = $request->input('job');

        try {
            Artisan::call('schedule:run-all', ['--job' => $jobName]);
            
            return back()->with('success', "Job '{$jobName}' executed successfully!");
        } catch (\Exception $e) {
            return back()->withErrors(['error' => "Job failed: " . $e->getMessage()]);
        }
    }

    /**
     * Get scheduled jobs configuration
     */
    private function getScheduledJobs(): array
    {
        return [
            [
                'name' => 'Check Order Status',
                'job' => 'order-status',
                'schedule' => 'Every 5 minutes',
                'description' => 'Update order status from API providers',
                'last_run' => Cache::get('job_last_run:order-status'),
            ],
            [
                'name' => 'Process Dripfeed Orders',
                'job' => 'dripfeed',
                'schedule' => 'Every 10 minutes',
                'description' => 'Process dripfeed order batches',
                'last_run' => Cache::get('job_last_run:dripfeed'),
            ],
            [
                'name' => 'Update Exchange Rates',
                'job' => 'exchange-rates',
                'schedule' => 'Every 6 hours',
                'description' => 'Fetch latest currency exchange rates',
                'last_run' => Cache::get('job_last_run:exchange-rates'),
            ],
            [
                'name' => 'Low Balance Alerts',
                'job' => 'low-balance',
                'schedule' => 'Daily at 9:00 AM',
                'description' => 'Send alerts to users with low balance',
                'last_run' => Cache::get('job_last_run:low-balance'),
            ],
            [
                'name' => 'Daily Statistics',
                'job' => 'statistics',
                'schedule' => 'Daily at 12:30 AM',
                'description' => 'Generate daily performance statistics',
                'last_run' => Cache::get('job_last_run:statistics'),
            ],
            [
                'name' => 'Cleanup Inactive Users',
                'job' => 'cleanup',
                'schedule' => 'Weekly (Sunday 2:00 AM)',
                'description' => 'Remove unverified and inactive users',
                'last_run' => Cache::get('job_last_run:cleanup'),
            ],
        ];
    }

    /**
     * Get recent job logs
     */
    private function getRecentLogs(): array
    {
        // Mock implementation - integrate with actual logging
        return [
            [
                'job' => 'Check Order Status',
                'status' => 'success',
                'message' => 'Updated 15 orders',
                'executed_at' => now()->subMinutes(3)
            ],
            [
                'job' => 'Update Exchange Rates',
                'status' => 'success',
                'message' => 'Updated 10 currencies',
                'executed_at' => now()->subHours(2)
            ],
        ];
    }
}
