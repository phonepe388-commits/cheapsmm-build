<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\Category;
use App\Models\ApiProvider;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    /**
     * Display all services
     */
    public function index(Request $request)
    {
        $query = Service::with(['category', 'apiProvider']);

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('id', $request->search);
            });
        }

        // Filter by category
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by provider
        if ($request->filled('provider_id')) {
            $query->where('api_provider_id', $request->provider_id);
        }

        // Sort
        $sortBy = $request->input('sort_by', 'display_order');
        $sortDir = $request->input('sort_dir', 'asc');
        $query->orderBy($sortBy, $sortDir);

        $services = $query->paginate(50);

        // Get categories and providers for filters
        $categories = Category::where('status', 'active')->orderBy('name')->get();
        $providers = ApiProvider::where('status', 'active')->orderBy('name')->get();

        // Calculate stats
        $stats = [
            'total' => Service::count(),
            'active' => Service::where('status', 'active')->count(),
            'inactive' => Service::where('status', 'inactive')->count(),
            'total_orders' => \App\Models\Order::count(),
            'total_revenue' => \App\Models\Order::where('status', 'completed')->sum('price')
        ];

        return view('admin.services.index', compact('services', 'categories', 'providers', 'stats'));
    }

    /**
     * Show create service form
     */
    public function create()
    {
        $categories = Category::where('status', 'active')->orderBy('name')->get();
        $providers = ApiProvider::where('status', 'active')->orderBy('name')->get();
        
        return view('admin.services.create', compact('categories', 'providers'));
    }

    /**
     * Store new service
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'api_provider_id' => 'required|exists:api_providers,id',
            'provider_service_id' => 'required|string|max:255',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|in:default,custom_comments,mentions,package,poll',
            'price_per_1000' => 'required|numeric|min:0',
            'min_order' => 'required|integer|min:1',
            'max_order' => 'required|integer|min:1',
            'average_time' => 'nullable|string|max:100',
            'dripfeed_enabled' => 'boolean',
            'refill_enabled' => 'boolean',
            'cancel_enabled' => 'boolean',
            'status' => 'required|in:active,inactive',
            'display_order' => 'nullable|integer',
            'features' => 'nullable|array',
            'features.*' => 'string'
        ]);

        // Validate max > min
        if ($validated['max_order'] <= $validated['min_order']) {
            return back()->withErrors([
                'max_order' => 'Maximum order must be greater than minimum order'
            ])->withInput();
        }

        $service = Service::create([
            'category_id' => $validated['category_id'],
            'api_provider_id' => $validated['api_provider_id'],
            'provider_service_id' => $validated['provider_service_id'],
            'name' => $validated['name'],
            'description' => $validated['description'],
            'type' => $validated['type'],
            'price_per_1000' => $validated['price_per_1000'],
            'min_order' => $validated['min_order'],
            'max_order' => $validated['max_order'],
            'average_time' => $validated['average_time'],
            'dripfeed_enabled' => $request->boolean('dripfeed_enabled', false),
            'refill_enabled' => $request->boolean('refill_enabled', false),
            'cancel_enabled' => $request->boolean('cancel_enabled', false),
            'status' => $validated['status'],
            'display_order' => $validated['display_order'] ?? Service::max('display_order') + 1,
            'features' => $validated['features'] ?? []
        ]);

        // Log activity
        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'service_created',
            'description' => "Created service: {$service->name}",
            'ip_address' => $request->ip()
        ]);

        return redirect()
            ->route('admin.services.index')
            ->with('success', 'Service created successfully');
    }

    /**
     * Show service details
     */
    public function show(Service $service)
    {
        $service->load(['category', 'apiProvider', 'orders' => function($q) {
            $q->latest()->limit(50);
        }]);

        // Calculate service stats
        $stats = [
            'total_orders' => $service->orders()->count(),
            'pending_orders' => $service->orders()->where('status', 'pending')->count(),
            'completed_orders' => $service->orders()->where('status', 'completed')->count(),
            'total_revenue' => $service->orders()->where('status', 'completed')->sum('price'),
            'average_order_value' => $service->orders()->avg('price'),
            'today_orders' => $service->orders()->whereDate('created_at', today())->count()
        ];

        return view('admin.services.show', compact('service', 'stats'));
    }

    /**
     * Show edit service form
     */
    public function edit(Service $service)
    {
        $categories = Category::where('status', 'active')->orderBy('name')->get();
        $providers = ApiProvider::where('status', 'active')->orderBy('name')->get();
        
        return view('admin.services.edit', compact('service', 'categories', 'providers'));
    }

    /**
     * Update service
     */
    public function update(Request $request, Service $service)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'api_provider_id' => 'required|exists:api_providers,id',
            'provider_service_id' => 'required|string|max:255',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|in:default,custom_comments,mentions,package,poll',
            'price_per_1000' => 'required|numeric|min:0',
            'min_order' => 'required|integer|min:1',
            'max_order' => 'required|integer|min:1',
            'average_time' => 'nullable|string|max:100',
            'dripfeed_enabled' => 'boolean',
            'refill_enabled' => 'boolean',
            'cancel_enabled' => 'boolean',
            'status' => 'required|in:active,inactive',
            'display_order' => 'nullable|integer',
            'features' => 'nullable|array',
            'features.*' => 'string'
        ]);

        if ($validated['max_order'] <= $validated['min_order']) {
            return back()->withErrors([
                'max_order' => 'Maximum order must be greater than minimum order'
            ])->withInput();
        }

        $service->update([
            'category_id' => $validated['category_id'],
            'api_provider_id' => $validated['api_provider_id'],
            'provider_service_id' => $validated['provider_service_id'],
            'name' => $validated['name'],
            'description' => $validated['description'],
            'type' => $validated['type'],
            'price_per_1000' => $validated['price_per_1000'],
            'min_order' => $validated['min_order'],
            'max_order' => $validated['max_order'],
            'average_time' => $validated['average_time'],
            'dripfeed_enabled' => $request->boolean('dripfeed_enabled'),
            'refill_enabled' => $request->boolean('refill_enabled'),
            'cancel_enabled' => $request->boolean('cancel_enabled'),
            'status' => $validated['status'],
            'display_order' => $validated['display_order'],
            'features' => $validated['features'] ?? []
        ]);

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'service_updated',
            'description' => "Updated service: {$service->name}",
            'ip_address' => $request->ip()
        ]);

        return redirect()
            ->route('admin.services.show', $service)
            ->with('success', 'Service updated successfully');
    }

    /**
     * Delete service
     */
    public function destroy(Service $service)
    {
        // Check if service has orders
        if ($service->orders()->exists()) {
            return back()->withErrors([
                'error' => 'Cannot delete service with existing orders. Set status to inactive instead.'
            ]);
        }

        $name = $service->name;
        $service->delete();

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'service_deleted',
            'description' => "Deleted service: {$name}",
            'ip_address' => request()->ip()
        ]);

        return redirect()
            ->route('admin.services.index')
            ->with('success', 'Service deleted successfully');
    }

    /**
     * Bulk update services
     */
    public function bulkUpdate(Request $request)
    {
        $validated = $request->validate([
            'service_ids' => 'required|array',
            'service_ids.*' => 'exists:services,id',
            'action' => 'required|in:activate,deactivate,delete,update_price',
            'price_adjustment' => 'required_if:action,update_price|numeric',
            'price_type' => 'required_if:action,update_price|in:percentage,fixed'
        ]);

        $serviceIds = $validated['service_ids'];
        $updated = 0;

        foreach ($serviceIds as $serviceId) {
            $service = Service::find($serviceId);
            if (!$service) continue;

            switch ($validated['action']) {
                case 'activate':
                    $service->update(['status' => 'active']);
                    $updated++;
                    break;
                
                case 'deactivate':
                    $service->update(['status' => 'inactive']);
                    $updated++;
                    break;
                
                case 'delete':
                    if (!$service->orders()->exists()) {
                        $service->delete();
                        $updated++;
                    }
                    break;
                
                case 'update_price':
                    $oldPrice = $service->price_per_1000;
                    if ($validated['price_type'] === 'percentage') {
                        $newPrice = $oldPrice * (1 + ($validated['price_adjustment'] / 100));
                    } else {
                        $newPrice = $oldPrice + $validated['price_adjustment'];
                    }
                    $service->update(['price_per_1000' => max(0, $newPrice)]);
                    $updated++;
                    break;
            }
        }

        return back()->with('success', "Successfully processed {$updated} services");
    }

    /**
     * Sync services from provider
     */
    public function syncFromProvider(Request $request)
    {
        $validated = $request->validate([
            'provider_id' => 'required|exists:api_providers,id'
        ]);

        $provider = ApiProvider::findOrFail($validated['provider_id']);

        try {
            // Call provider API to get services
            $response = \Http::post($provider->api_url, [
                'key' => $provider->api_key,
                'action' => 'services'
            ]);

            if (!$response->successful()) {
                return back()->withErrors(['error' => 'Failed to fetch services from provider']);
            }

            $providerServices = $response->json();
            $imported = 0;
            $updated = 0;

            foreach ($providerServices as $providerService) {
                // Find or create service
                $service = Service::where('provider_service_id', $providerService['service'])
                    ->where('api_provider_id', $provider->id)
                    ->first();

                if ($service) {
                    // Update existing
                    $service->update([
                        'name' => $providerService['name'],
                        'price_per_1000' => $providerService['rate'],
                        'min_order' => $providerService['min'],
                        'max_order' => $providerService['max']
                    ]);
                    $updated++;
                } else {
                    // Create new
                    Service::create([
                        'category_id' => $request->input('default_category_id', 1),
                        'api_provider_id' => $provider->id,
                        'provider_service_id' => $providerService['service'],
                        'name' => $providerService['name'],
                        'type' => $providerService['type'] ?? 'default',
                        'price_per_1000' => $providerService['rate'],
                        'min_order' => $providerService['min'],
                        'max_order' => $providerService['max'],
                        'status' => 'inactive' // Set inactive by default for review
                    ]);
                    $imported++;
                }
            }

            return back()->with('success', "Synced successfully. Imported: {$imported}, Updated: {$updated}");

        } catch (\Exception $e) {
            \Log::error('Service sync failed', [
                'provider_id' => $provider->id,
                'error' => $e->getMessage()
            ]);

            return back()->withErrors(['error' => 'Sync failed: ' . $e->getMessage()]);
        }
    }
}
