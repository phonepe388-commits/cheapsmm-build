<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Webhook;
use App\Services\WebhookService;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    protected $webhookService;

    public function __construct(WebhookService $webhookService)
    {
        $this->webhookService = $webhookService;
    }

    public function index()
    {
        $webhooks = Webhook::latest()->get();
        $events = [
            'order.created', 'order.completed', 'order.failed',
            'payment.completed', 'user.registered', 'ticket.created'
        ];

        return view('admin.webhooks.index', compact('webhooks', 'events'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'required|url',
            'event' => 'required|string',
            'status' => 'required|in:active,inactive'
        ]);

        Webhook::create($validated);

        return back()->with('success', 'Webhook created!');
    }

    public function test(Webhook $webhook)
    {
        $result = $this->webhookService->test($webhook);

        if ($result['success']) {
            return back()->with('success', 'Webhook test successful!');
        } else {
            return back()->withErrors(['error' => 'Webhook test failed: ' . ($result['error'] ?? 'Unknown error')]);
        }
    }

    public function destroy(Webhook $webhook)
    {
        $webhook->delete();
        return back()->with('success', 'Webhook deleted!');
    }
}
