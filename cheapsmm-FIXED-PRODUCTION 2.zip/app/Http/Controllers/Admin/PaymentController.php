<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PaymentGateways\ManualPaymentService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected $manualService;

    public function __construct(ManualPaymentService $manualService)
    {
        $this->manualService = $manualService;
    }

    /**
     * Display all payments
     */
    public function index(Request $request)
    {
        $query = Payment::with(['user', 'paymentMethod']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('method')) {
            $query->where('payment_method_id', $request->method);
        }

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('transaction_id', 'like', "%{$request->search}%")
                  ->orWhereHas('user', function($uq) use ($request) {
                      $uq->where('name', 'like', "%{$request->search}%")
                         ->orWhere('email', 'like', "%{$request->search}%");
                  });
            });
        }

        $payments = $query->latest()->paginate(50);

        $stats = [
            'total_revenue' => Payment::where('status', 'completed')->sum('amount'),
            'pending_amount' => Payment::where('status', 'pending')->sum('amount'),
            'pending_count' => Payment::where('status', 'pending')->count(),
            'today_revenue' => Payment::where('status', 'completed')
                ->whereDate('paid_at', today())->sum('amount')
        ];

        return view('admin.payments.index', compact('payments', 'stats'));
    }

    /**
     * Show payment details
     */
    public function show(Payment $payment)
    {
        $payment->load(['user', 'paymentMethod', 'user.transactions' => function($q) use ($payment) {
            $q->where('reference_type', 'payment')
              ->where('reference_id', $payment->id);
        }]);

        return view('admin.payments.show', compact('payment'));
    }

    /**
     * Pending manual payments for review
     */
    public function pending()
    {
        $payments = $this->manualService->getPendingPayments();

        return view('admin.payments.pending', compact('payments'));
    }

    /**
     * Approve manual payment
     */
    public function approve(Request $request, Payment $payment)
    {
        $validated = $request->validate([
            'notes' => 'nullable|max:500'
        ]);

        try {
            $this->manualService->approvePayment(
                $payment,
                auth('admin')->id(),
                $validated['notes'] ?? null
            );

            return redirect()->route('admin.payments.pending')
                ->with('success', "Payment approved successfully. User's balance has been updated.");
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Reject manual payment
     */
    public function reject(Request $request, Payment $payment)
    {
        $validated = $request->validate([
            'reason' => 'required|max:500'
        ]);

        try {
            $this->manualService->rejectPayment(
                $payment,
                auth('admin')->id(),
                $validated['reason']
            );

            return redirect()->route('admin.payments.pending')
                ->with('success', 'Payment rejected. User has been notified.');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Refund payment
     */
    public function refund(Request $request, Payment $payment)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:0.01|max:' . $payment->amount,
            'reason' => 'required|max:500'
        ]);

        try {
            // Process refund based on payment method
            // Implementation would call respective gateway's refund method

            return back()->with('success', 'Refund processed successfully');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}

    /**
     * Export all payments to CSV
     */
    public function export(Request $request, \App\Services\ExportService $exportService)
    {
        $query = Payment::with(['user', 'paymentMethod']);

        // Apply filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('method')) {
            $query->where('payment_method_id', $request->method);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $csv = $exportService->exportPayments($query);
        $filename = $exportService->getFilename('payments');

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
    }
