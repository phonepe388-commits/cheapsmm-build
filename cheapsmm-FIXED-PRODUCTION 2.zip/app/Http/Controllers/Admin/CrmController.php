<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{User, CustomerSegment, CustomerTag, Campaign};
use App\Services\CRMService;
use Illuminate\Http\Request;

class CrmController extends Controller
{
    protected $crmService;

    public function __construct(CRMService $crmService)
    {
        $this->crmService = $crmService;
    }

    /**
     * CRM Dashboard
     */
    public function index()
    {
        $stats = [
            'total_customers' => User::count(),
            'active_customers' => User::where('status', 'active')->count(),
            'high_value_customers' => User::whereHas('orders', function($q) {
                $q->havingRaw('SUM(charge) > 1000');
            })->count(),
            'segments' => CustomerSegment::count(),
            'tags' => CustomerTag::count()
        ];

        $recentCustomers = User::with('orders')->latest()->limit(10)->get();
        $topCustomers = User::withSum('orders', 'charge')
            ->orderByDesc('orders_sum_charge')
            ->limit(10)
            ->get();

        return view('admin.crm.index', compact('stats', 'recentCustomers', 'topCustomers'));
    }

    /**
     * Customer segments
     */
    public function segments()
    {
        $segments = CustomerSegment::withCount('users')->get();
        return view('admin.crm.segments', compact('segments'));
    }

    /**
     * Create segment
     */
    public function createSegment(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'spending_min' => 'nullable|numeric',
            'last_order_days' => 'nullable|integer',
            'min_orders' => 'nullable|integer',
            'status' => 'nullable|string'
        ]);

        $criteria = array_filter($validated, fn($v, $k) => $k !== 'name', ARRAY_FILTER_USE_BOTH);
        
        $segment = $this->crmService->createSegment($validated['name'], $criteria);

        return back()->with('success', 'Segment created with ' . $segment->user_count . ' users!');
    }

    /**
     * Customer tags
     */
    public function tags()
    {
        $tags = CustomerTag::withCount('users')->get();
        return view('admin.crm.tags', compact('tags'));
    }

    /**
     * Tag user
     */
    public function tagUser(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'tag_name' => 'required|string|max:50'
        ]);

        $user = User::findOrFail($validated['user_id']);
        $this->crmService->tagUser($user, $validated['tag_name']);

        return back()->with('success', 'User tagged successfully!');
    }

    /**
     * View customer insights
     */
    public function customerInsights(User $user)
    {
        $insights = $this->crmService->getCustomerInsights($user);
        $orders = $user->orders()->with('service')->latest()->paginate(20);

        return view('admin.crm.customer-insights', compact('user', 'insights', 'orders'));
    }

    /**
     * Campaigns list
     */
    public function campaigns()
    {
        $campaigns = Campaign::with('segment')->latest()->get();
        $segments = CustomerSegment::all();

        return view('admin.crm.campaigns', compact('campaigns', 'segments'));
    }

    /**
     * Create campaign
     */
    public function createCampaign(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
            'segment_id' => 'required|exists:customer_segments,id'
        ]);

        $campaign = Campaign::create($validated);

        return redirect()->route('admin.crm.campaigns')
            ->with('success', 'Campaign created! Ready to send.');
    }

    /**
     * Send campaign
     */
    public function sendCampaign(Campaign $campaign)
    {
        $sent = $this->crmService->sendCampaign($campaign, $campaign->segment);

        return back()->with('success', "Campaign sent to {$sent} customers!");
    }
}
