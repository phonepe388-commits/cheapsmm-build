<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::withCount('services')
            ->orderBy('display_order')
            ->paginate(50);

        $stats = [
            'total' => Category::count(),
            'active' => Category::where('status', 'active')->count(),
            'inactive' => Category::where('status', 'inactive')->count()
        ];

        return view('admin.categories.index', compact('categories', 'stats'));
    }

    public function create()
    {
        $parentCategories = Category::whereNull('parent_id')
            ->where('status', 'active')
            ->orderBy('name')
            ->get();
        
        return view('admin.categories.create', compact('parentCategories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:categories,name',
            'slug' => 'nullable|string|max:255|unique:categories,slug',
            'description' => 'nullable|string',
            'parent_id' => 'nullable|exists:categories,id',
            'icon' => 'nullable|string|max:100',
            'status' => 'required|in:active,inactive',
            'display_order' => 'nullable|integer'
        ]);

        $validated['slug'] = $validated['slug'] ?? \Str::slug($validated['name']);
        $validated['display_order'] = $validated['display_order'] ?? Category::max('display_order') + 1;

        $category = Category::create($validated);

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'category_created',
            'description' => "Created category: {$category->name}",
            'ip_address' => $request->ip()
        ]);

        return redirect()->route('admin.categories.index')->with('success', 'Category created successfully');
    }

    public function edit(Category $category)
    {
        $parentCategories = Category::whereNull('parent_id')
            ->where('id', '!=', $category->id)
            ->where('status', 'active')
            ->orderBy('name')
            ->get();
        
        return view('admin.categories.edit', compact('category', 'parentCategories'));
    }

    public function update(Request $request, Category $category)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:categories,name,' . $category->id,
            'slug' => 'nullable|string|max:255|unique:categories,slug,' . $category->id,
            'description' => 'nullable|string',
            'parent_id' => 'nullable|exists:categories,id',
            'icon' => 'nullable|string|max:100',
            'status' => 'required|in:active,inactive',
            'display_order' => 'nullable|integer'
        ]);

        $validated['slug'] = $validated['slug'] ?? \Str::slug($validated['name']);

        $category->update($validated);

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'category_updated',
            'description' => "Updated category: {$category->name}",
            'ip_address' => $request->ip()
        ]);

        return redirect()->route('admin.categories.index')->with('success', 'Category updated successfully');
    }

    public function destroy(Category $category)
    {
        if ($category->services()->exists()) {
            return back()->withErrors(['error' => 'Cannot delete category with services']);
        }

        if ($category->children()->exists()) {
            return back()->withErrors(['error' => 'Cannot delete category with sub-categories']);
        }

        $name = $category->name;
        $category->delete();

        \App\Models\ActivityLog::create([
            'user_id' => auth()->guard('admin')->id(),
            'action' => 'category_deleted',
            'description' => "Deleted category: {$name}",
            'ip_address' => request()->ip()
        ]);

        return redirect()->route('admin.categories.index')->with('success', 'Category deleted successfully');
    }

    public function reorder(Request $request)
    {
        $validated = $request->validate([
            'categories' => 'required|array',
            'categories.*.id' => 'required|exists:categories,id',
            'categories.*.order' => 'required|integer'
        ]);

        foreach ($validated['categories'] as $item) {
            Category::where('id', $item['id'])->update(['display_order' => $item['order']]);
        }

        return response()->json(['success' => true, 'message' => 'Order updated successfully']);
    }
}
