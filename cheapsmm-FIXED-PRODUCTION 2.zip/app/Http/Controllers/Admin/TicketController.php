<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\TicketMessage;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        $query = Ticket::with(['user', 'messages']);

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('id', $request->search)
                  ->orWhere('subject', 'like', "%{$request->search}%")
                  ->orWhereHas('user', function($q) use ($request) {
                      $q->where('email', 'like', "%{$request->search}%");
                  });
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }

        if ($request->filled('assigned_to')) {
            $query->where('assigned_to', $request->assigned_to);
        }

        $tickets = $query->latest()->paginate(50);

        $stats = [
            'total' => Ticket::count(),
            'open' => Ticket::where('status', 'open')->count(),
            'waiting' => Ticket::where('status', 'waiting_reply')->count(),
            'answered' => Ticket::where('status', 'answered')->count(),
            'closed' => Ticket::where('status', 'closed')->count()
        ];

        $admins = Admin::where('status', 'active')->get();

        return view('admin.tickets.index', compact('tickets', 'stats', 'admins'));
    }

    public function show(Ticket $ticket)
    {
        $ticket->load(['user', 'messages.user', 'messages.admin', 'assignedAdmin']);
        $admins = Admin::where('status', 'active')->get();
        
        return view('admin.tickets.show', compact('ticket', 'admins'));
    }

    public function reply(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'message' => 'required|string',
            'attachments.*' => 'nullable|file|max:5120'
        ]);

        $attachmentPaths = [];
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('ticket-attachments', 'public');
                $attachmentPaths[] = [
                    'name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'size' => $file->getSize()
                ];
            }
        }

        $ticket->messages()->create([
            'admin_id' => auth()->guard('admin')->id(),
            'message' => $validated['message'],
            'attachments' => $attachmentPaths,
            'is_admin' => true
        ]);

        $ticket->update([
            'status' => 'answered',
            'last_reply_at' => now()
        ]);

        $ticket->user->notifications()->create([
            'type' => 'ticket_reply',
            'title' => 'Ticket Reply',
            'message' => "Admin replied to your ticket #{$ticket->id}",
            'data' => ['ticket_id' => $ticket->id]
        ]);

        return back()->with('success', 'Reply sent successfully');
    }

    public function assign(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'admin_id' => 'required|exists:admins,id'
        ]);

        $ticket->update(['assigned_to' => $validated['admin_id']]);

        return back()->with('success', 'Ticket assigned successfully');
    }

    public function updateStatus(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'status' => 'required|in:open,waiting_reply,answered,closed'
        ]);

        $ticket->update(['status' => $validated['status']]);

        if ($validated['status'] === 'closed') {
            $ticket->update([
                'closed_at' => now(),
                'closed_by' => auth()->guard('admin')->id()
            ]);
        }

        return back()->with('success', 'Ticket status updated');
    }

    public function updatePriority(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'priority' => 'required|in:low,medium,high'
        ]);

        $ticket->update(['priority' => $validated['priority']]);

        return back()->with('success', 'Priority updated');
    }

    public function close(Ticket $ticket)
    {
        $ticket->update([
            'status' => 'closed',
            'closed_at' => now(),
            'closed_by' => auth()->guard('admin')->id()
        ]);

        $ticket->user->notifications()->create([
            'type' => 'ticket_closed',
            'title' => 'Ticket Closed',
            'message' => "Your ticket #{$ticket->id} has been closed",
            'data' => ['ticket_id' => $ticket->id]
        ]);

        return back()->with('success', 'Ticket closed');
    }

    public function destroy(Ticket $ticket)
    {
        $ticket->messages()->each(function($message) {
            if ($message->attachments) {
                foreach ($message->attachments as $attachment) {
                    Storage::disk('public')->delete($attachment['path']);
                }
            }
        });

        $ticket->delete();

        return redirect()->route('admin.tickets.index')->with('success', 'Ticket deleted');
    }
}
