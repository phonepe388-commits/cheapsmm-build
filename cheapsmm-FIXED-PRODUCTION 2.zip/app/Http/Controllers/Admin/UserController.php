<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserTier;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $users = $query->latest()->paginate(50);

        $stats = [
            'total' => User::count(),
            'active' => User::where('status', 'active')->count(),
            'suspended' => User::where('status', 'suspended')->count(),
            'banned' => User::where('status', 'banned')->count()
        ];

        return view('admin.users.index', compact('users', 'stats'));
    }

    public function show(User $user)
    {
        $user->load(['orders' => fn($q) => $q->latest()->limit(10)]);
        
        $stats = [
            'total_orders' => $user->orders()->count(),
            'total_spent' => $user->transactions()->where('type', 'debit')->sum('amount'),
            'current_balance' => $user->balance
        ];

        return view('admin.users.show', compact('user', 'stats'));
    }

    public function edit(User $user)
    {
        $tiers = UserTier::all();
        return view('admin.users.edit', compact('user', 'tiers'));
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'status' => 'required|in:active,suspended,banned',
            'balance' => 'nullable|numeric|min:0'
        ]);

        $user->update($validated);

        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'admin_id' => auth('admin')->id(),
            'action' => 'user_updated',
            'ip_address' => $request->ip()
        ]);

        return redirect()->route('admin.users.show', $user)->with('success', 'User updated');
    }

    public function suspend(Request $request, User $user)
    {
        $validated = $request->validate(['reason' => 'required|max:500']);

        $user->update([
            'status' => 'suspended',
            'suspended_at' => now(),
            'suspension_reason' => $validated['reason']
        ]);

        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'admin_id' => auth('admin')->id(),
            'action' => 'user_suspended',
            'description' => $validated['reason']
        ]);

        $user->notifications()->create([
            'type' => 'account_suspended',
            'title' => 'Account Suspended',
            'message' => "Your account has been suspended. Reason: {$validated['reason']}"
        ]);

        return back()->with('success', 'User suspended');
    }

    public function unsuspend(User $user)
    {
        $user->update([
            'status' => 'active',
            'suspended_at' => null,
            'suspension_reason' => null
        ]);

        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'admin_id' => auth('admin')->id(),
            'action' => 'user_unsuspended'
        ]);

        return back()->with('success', 'User unsuspended');
    }

    public function ban(Request $request, User $user)
    {
        $validated = $request->validate(['reason' => 'required|max:500']);

        $user->update([
            'status' => 'banned',
            'banned_at' => now(),
            'ban_reason' => $validated['reason']
        ]);

        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'admin_id' => auth('admin')->id(),
            'action' => 'user_banned',
            'description' => $validated['reason']
        ]);

        return back()->with('success', 'User banned');
    }

    public function adjustBalance(Request $request, User $user)
    {
        $validated = $request->validate([
            'type' => 'required|in:add,subtract,set',
            'amount' => 'required|numeric|min:0',
            'reason' => 'required|max:500'
        ]);

        $oldBalance = $user->balance;

        $newBalance = match($validated['type']) {
            'add' => $oldBalance + $validated['amount'],
            'subtract' => max(0, $oldBalance - $validated['amount']),
            'set' => $validated['amount']
        };

        $user->update(['balance' => $newBalance]);

        $user->transactions()->create([
            'type' => $newBalance > $oldBalance ? 'credit' : 'debit',
            'amount' => abs($newBalance - $oldBalance),
            'balance_before' => $oldBalance,
            'balance_after' => $newBalance,
            'description' => "Admin adjustment: {$validated['reason']}"
        ]);

        return back()->with('success', 'Balance adjusted');
    }

    public function loginAs(User $user)
    {
        session(['impersonate_admin_id' => auth('admin')->id()]);
        auth()->login($user);
        
        return redirect()->route('user.dashboard');
    }
}

    /**
     * Export all users to CSV
     */
    public function export(Request $request, \App\Services\ExportService $exportService)
    {
        $query = User::query();

        // Apply filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $csv = $exportService->exportUsers($query);
        $filename = $exportService->getFilename('users');

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
    }
