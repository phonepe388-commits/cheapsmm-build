<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ExportService;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    protected $exportService;

    public function __construct(ExportService $exportService)
    {
        $this->exportService = $exportService;
    }

    /**
     * Show reports page
     */
    public function index()
    {
        return view('admin.reports.index');
    }

    /**
     * Generate summary report
     */
    public function summary(Request $request)
    {
        $filters = [
            'date_from' => $request->input('date_from', now()->subMonth()),
            'date_to' => $request->input('date_to', now())
        ];

        $report = $this->exportService->generateSummaryReport($filters);

        if ($request->get('export') === 'csv') {
            $csv = $this->exportService->exportSummaryReport($report);
            $filename = $this->exportService->getFilename('summary_report');

            return response($csv)
                ->header('Content-Type', 'text/csv')
                ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
        }

        return view('admin.reports.summary', compact('report', 'filters'));
    }
}
