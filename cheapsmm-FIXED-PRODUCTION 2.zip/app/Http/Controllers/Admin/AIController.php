<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\AIService;
use App\Models\User;

class AIController extends Controller
{
    protected $aiService;

    public function __construct(AIService $aiService)
    {
        $this->aiService = $aiService;
    }

    public function dashboard()
    {
        // Get users at risk
        $usersAtRisk = User::take(100)->get()->map(function($user) {
            $risk = $this->aiService->calculateChurnRisk($user);
            return [
                'user' => $user,
                'risk' => $risk
            ];
        })->filter(fn($item) => $item['risk']['risk'] !== 'low')
          ->sortByDesc('risk.score')
          ->take(20);

        // Get suspicious activities
        $suspiciousUsers = User::whereHas('orders', function($q) {
            $q->where('created_at', '>', now()->subDay());
        })->take(50)->get()->map(function($user) {
            return [
                'user' => $user,
                'flags' => $this->aiService->detectSuspiciousActivity($user)
            ];
        })->filter(fn($item) => count($item['flags']) > 0);

        return view('admin.ai.dashboard', compact('usersAtRisk', 'suspiciousUsers'));
    }
}
