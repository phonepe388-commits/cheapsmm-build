<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{Blog, Page, FAQ};
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    // Blog Posts
    public function index()
    {
        $posts = Blog::latest()->paginate(20);
        return view('admin.blog.index', compact('posts'));
    }

    public function create()
    {
        return view('admin.blog.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'excerpt' => 'nullable|string',
            'featured_image' => 'nullable|string',
            'status' => 'required|in:draft,published'
        ]);

        $validated['slug'] = Str::slug($validated['title']);
        $validated['author_id'] = auth()->id();

        Blog::create($validated);

        return redirect()->route('admin.blog.index')->with('success', 'Post created!');
    }

    public function edit(Blog $blog)
    {
        return view('admin.blog.edit', compact('blog'));
    }

    public function update(Request $request, Blog $blog)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'excerpt' => 'nullable|string',
            'featured_image' => 'nullable|string',
            'status' => 'required|in:draft,published'
        ]);

        $validated['slug'] = Str::slug($validated['title']);
        $blog->update($validated);

        return back()->with('success', 'Post updated!');
    }

    public function destroy(Blog $blog)
    {
        $blog->delete();
        return redirect()->route('admin.blog.index')->with('success', 'Post deleted!');
    }

    // Pages
    public function pages()
    {
        $pages = Page::latest()->get();
        return view('admin.blog.pages', compact('pages'));
    }

    public function createPage()
    {
        return view('admin.blog.create-page');
    }

    public function storePage(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'status' => 'required|in:draft,published'
        ]);

        $validated['slug'] = Str::slug($validated['title']);
        Page::create($validated);

        return redirect()->route('admin.blog.pages')->with('success', 'Page created!');
    }

    // FAQs
    public function faqs()
    {
        $faqs = FAQ::orderBy('order')->get();
        return view('admin.blog.faqs', compact('faqs'));
    }

    public function storeFAQ(Request $request)
    {
        $validated = $request->validate([
            'question' => 'required|string',
            'answer' => 'required|string',
            'category' => 'nullable|string',
            'order' => 'nullable|integer'
        ]);

        FAQ::create($validated);

        return back()->with('success', 'FAQ added!');
    }
}
