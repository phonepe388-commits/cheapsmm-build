<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Backup;
use App\Services\BackupService;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    protected $backupService;

    public function __construct(BackupService $backupService)
    {
        $this->backupService = $backupService;
    }

    public function index()
    {
        $backups = Backup::latest()->paginate(20);
        return view('admin.backups.index', compact('backups'));
    }

    public function createDatabaseBackup()
    {
        try {
            $backup = $this->backupService->createDatabaseBackup();
            return back()->with('success', 'Database backup created: ' . $backup->filename);
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function createFilesBackup()
    {
        try {
            $backup = $this->backupService->createFilesBackup();
            return back()->with('success', 'Files backup created: ' . $backup->filename);
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function download(Backup $backup)
    {
        if (!file_exists($backup->path)) {
            return back()->withErrors(['error' => 'Backup file not found']);
        }

        return response()->download($backup->path);
    }

    public function restore(Backup $backup)
    {
        try {
            $result = $this->backupService->restoreDatabase($backup);
            
            if ($result) {
                return back()->with('success', 'Database restored successfully!');
            } else {
                return back()->withErrors(['error' => 'Restore failed']);
            }
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function destroy(Backup $backup)
    {
        if (file_exists($backup->path)) {
            unlink($backup->path);
        }
        $backup->delete();

        return back()->with('success', 'Backup deleted');
    }
}
