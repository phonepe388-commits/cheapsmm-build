<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\{App, Session};

class LanguageController extends Controller
{
    /**
     * Supported languages with metadata
     */
    private $languages = [
        'en' => ['name' => 'English', 'native' => 'English', 'flag' => '🇬🇧'],
        'es' => ['name' => 'Spanish', 'native' => 'Español', 'flag' => '🇪🇸'],
        'fr' => ['name' => 'French', 'native' => 'Français', 'flag' => '🇫🇷'],
        'de' => ['name' => 'German', 'native' => 'Deutsch', 'flag' => '🇩🇪'],
        'pt' => ['name' => 'Portuguese', 'native' => 'Português', 'flag' => '🇵🇹'],
        'ar' => ['name' => 'Arabic', 'native' => 'العربية', 'flag' => '🇸🇦'],
        'hi' => ['name' => 'Hindi', 'native' => 'हिन्दी', 'flag' => '🇮🇳'],
        'zh' => ['name' => 'Chinese', 'native' => '中文', 'flag' => '🇨🇳'],
        'ja' => ['name' => 'Japanese', 'native' => '日本語', 'flag' => '🇯🇵'],
        'ru' => ['name' => 'Russian', 'native' => 'Русский', 'flag' => '🇷🇺'],
    ];

    /**
     * Switch language
     */
    public function switch(Request $request)
    {
        $locale = $request->input('locale', 'en');

        if (!array_key_exists($locale, $this->languages)) {
            return back()->withErrors(['error' => 'Invalid language']);
        }

        // Set locale
        App::setLocale($locale);
        Session::put('locale', $locale);

        // Update user preference if authenticated
        if (auth()->check()) {
            auth()->user()->update(['language' => $locale]);
        }

        return back()->with('success', __('app.language_changed'));
    }

    /**
     * Get available languages (API)
     */
    public function index()
    {
        return response()->json([
            'current' => App::getLocale(),
            'languages' => $this->languages
        ]);
    }
}
