<?php

namespace App\Http\Controllers;

use App\Services\CurrencyService;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    protected $currencyService;

    public function __construct(CurrencyService $currencyService)
    {
        $this->currencyService = $currencyService;
    }

    /**
     * Switch currency
     */
    public function switch(Request $request)
    {
        $validated = $request->validate([
            'currency' => 'required|string|size:3'
        ]);

        if ($this->currencyService->setCurrency($validated['currency'])) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'currency' => $validated['currency']
                ]);
            }

            return redirect()->back()->with('success', 'Currency updated successfully');
        }

        if ($request->ajax()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid currency'
            ], 400);
        }

        return redirect()->back()->withErrors(['currency' => 'Invalid currency']);
    }

    /**
     * Get active currencies (API)
     */
    public function index()
    {
        return response()->json([
            'currencies' => $this->currencyService->getActiveCurrencies(),
            'current' => $this->currencyService->getCurrentCurrency()
        ]);
    }
}
