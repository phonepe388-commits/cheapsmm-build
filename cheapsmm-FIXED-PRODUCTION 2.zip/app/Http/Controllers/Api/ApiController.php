<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\{ServiceResource, OrderResource};
use App\Models\{Service, Order, Category};
use App\Services\OrderService;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    /**
     * Get user balance
     * GET /api/v2/balance
     */
    public function balance(Request $request)
    {
        $user = $request->user();

        return response()->json([
            'balance' => number_format($user->balance, 2),
            'currency' => 'USD'
        ]);
    }

    /**
     * Get all services
     * GET /api/v2/services
     */
    public function services(Request $request)
    {
        $services = Service::where('status', 'active')
            ->with('category')
            ->get();

        return ServiceResource::collection($services);
    }

    /**
     * Add new order
     * POST /api/v2/add
     * Params: service, link, quantity, runs (optional), interval (optional)
     */
    public function add(Request $request)
    {
        $validated = $request->validate([
            'service' => 'required|exists:services,id',
            'link' => 'required|url',
            'quantity' => 'required|integer|min:1',
            'runs' => 'nullable|integer|min:2',
            'interval' => 'nullable|integer|min:1'
        ]);

        try {
            $user = $request->user();
            $service = Service::findOrFail($validated['service']);

            // Check quantity limits
            if ($validated['quantity'] < $service->min_quantity) {
                return response()->json([
                    'error' => "Quantity below minimum ({$service->min_quantity})",
                    'code' => 'MIN_QUANTITY'
                ], 400);
            }

            if ($validated['quantity'] > $service->max_quantity) {
                return response()->json([
                    'error' => "Quantity exceeds maximum ({$service->max_quantity})",
                    'code' => 'MAX_QUANTITY'
                ], 400);
            }

            // Calculate charge
            $charge = ($service->price_per_1000 * $validated['quantity']) / 1000;

            // Check balance
            if ($user->balance < $charge) {
                return response()->json([
                    'error' => 'Insufficient balance',
                    'code' => 'INSUFFICIENT_BALANCE'
                ], 400);
            }

            // Create order
            $orderData = [
                'service_id' => $service->id,
                'link' => $validated['link'],
                'quantity' => $validated['quantity']
            ];

            // Dripfeed support
            if (isset($validated['runs']) && isset($validated['interval']) && $service->dripfeed_enabled) {
                $orderData['is_dripfeed'] = true;
                $orderData['runs'] = $validated['runs'];
                $orderData['interval'] = $validated['interval'];
            }

            $order = $this->orderService->createOrder($user, $orderData);

            return response()->json([
                'order' => $order->id
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'code' => 'ORDER_FAILED'
            ], 400);
        }
    }

    /**
     * Get order status
     * POST /api/v2/status
     * Params: order or orders (comma-separated)
     */
    public function status(Request $request)
    {
        $request->validate([
            'order' => 'required_without:orders',
            'orders' => 'required_without:order'
        ]);

        $user = $request->user();

        // Single order
        if ($request->has('order')) {
            $order = Order::where('id', $request->order)
                ->where('user_id', $user->id)
                ->first();

            if (!$order) {
                return response()->json([
                    'error' => 'Order not found',
                    'code' => 'ORDER_NOT_FOUND'
                ], 404);
            }

            return new OrderResource($order);
        }

        // Multiple orders
        $orderIds = explode(',', $request->orders);
        $orders = Order::whereIn('id', $orderIds)
            ->where('user_id', $user->id)
            ->get()
            ->keyBy('id');

        $result = [];
        foreach ($orderIds as $orderId) {
            if (isset($orders[$orderId])) {
                $result[$orderId] = (new OrderResource($orders[$orderId]))->toArray($request);
            } else {
                $result[$orderId] = [
                    'error' => 'Order not found',
                    'code' => 'ORDER_NOT_FOUND'
                ];
            }
        }

        return response()->json($result);
    }

    /**
     * Create multiple orders
     * POST /api/v2/add-multi
     * Params: orders (array of service/link/quantity)
     */
    public function addMulti(Request $request)
    {
        $validated = $request->validate([
            'orders' => 'required|array|min:1|max:100',
            'orders.*.service' => 'required|exists:services,id',
            'orders.*.link' => 'required|url',
            'orders.*.quantity' => 'required|integer|min:1'
        ]);

        $user = $request->user();
        $created = [];
        $errors = [];

        foreach ($validated['orders'] as $index => $orderData) {
            try {
                $service = Service::findOrFail($orderData['service']);

                // Validate quantity
                if ($orderData['quantity'] < $service->min_quantity || 
                    $orderData['quantity'] > $service->max_quantity) {
                    $errors[$index] = 'Invalid quantity';
                    continue;
                }

                // Calculate charge
                $charge = ($service->price_per_1000 * $orderData['quantity']) / 1000;

                // Check balance
                if ($user->balance < $charge) {
                    $errors[$index] = 'Insufficient balance';
                    continue;
                }

                // Create order
                $order = $this->orderService->createOrder($user, [
                    'service_id' => $service->id,
                    'link' => $orderData['link'],
                    'quantity' => $orderData['quantity']
                ]);

                $created[$index] = $order->id;

            } catch (\Exception $e) {
                $errors[$index] = $e->getMessage();
            }
        }

        return response()->json([
            'created' => $created,
            'errors' => $errors,
            'success_count' => count($created),
            'error_count' => count($errors)
        ]);
    }

    /**
     * Refill order
     * POST /api/v2/refill
     * Params: order
     */
    public function refill(Request $request)
    {
        $validated = $request->validate([
            'order' => 'required|exists:orders,id'
        ]);

        $user = $request->user();
        $order = Order::where('id', $validated['order'])
            ->where('user_id', $user->id)
            ->first();

        if (!$order) {
            return response()->json([
                'error' => 'Order not found',
                'code' => 'ORDER_NOT_FOUND'
            ], 404);
        }

        if (!$order->service->refill_enabled) {
            return response()->json([
                'error' => 'Refill not available for this service',
                'code' => 'REFILL_DISABLED'
            ], 400);
        }

        try {
            $refill = $this->orderService->requestRefill($order);

            return response()->json([
                'refill' => $refill->id
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'code' => 'REFILL_FAILED'
            ], 400);
        }
    }

    /**
     * Get refill status
     * POST /api/v2/refill-status
     * Params: refill
     */
    public function refillStatus(Request $request)
    {
        $validated = $request->validate([
            'refill' => 'required|exists:refills,id'
        ]);

        $refill = \App\Models\Refill::findOrFail($validated['refill']);

        return response()->json([
            'status' => $refill->status
        ]);
    }

    /**
     * Cancel order
     * POST /api/v2/cancel
     * Params: orders (comma-separated)
     */
    public function cancel(Request $request)
    {
        $validated = $request->validate([
            'orders' => 'required|string'
        ]);

        $user = $request->user();
        $orderIds = explode(',', $validated['orders']);
        
        $cancelled = [];
        $errors = [];

        foreach ($orderIds as $orderId) {
            try {
                $order = Order::where('id', $orderId)
                    ->where('user_id', $user->id)
                    ->first();

                if (!$order) {
                    $errors[$orderId] = 'Order not found';
                    continue;
                }

                if (!$order->service->cancel_enabled) {
                    $errors[$orderId] = 'Cancel not available';
                    continue;
                }

                $this->orderService->cancelOrder($order);
                $cancelled[] = $orderId;

            } catch (\Exception $e) {
                $errors[$orderId] = $e->getMessage();
            }
        }

        return response()->json([
            'cancelled' => $cancelled,
            'errors' => $errors
        ]);
    }

    /**
     * Get user orders
     * GET /api/v2/orders
     */
    public function orders(Request $request)
    {
        $user = $request->user();
        
        $query = $user->orders()->with('service');

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        if ($request->has('limit')) {
            $query->limit($request->limit);
        }

        $orders = $query->latest()->get();

        return OrderResource::collection($orders);
    }
}
