<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    /**
     * Display all notifications
     */
    public function index(Request $request)
    {
        $query = auth()->user()->notifications();

        // Filter by type
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        // Filter by read status
        if ($request->filled('status')) {
            if ($request->status === 'unread') {
                $query->whereNull('read_at');
            } elseif ($request->status === 'read') {
                $query->whereNotNull('read_at');
            }
        }

        // Filter by date range
        if ($request->filled('from')) {
            $query->whereDate('created_at', '>=', $request->from);
        }
        if ($request->filled('to')) {
            $query->whereDate('created_at', '<=', $request->to);
        }

        $notifications = $query->latest()->paginate(20);

        // Get notification types for filter
        $types = auth()->user()->notifications()
            ->select('type')
            ->distinct()
            ->pluck('type');

        // Calculate stats
        $stats = [
            'total' => auth()->user()->notifications()->count(),
            'unread' => auth()->user()->notifications()->whereNull('read_at')->count(),
            'read' => auth()->user()->notifications()->whereNotNull('read_at')->count(),
            'today' => auth()->user()->notifications()->whereDate('created_at', today())->count()
        ];

        return view('user.notifications.index', compact('notifications', 'types', 'stats'));
    }

    /**
     * Show single notification
     */
    public function show(Notification $notification)
    {
        // Authorization check
        if ($notification->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        // Mark as read
        if (!$notification->read_at) {
            $notification->update(['read_at' => now()]);
        }

        return view('user.notifications.show', compact('notification'));
    }

    /**
     * Mark notification as read
     */
    public function markAsRead(Notification $notification)
    {
        // Authorization check
        if ($notification->user_id !== auth()->id()) {
            abort(403);
        }

        $notification->update(['read_at' => now()]);

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Notification marked as read'
            ]);
        }

        return back()->with('success', 'Notification marked as read');
    }

    /**
     * Mark notification as unread
     */
    public function markAsUnread(Notification $notification)
    {
        // Authorization check
        if ($notification->user_id !== auth()->id()) {
            abort(403);
        }

        $notification->update(['read_at' => null]);

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Notification marked as unread'
            ]);
        }

        return back()->with('success', 'Notification marked as unread');
    }

    /**
     * Mark all notifications as read
     */
    public function markAllAsRead()
    {
        $updated = auth()->user()->notifications()
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => "Marked {$updated} notifications as read",
                'count' => $updated
            ]);
        }

        return back()->with('success', "Marked {$updated} notifications as read");
    }

    /**
     * Delete notification
     */
    public function destroy(Notification $notification)
    {
        // Authorization check
        if ($notification->user_id !== auth()->id()) {
            abort(403);
        }

        $notification->delete();

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Notification deleted'
            ]);
        }

        return back()->with('success', 'Notification deleted');
    }

    /**
     * Delete all read notifications
     */
    public function deleteAllRead()
    {
        $deleted = auth()->user()->notifications()
            ->whereNotNull('read_at')
            ->delete();

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => "Deleted {$deleted} notifications",
                'count' => $deleted
            ]);
        }

        return back()->with('success', "Deleted {$deleted} notifications");
    }

    /**
     * Get unread notification count (AJAX)
     */
    public function unreadCount()
    {
        $count = auth()->user()->notifications()
            ->whereNull('read_at')
            ->count();

        return response()->json([
            'count' => $count
        ]);
    }

    /**
     * Get recent notifications (AJAX)
     */
    public function recent()
    {
        $notifications = auth()->user()->notifications()
            ->latest()
            ->limit(10)
            ->get();

        return response()->json([
            'notifications' => $notifications,
            'unread_count' => auth()->user()->notifications()->whereNull('read_at')->count()
        ]);
    }

    /**
     * Show notification preferences
     */
    public function preferences()
    {
        $user = auth()->user();

        $preferences = [
            'email_notifications' => $user->notification_email ?? true,
            'sms_notifications' => $user->notification_sms ?? false,
            'browser_notifications' => $user->notification_browser ?? true,
            'order_updates' => $user->notification_order_updates ?? true,
            'payment_updates' => $user->notification_payment_updates ?? true,
            'ticket_updates' => $user->notification_ticket_updates ?? true,
            'referral_updates' => $user->notification_referral_updates ?? true,
            'promotional' => $user->notification_promotional ?? true,
            'security_alerts' => $user->notification_security_alerts ?? true
        ];

        return view('user.notifications.preferences', compact('preferences'));
    }

    /**
     * Update notification preferences
     */
    public function updatePreferences(Request $request)
    {
        $validated = $request->validate([
            'email_notifications' => 'boolean',
            'sms_notifications' => 'boolean',
            'browser_notifications' => 'boolean',
            'order_updates' => 'boolean',
            'payment_updates' => 'boolean',
            'ticket_updates' => 'boolean',
            'referral_updates' => 'boolean',
            'promotional' => 'boolean',
            'security_alerts' => 'boolean'
        ]);

        auth()->user()->update([
            'notification_email' => $validated['email_notifications'] ?? false,
            'notification_sms' => $validated['sms_notifications'] ?? false,
            'notification_browser' => $validated['browser_notifications'] ?? false,
            'notification_order_updates' => $validated['order_updates'] ?? false,
            'notification_payment_updates' => $validated['payment_updates'] ?? false,
            'notification_ticket_updates' => $validated['ticket_updates'] ?? false,
            'notification_referral_updates' => $validated['referral_updates'] ?? false,
            'notification_promotional' => $validated['promotional'] ?? false,
            'notification_security_alerts' => $validated['security_alerts'] ?? true // Always true for security
        ]);

        return back()->with('success', 'Notification preferences updated successfully');
    }

    /**
     * Subscribe to browser notifications
     */
    public function subscribeToPush(Request $request)
    {
        $validated = $request->validate([
            'endpoint' => 'required|url',
            'keys' => 'required|array',
            'keys.p256dh' => 'required|string',
            'keys.auth' => 'required|string'
        ]);

        // Store subscription
        auth()->user()->pushSubscriptions()->updateOrCreate(
            ['endpoint' => $validated['endpoint']],
            [
                'public_key' => $validated['keys']['p256dh'],
                'auth_token' => $validated['keys']['auth'],
                'content_encoding' => $request->input('contentEncoding', 'aes128gcm')
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Successfully subscribed to push notifications'
        ]);
    }

    /**
     * Unsubscribe from browser notifications
     */
    public function unsubscribeFromPush(Request $request)
    {
        $validated = $request->validate([
            'endpoint' => 'required|url'
        ]);

        auth()->user()->pushSubscriptions()
            ->where('endpoint', $validated['endpoint'])
            ->delete();

        return response()->json([
            'success' => true,
            'message' => 'Successfully unsubscribed from push notifications'
        ]);
    }
}
