<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\CurrencyService;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    protected $currencyService;

    public function __construct(CurrencyService $currencyService)
    {
        $this->currencyService = $currencyService;
    }

    /**
     * Change user's currency preference
     */
    public function setCurrency(Request $request)
    {
        $validated = $request->validate([
            'currency' => 'required|string|size:3'
        ]);

        $success = $this->currencyService->setUserCurrency(
            $validated['currency'],
            auth()->user()
        );

        if (!$success) {
            return back()->withErrors(['error' => 'Invalid currency selected']);
        }

        return back()->with('success', 'Currency updated successfully');
    }

    /**
     * Get current exchange rate
     */
    public function getRate(string $currency)
    {
        $rate = $this->currencyService->getCurrency($currency);

        if (!$rate) {
            return response()->json(['error' => 'Currency not found'], 404);
        }

        return response()->json([
            'code' => $rate->code,
            'name' => $rate->name,
            'symbol' => $rate->symbol,
            'rate' => $rate->exchange_rate,
            'last_updated' => $rate->last_updated
        ]);
    }

    /**
     * Get all active currencies
     */
    public function getCurrencies()
    {
        $currencies = $this->currencyService->getActiveCurrencies();

        return response()->json($currencies);
    }

    /**
     * Convert price
     */
    public function convert(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:0',
            'from' => 'required|string|size:3',
            'to' => 'required|string|size:3'
        ]);

        $converted = $this->currencyService->convertBetween(
            $validated['amount'],
            $validated['from'],
            $validated['to']
        );

        return response()->json([
            'original_amount' => $validated['amount'],
            'original_currency' => $validated['from'],
            'converted_amount' => $converted,
            'converted_currency' => $validated['to'],
            'formatted' => $this->currencyService->format($converted, $validated['to'])
        ]);
    }
}
