<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiClient;
use Illuminate\Http\Request;

class ApiKeyController extends Controller
{
    /**
     * Show API documentation
     */
    public function documentation()
    {
        $apiKey = auth()->user()->apiClients()->where('status', 'active')->first();
        
        return view('user.api.documentation', compact('apiKey'));
    }

    /**
     * Generate new API key
     */
    public function generate(Request $request)
    {
        $user = auth()->user();

        // Check if user already has an active API key
        $existing = $user->apiClients()->where('status', 'active')->first();
        
        if ($existing) {
            return back()->with('info', 'You already have an active API key. Regenerate it below if needed.');
        }

        // Generate new API key
        $apiKey = ApiClient::create([
            'user_id' => $user->id,
            'name' => 'Main API Key',
            'api_key' => ApiClient::generateApiKey(),
            'api_secret' => ApiClient::generateApiSecret(),
            'status' => 'active',
            'rate_limit' => 1000 // 1000 requests per hour
        ]);

        return back()->with('success', 'API key generated successfully!');
    }

    /**
     * Regenerate API key
     */
    public function regenerate(Request $request)
    {
        $user = auth()->user();

        // Deactivate old keys
        $user->apiClients()->update(['status' => 'inactive']);

        // Generate new API key
        $apiKey = ApiClient::create([
            'user_id' => $user->id,
            'name' => 'Main API Key',
            'api_key' => ApiClient::generateApiKey(),
            'api_secret' => ApiClient::generateApiSecret(),
            'status' => 'active',
            'rate_limit' => 1000
        ]);

        return back()->with('success', 'API key regenerated! Old keys are now inactive.');
    }

    /**
     * Deactivate API key
     */
    public function deactivate(Request $request)
    {
        $user = auth()->user();
        $user->apiClients()->update(['status' => 'inactive']);

        return back()->with('success', 'API key deactivated successfully.');
    }
}
