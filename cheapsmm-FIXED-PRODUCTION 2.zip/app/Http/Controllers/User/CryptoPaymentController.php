<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\CryptoPaymentService;
use Illuminate\Http\Request;

class CryptoPaymentController extends Controller
{
    protected $cryptoService;

    public function __construct(CryptoPaymentService $cryptoService)
    {
        $this->cryptoService = $cryptoService;
    }

    public function create()
    {
        $currencies = $this->cryptoService->getSupportedCurrencies();
        return view('user.payments.crypto', compact('currencies'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:10',
            'crypto' => 'required|in:BTC,ETH,USDT,BNB'
        ]);

        $payment = $this->cryptoService->createPayment(
            auth()->user(),
            $validated['amount'],
            $validated['crypto']
        );

        return view('user.payments.crypto-checkout', compact('payment'));
    }
}
