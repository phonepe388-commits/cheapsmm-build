<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\{ChildPanel, Service};
use App\Services\ChildPanelService;
use Illuminate\Http\Request;

class ChildPanelController extends Controller
{
    protected $childPanelService;

    public function __construct(ChildPanelService $childPanelService)
    {
        $this->childPanelService = $childPanelService;
    }

    /**
     * Show child panels list
     */
    public function index()
    {
        $panels = auth()->user()->childPanels()->withCount('childUsers', 'orders')->get();
        
        return view('user.child-panels.index', compact('panels'));
    }

    /**
     * Show create form
     */
    public function create()
    {
        return view('user.child-panels.create');
    }

    /**
     * Store new child panel
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'domain' => 'nullable|string|max:255|unique:child_panels',
            'subdomain' => 'nullable|string|max:255|unique:child_panels',
            'markup_percentage' => 'required|numeric|min:0|max:100',
            'credit_limit' => 'nullable|numeric|min:0',
            'support_email' => 'nullable|email',
            'currency' => 'nullable|string',
            'language' => 'nullable|string'
        ]);

        try {
            $panel = $this->childPanelService->createPanel(auth()->user(), $validated);
            
            return redirect()->route('user.child-panels.show', $panel)
                ->with('success', 'Child panel created successfully!');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    /**
     * Show child panel details
     */
    public function show(ChildPanel $childPanel)
    {
        $this->authorize('view', $childPanel);
        
        $stats = $this->childPanelService->getStatistics($childPanel);
        $childPanel->load(['childUsers' => function($q) {
            $q->latest()->limit(10);
        }]);
        
        return view('user.child-panels.show', compact('childPanel', 'stats'));
    }

    /**
     * Show edit form
     */
    public function edit(ChildPanel $childPanel)
    {
        $this->authorize('update', $childPanel);
        
        return view('user.child-panels.edit', compact('childPanel'));
    }

    /**
     * Update child panel
     */
    public function update(Request $request, ChildPanel $childPanel)
    {
        $this->authorize('update', $childPanel);
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'domain' => 'nullable|string|max:255|unique:child_panels,domain,' . $childPanel->id,
            'markup_percentage' => 'required|numeric|min:0|max:100',
            'credit_limit' => 'nullable|numeric|min:0',
            'primary_color' => 'nullable|string|max:7',
            'secondary_color' => 'nullable|string|max:7',
            'support_email' => 'nullable|email',
            'support_phone' => 'nullable|string',
            'custom_footer' => 'nullable|string'
        ]);

        $childPanel->update($validated);
        
        return back()->with('success', 'Child panel updated successfully!');
    }

    /**
     * Manage service pricing
     */
    public function pricing(ChildPanel $childPanel)
    {
        $this->authorize('update', $childPanel);
        
        $services = Service::with(['childPanelPricing' => function($q) use ($childPanel) {
            $q->where('child_panel_id', $childPanel->id);
        }])->where('status', 'active')->get();
        
        return view('user.child-panels.pricing', compact('childPanel', 'services'));
    }

    /**
     * Update service pricing
     */
    public function updatePricing(Request $request, ChildPanel $childPanel)
    {
        $this->authorize('update', $childPanel);
        
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'price' => 'required|numeric|min:0'
        ]);

        $this->childPanelService->updateServicePricing(
            $childPanel,
            $validated['service_id'],
            $validated['price']
        );
        
        return back()->with('success', 'Pricing updated successfully!');
    }

    /**
     * Add funds to child panel
     */
    public function addFunds(Request $request, ChildPanel $childPanel)
    {
        $this->authorize('update', $childPanel);
        
        $validated = $request->validate([
            'amount' => 'required|numeric|min:1'
        ]);

        $user = auth()->user();
        
        if ($user->balance < $validated['amount']) {
            return back()->withErrors(['error' => 'Insufficient balance']);
        }

        // Deduct from user, add to child panel
        $user->decrement('balance', $validated['amount']);
        $childPanel->addBalance($validated['amount']);

        return back()->with('success', 'Funds added successfully!');
    }

    /**
     * Delete child panel
     */
    public function destroy(ChildPanel $childPanel)
    {
        $this->authorize('delete', $childPanel);
        
        if ($childPanel->childUsers()->count() > 0) {
            return back()->withErrors(['error' => 'Cannot delete panel with active users']);
        }

        $childPanel->delete();
        
        return redirect()->route('user.child-panels.index')
            ->with('success', 'Child panel deleted successfully!');
    }
}
