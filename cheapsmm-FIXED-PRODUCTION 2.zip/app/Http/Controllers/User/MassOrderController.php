<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\MassOrderService;
use Illuminate\Http\Request;

class MassOrderController extends Controller
{
    protected $massOrderService;

    public function __construct(MassOrderService $massOrderService)
    {
        $this->massOrderService = $massOrderService;
    }

    /**
     * Show mass order form
     */
    public function create()
    {
        $textTemplate = $this->massOrderService->getTemplate('text');
        $csvTemplate = $this->massOrderService->getTemplate('csv');

        return view('user.orders.mass-order', compact('textTemplate', 'csvTemplate'));
    }

    /**
     * Validate and preview mass orders
     */
    public function validate(Request $request)
    {
        $request->validate([
            'input_type' => 'required|in:text,csv',
            'text_input' => 'required_if:input_type,text',
            'csv_file' => 'required_if:input_type,csv|file|mimes:csv,txt|max:2048'
        ]);

        try {
            $user = auth()->user();

            // Parse input
            if ($request->input_type === 'text') {
                $parsed = $this->massOrderService->parseTextInput($request->text_input);
            } else {
                $parsed = $this->massOrderService->parseCsvFile($request->file('csv_file'));
            }

            // Check for parsing errors
            if (empty($parsed['orders']) && !empty($parsed['errors'])) {
                return back()->withErrors([
                    'error' => 'No valid orders found. Please check your input format.'
                ])->withInput()->with('parsing_errors', $parsed['errors']);
            }

            // Validate orders
            $validation = $this->massOrderService->validateOrders($user, $parsed['orders']);

            // Store validation data in session for processing
            session([
                'mass_order_validation' => $validation,
                'mass_order_parsed' => $parsed
            ]);

            return view('user.orders.mass-order-preview', [
                'validation' => $validation,
                'parsed' => $parsed,
                'user' => $user
            ]);

        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    /**
     * Process confirmed mass orders
     */
    public function process(Request $request)
    {
        // Retrieve validation data from session
        $validation = session('mass_order_validation');

        if (!$validation) {
            return redirect()->route('user.orders.mass.create')
                ->withErrors(['error' => 'Session expired. Please submit your orders again.']);
        }

        try {
            $user = auth()->user();

            // Double-check balance (might have changed)
            if ($user->balance < $validation['total_cost']) {
                return back()->withErrors([
                    'error' => 'Insufficient balance. Your balance may have changed.'
                ]);
            }

            // Process orders
            $results = $this->massOrderService->processMassOrders(
                $user, 
                $validation['validated_orders']
            );

            // Clear session data
            session()->forget(['mass_order_validation', 'mass_order_parsed']);

            return view('user.orders.mass-order-results', [
                'results' => $results,
                'user' => $user->fresh()
            ]);

        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Download mass order template
     */
    public function downloadTemplate(Request $request)
    {
        $format = $request->get('format', 'text');
        $template = $this->massOrderService->getTemplate($format);

        $filename = $format === 'csv' 
            ? 'mass-order-template.csv' 
            : 'mass-order-template.txt';

        return response($template)
            ->header('Content-Type', 'text/plain')
            ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
    }

    /**
     * Download mass order results
     */
    public function downloadResults(Request $request)
    {
        $results = session('last_mass_order_results');

        if (!$results) {
            return redirect()->route('user.orders.mass.create')
                ->withErrors(['error' => 'No results available to download.']);
        }

        $csv = $this->massOrderService->exportResults($results);

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', 'attachment; filename="mass-order-results.csv"');
    }

    /**
     * Cancel mass order preview
     */
    public function cancel()
    {
        session()->forget(['mass_order_validation', 'mass_order_parsed']);
        
        return redirect()->route('user.orders.mass.create')
            ->with('info', 'Mass order cancelled.');
    }
}
