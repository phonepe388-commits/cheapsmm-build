<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\{Payment, PaymentMethod};
use App\Services\{EmailService, StripePaymentService};
use App\Services\PaymentGateways\{PayPalService, RazorpayService, ManualPaymentService};
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected $emailService;
    protected $stripeService;
    protected $paypalService;
    protected $razorpayService;
    protected $manualService;

    public function __construct(
        EmailService $emailService,
        StripePaymentService $stripeService,
        PayPalService $paypalService,
        RazorpayService $razorpayService,
        ManualPaymentService $manualService
    ) {
        $this->emailService = $emailService;
        $this->stripeService = $stripeService;
        $this->paypalService = $paypalService;
        $this->razorpayService = $razorpayService;
        $this->manualService = $manualService;
    }

    /**
     * Show payment history
     */
    public function index(Request $request)
    {
        $query = auth()->user()->payments()->with('paymentMethod');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $payments = $query->latest()->paginate(20);

        $stats = [
            'total_deposited' => auth()->user()->payments()
                ->where('status', 'completed')->sum('amount'),
            'pending_amount' => auth()->user()->payments()
                ->where('status', 'pending')->sum('amount'),
            'total_transactions' => auth()->user()->payments()->count()
        ];

        return view('user.payments.index', compact('payments', 'stats'));
    }

    /**
     * Show add funds page
     */
    public function create()
    {
        $paymentMethods = PaymentMethod::where('status', 'active')
            ->orderBy('sort_order')
            ->get();

        $minAmount = setting('min_payment_amount', 10);
        $maxAmount = setting('max_payment_amount', 10000);

        return view('user.payments.add-funds', compact('paymentMethods', 'minAmount', 'maxAmount'));
    }

    /**
     * Process payment
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:' . setting('min_payment_amount', 10) . '|max:' . setting('max_payment_amount', 10000),
            'payment_method' => 'required|exists:payment_methods,id',
            'coupon_code' => 'nullable|string'
        ]);

        $paymentMethod = PaymentMethod::findOrFail($validated['payment_method']);
        $user = auth()->user();
        $originalAmount = $validated['amount'];
        $finalAmount = $originalAmount;
        $couponId = null;
        $discountAmount = 0;

        // Process coupon if provided
        if (!empty($validated['coupon_code'])) {
            $couponService = app(\App\Services\CouponService::class);
            $couponResult = $couponService->validateCoupon($validated['coupon_code'], $user, $originalAmount);
            
            if ($couponResult['valid']) {
                $finalAmount = $couponResult['final_amount'];
                $discountAmount = $couponResult['discount'];
                $couponId = $couponResult['coupon']->id;
            }
        }

        try {
            switch ($paymentMethod->code) {
                case 'stripe':
                    return $this->processStripe($user, $finalAmount, $originalAmount, $couponId, $discountAmount);

                case 'paypal':
                    return $this->processPayPal($user, $finalAmount, $originalAmount, $couponId, $discountAmount);

                case 'razorpay':
                    return $this->processRazorpay($user, $finalAmount, $originalAmount, $couponId, $discountAmount);

                default:
                    // Manual payment methods
                    return $this->processManualPayment($user, $finalAmount, $paymentMethod, $originalAmount, $couponId, $discountAmount);
            }

        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Process Stripe payment
     */
    private function processStripe($user, $amount, $originalAmount = null, $couponId = null, $discountAmount = 0)
    {
        $result = $this->stripeService->createCheckoutSession($user, $amount, [
            'original_amount' => $originalAmount,
            'coupon_id' => $couponId,
            'discount_amount' => $discountAmount
        ]);
        return redirect()->away("https://checkout.stripe.com/c/pay/{$result['session_id']}");
    }

    /**
     * Process PayPal payment
     */
    private function processPayPal($user, $amount, $originalAmount = null, $couponId = null, $discountAmount = 0)
    {
        $result = $this->paypalService->createOrder($user, $amount, [
            'original_amount' => $originalAmount,
            'coupon_id' => $couponId,
            'discount_amount' => $discountAmount
        ]);
        return redirect()->away($result['approval_url']);
    }

    /**
     * Process Razorpay payment
     */
    private function processRazorpay($user, $amount, $originalAmount = null, $couponId = null, $discountAmount = 0)
    {
        $result = $this->razorpayService->createOrder($user, $amount, [
            'original_amount' => $originalAmount,
            'coupon_id' => $couponId,
            'discount_amount' => $discountAmount
        ]);
        return view('user.payments.razorpay-checkout', compact('result'));
    }

    /**
     * Process manual payment
     */
    private function processManualPayment($user, $amount, $paymentMethod, $originalAmount = null, $couponId = null, $discountAmount = 0)
    {
        $instructions = $this->manualService->getPaymentInstructions($paymentMethod->code);
        session([
            'payment_coupon_id' => $couponId,
            'payment_discount' => $discountAmount,
            'payment_original_amount' => $originalAmount
        ]);
        return view('user.payments.manual-payment', compact('amount', 'paymentMethod', 'instructions'));
    }

    /**
     * Submit manual payment proof
     */
    public function submitManualProof(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'payment_method_code' => 'required',
            'transaction_ref' => 'required',
            'sender_name' => 'required',
            'transfer_date' => 'required|date',
            'receipt' => 'required|file|mimes:jpg,jpeg,png,pdf|max:5120',
            'notes' => 'nullable|max:500'
        ]);

        // Upload receipt
        $receiptPath = $request->file('receipt')->store('payment-receipts', 'public');

        $details = [
            'transaction_ref' => $validated['transaction_ref'],
            'sender_name' => $validated['sender_name'],
            'transfer_date' => $validated['transfer_date'],
            'receipt_file' => $receiptPath,
            'notes' => $validated['notes']
        ];

        $payment = $this->manualService->createPaymentRequest(
            auth()->user(),
            $validated['amount'],
            $validated['payment_method_code'],
            $details
        );

        return redirect()->route('user.payments.index')
            ->with('success', 'Payment submitted for review. You will be notified once approved.');
    }

    /**
     * Stripe success callback
     */
    public function stripeSuccess(Request $request)
    {
        $sessionId = $request->get('session_id');
        
        try {
            $payment = $this->stripeService->handleSuccess($sessionId);
            return view('user.payments.success', compact('payment'));
        } catch (\Exception $e) {
            return redirect()->route('user.payments.create')
                ->withErrors(['error' => 'Payment verification failed']);
        }
    }

    /**
     * PayPal success callback
     */
    public function paypalSuccess(Request $request)
    {
        $token = $request->get('token');
        
        try {
            $payment = $this->paypalService->capturePayment($token);
            return view('user.payments.success', compact('payment'));
        } catch (\Exception $e) {
            return redirect()->route('user.payments.create')
                ->withErrors(['error' => 'Payment verification failed']);
        }
    }

    /**
     * Razorpay verification
     */
    public function razorpayVerify(Request $request)
    {
        $validated = $request->validate([
            'razorpay_order_id' => 'required',
            'razorpay_payment_id' => 'required',
            'razorpay_signature' => 'required'
        ]);

        try {
            $payment = $this->razorpayService->verifyPayment(
                $validated['razorpay_order_id'],
                $validated['razorpay_payment_id'],
                $validated['razorpay_signature']
            );

            return redirect()->route('user.payments.success-page', ['payment' => $payment->id]);
        } catch (\Exception $e) {
            return redirect()->route('user.payments.create')
                ->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Show payment success page
     */
    public function successPage(Payment $payment)
    {
        $this->authorize('view', $payment);
        return view('user.payments.success', compact('payment'));
    }

    /**
     * Show payment details
     */
    public function show(Payment $payment)
    {
        $this->authorize('view', $payment);
        return view('user.payments.show', compact('payment'));
    }

    /**
     * Stripe webhook
     */
    public function stripeWebhook(Request $request)
    {
        $payload = $request->all();
        $this->stripeService->handleWebhook($payload);
        return response()->json(['status' => 'success']);
    }

    /**
     * PayPal webhook
     */
    public function paypalWebhook(Request $request)
    {
        $payload = $request->all();
        $this->paypalService->handleWebhook($payload);
        return response()->json(['status' => 'success']);
    }

    /**
     * Razorpay webhook
     */
    public function razorpayWebhook(Request $request)
    {
        $signature = $request->header('X-Razorpay-Signature');
        $body = $request->getContent();

        if (!$this->razorpayService->verifyWebhookSignature($signature, $body)) {
            return response()->json(['error' => 'Invalid signature'], 403);
        }

        $this->razorpayService->handleWebhook($request->all());
        return response()->json(['status' => 'success']);
    }
}

    /**
     * Validate coupon code (AJAX)
     */
    public function validateCoupon(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'amount' => 'required|numeric|min:0'
        ]);

        $couponService = app(\App\Services\CouponService::class);
        $result = $couponService->validateCoupon(
            $request->code,
            auth()->user(),
            $request->amount
        );

        if (!$result['valid']) {
            return response()->json([
                'valid' => false,
                'error' => $result['error']
            ], 400);
        }

        return response()->json([
            'valid' => true,
            'discount' => number_format($result['discount'], 2),
            'final_amount' => number_format($result['final_amount'], 2),
            'code' => $result['coupon']->code
        ]);
    }
}
