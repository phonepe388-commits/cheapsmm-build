<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\{Category, Service, Order};
use App\Services\{OrderService, EmailService};
use Illuminate\Http\Request;

class OrderController extends Controller
{
    protected $orderService;
    protected $emailService;

    public function __construct(OrderService $orderService, EmailService $emailService)
    {
        $this->orderService = $orderService;
        $this->emailService = $emailService;
    }

    public function index(Request $request)
    {
        $query = auth()->user()->orders()->with('service');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('id', $request->search)
                  ->orWhereHas('service', function($sq) use ($request) {
                      $sq->where('name', 'like', "%{$request->search}%");
                  });
            });
        }

        $orders = $query->latest()->paginate(20);

        return view('user.orders.index', compact('orders'));
    }

    public function create()
    {
        $categories = Category::where('status', 'active')
            ->withCount('services')
            ->having('services_count', '>', 0)
            ->get();

        return view('user.orders.create', compact('categories'));
    }

    public function getServices($categoryId)
    {
        $services = Service::where('category_id', $categoryId)
            ->where('status', 'active')
            ->select('id', 'name', 'price_per_1000', 'min_quantity', 'max_quantity', 'description')
            ->get();

        return response()->json($services);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'link' => 'required|url',
            'quantity' => 'required|integer|min:1'
        ]);

        try {
            $order = $this->orderService->createOrder(auth()->user(), $validated);

            // Send order confirmation email
            $this->emailService->sendOrderConfirmation($order);

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Order placed successfully!',
                    'order' => $order
                ]);
            }

            return redirect()->route('user.orders.show', $order)
                ->with('success', 'Order placed successfully! Check your email for confirmation.');
                
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage()
                ], 400);
            }

            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function show(Order $order)
    {
        $this->authorize('view', $order);

        $order->load('service', 'user');

        return view('user.orders.show', compact('order'));
    }

    public function cancel(Order $order)
    {
        $this->authorize('update', $order);

        try {
            $this->orderService->cancelOrder($order);

            return back()->with('success', 'Order cancelled successfully. Funds have been refunded.');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}

    /**
     * Export user's orders to CSV
     */
    public function export(Request $request, \App\Services\ExportService $exportService)
    {
        $query = auth()->user()->orders()->with('service');

        // Apply filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $csv = $exportService->exportOrders($query);
        $filename = $exportService->getFilename('orders');

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename=\"{$filename}\"");
    }
