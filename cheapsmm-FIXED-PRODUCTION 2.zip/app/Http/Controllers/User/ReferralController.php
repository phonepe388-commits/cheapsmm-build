<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReferralController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        
        $stats = [
            'total_referrals' => $user->referrals()->count(),
            'active_referrals' => $user->referrals()->where('status', 'active')->count(),
            'total_earned' => $user->referralEarnings()->sum('amount'),
            'pending_earnings' => $user->referralEarnings()->where('status', 'pending')->sum('amount'),
            'paid_earnings' => $user->referralEarnings()->where('status', 'paid')->sum('amount'),
        ];

        $referrals = $user->referrals()
            ->with('referralEarnings')
            ->latest()
            ->paginate(20);

        $earnings = $user->referralEarnings()
            ->with('order')
            ->latest()
            ->paginate(20);

        return view('user.referrals.index', compact('user', 'stats', 'referrals', 'earnings'));
    }

    public function withdraw(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:10'
        ]);

        $user = auth()->user();
        $availableEarnings = $user->referralEarnings()
            ->where('status', 'pending')
            ->sum('amount');

        if ($validated['amount'] > $availableEarnings) {
            return back()->withErrors(['amount' => 'Insufficient earnings']);
        }

        // Transfer to main balance
        $user->increment('balance', $validated['amount']);
        
        // Mark earnings as paid
        $user->referralEarnings()
            ->where('status', 'pending')
            ->update(['status' => 'paid']);

        // Log transaction
        $user->transactions()->create([
            'type' => 'credit',
            'amount' => $validated['amount'],
            'balance_before' => $user->balance - $validated['amount'],
            'balance_after' => $user->balance,
            'description' => 'Referral earnings withdrawal',
            'reference_type' => 'referral_withdrawal'
        ]);

        return back()->with('success', 'Earnings transferred to your balance!');
    }
}
