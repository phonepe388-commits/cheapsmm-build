<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\Password;
use PragmaRX\Google2FA\Google2FA;

class ProfileController extends Controller
{
    public function edit()
    {
        $user = auth()->user();
        $timezones = \DateTimeZone::listIdentifiers();
        $languages = \App\Models\Language::where('status', 'active')->get();
        $currencies = \App\Models\Currency::where('status', 'active')->get();
        return view('user.profile.edit', compact('user', 'timezones', 'languages', 'currencies'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . auth()->id(),
            'phone' => 'nullable|string|max:20',
            'timezone' => 'nullable|timezone',
            'language_id' => 'nullable|exists:languages,id',
            'currency_id' => 'nullable|exists:currencies,id'
        ]);

        $user = auth()->user();
        $emailChanged = $user->email !== $validated['email'];
        $user->update($validated);

        if ($emailChanged) {
            $user->update(['email_verified_at' => null]);
            return back()->with('warning', 'Please verify your new email');
        }

        return back()->with('success', 'Profile updated successfully');
    }

    public function updatePassword(Request $request)
    {
        $validated = $request->validate([
            'current_password' => 'required',
            'password' => ['required', 'confirmed', Password::min(8)]
        ]);

        if (!Hash::check($validated['current_password'], auth()->user()->password)) {
            return back()->withErrors(['current_password' => 'Current password is incorrect']);
        }

        auth()->user()->update(['password' => Hash::make($validated['password'])]);

        \App\Models\ActivityLog::create([
            'user_id' => auth()->id(),
            'action' => 'password_changed',
            'ip_address' => $request->ip()
        ]);

        return back()->with('success', 'Password updated successfully');
    }

    public function uploadAvatar(Request $request)
    {
        $request->validate(['avatar' => 'required|image|max:2048']);
        
        $user = auth()->user();
        if ($user->avatar) Storage::disk('public')->delete($user->avatar);
        
        $path = $request->file('avatar')->store('avatars', 'public');
        $user->update(['avatar' => $path]);
        
        return back()->with('success', 'Avatar updated');
    }

    public function deleteAvatar()
    {
        $user = auth()->user();
        if ($user->avatar) Storage::disk('public')->delete($user->avatar);
        $user->update(['avatar' => null]);
        return back()->with('success', 'Avatar removed');
    }

    public function twoFactorSettings()
    {
        return view('user.profile.two-factor', ['user' => auth()->user()]);
    }

    public function enableTwoFactor()
    {
        if (auth()->user()->two_factor_enabled) {
            return back()->with('info', '2FA already enabled');
        }

        $google2fa = new Google2FA();
        $secret = $google2fa->generateSecretKey();
        $qrCodeUrl = $google2fa->getQRCodeUrl(config('app.name'), auth()->user()->email, $secret);

        session(['2fa_secret' => $secret]);

        return view('user.profile.two-factor-setup', compact('secret', 'qrCodeUrl'));
    }

    public function confirmTwoFactor(Request $request)
    {
        $request->validate(['code' => 'required|digits:6']);
        $secret = session('2fa_secret');

        if (!$secret) {
            return back()->withErrors(['error' => 'Session expired']);
        }

        $google2fa = new Google2FA();
        if (!$google2fa->verifyKey($secret, $request->code)) {
            return back()->withErrors(['code' => 'Invalid code']);
        }

        auth()->user()->update([
            'two_factor_secret' => encrypt($secret),
            'two_factor_enabled' => true
        ]);

        session()->forget('2fa_secret');

        \App\Models\ActivityLog::create([
            'user_id' => auth()->id(),
            'action' => '2fa_enabled',
            'ip_address' => $request->ip()
        ]);

        return redirect()->route('user.profile.edit')->with('success', '2FA enabled successfully');
    }

    public function disableTwoFactor(Request $request)
    {
        $request->validate(['password' => 'required']);

        if (!Hash::check($request->password, auth()->user()->password)) {
            return back()->withErrors(['password' => 'Incorrect password']);
        }

        auth()->user()->update([
            'two_factor_secret' => null,
            'two_factor_enabled' => false
        ]);

        \App\Models\ActivityLog::create([
            'user_id' => auth()->id(),
            'action' => '2fa_disabled',
            'ip_address' => $request->ip()
        ]);

        return back()->with('success', '2FA disabled');
    }
}
