<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\SocialFeaturesService;
use App\Models\{ServiceReview, Leaderboard, Achievement, DailyReward};
use Illuminate\Http\Request;

class SocialController extends Controller
{
    protected $socialService;

    public function __construct(SocialFeaturesService $socialService)
    {
        $this->socialService = $socialService;
    }

    public function leaderboard()
    {
        $monthly = $this->socialService->getLeaderboard('monthly');
        $weekly = $this->socialService->getLeaderboard('weekly');
        $daily = $this->socialService->getLeaderboard('daily');

        return view('user.social.leaderboard', compact('monthly', 'weekly', 'daily'));
    }

    public function achievements()
    {
        $achievements = auth()->user()->achievements;
        $available = [
            ['type' => 'first_order', 'name' => 'First Order', 'description' => 'Place your first order', 'reward' => 5],
            ['type' => 'big_spender', 'name' => 'Big Spender', 'description' => 'Spend over $1000', 'reward' => 50],
            ['type' => 'loyal_customer', 'name' => 'Loyal Customer', 'description' => 'Complete 100+ orders', 'reward' => 100],
        ];

        return view('user.social.achievements', compact('achievements', 'available'));
    }

    public function dailyReward()
    {
        $reward = $this->socialService->claimDailyReward(auth()->user());

        if (!$reward) {
            return back()->withErrors(['error' => 'Already claimed today!']);
        }

        return back()->with('success', "Claimed ${$reward->amount}! Streak: {$reward->streak_days} days");
    }

    public function submitReview(Request $request)
    {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:500'
        ]);

        $this->socialService->submitReview(
            auth()->user(),
            $validated['service_id'],
            $validated['rating'],
            $validated['comment']
        );

        return back()->with('success', 'Review submitted! Thank you!');
    }
}
