<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Service;
use App\Models\ServiceReview;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    /**
     * Display services page
     */
    public function index(Request $request)
    {
        $categoryId = $request->get('category');
        $search = $request->get('search');

        $categories = Category::active()
            ->parents()
            ->withCount('services')
            ->orderBy('display_order')
            ->get();

        $services = Service::active()
            ->where('is_secret', false)
            ->when($categoryId, function($query) use ($categoryId) {
                return $query->where('category_id', $categoryId);
            })
            ->when($search, function($query) use ($search) {
                return $query->where('name', 'like', "%{$search}%")
                            ->orWhere('description', 'like', "%{$search}%");
            })
            ->with('category')
            ->withCount('orders')
            ->orderBy('display_order')
            ->paginate(50);

        return view('user.services.index', compact('categories', 'services'));
    }

    /**
     * Show service details
     */
    public function show(Service $service)
    {
        if (!$service->isAvailable() || $service->is_secret) {
            abort(404);
        }

        $service->load(['category', 'reviews' => function($query) {
            $query->where('status', 'approved')
                  ->orderBy('created_at', 'desc')
                  ->limit(10);
        }]);

        $priceForUser = $service->getPriceForUser(auth()->user(), 1000);
        $averageRating = $service->getAverageRating();

        return view('user.services.show', compact('service', 'priceForUser', 'averageRating'));
    }

    /**
     * Search services (AJAX)
     */
    public function search(Request $request)
    {
        $query = $request->get('q');

        $services = Service::active()
            ->where('is_secret', false)
            ->where(function($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                  ->orWhere('description', 'like', "%{$query}%");
            })
            ->limit(10)
            ->get()
            ->map(function($service) {
                return [
                    'id' => $service->id,
                    'name' => $service->name,
                    'category' => $service->category->name,
                    'price' => $service->getPriceForUser(auth()->user(), 1000),
                ];
            });

        return response()->json($services);
    }
}
