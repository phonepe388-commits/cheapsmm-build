<?php
namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
use App\Models\ServiceReview;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function store(Request $request) {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:500'
        ]);
        
        $validated['user_id'] = auth()->id();
        ServiceReview::create($validated);
        return back()->with('success', 'Review submitted!');
    }
}
