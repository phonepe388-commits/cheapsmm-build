<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\TicketMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TicketController extends Controller
{
    /**
     * Display all tickets
     */
    public function index(Request $request)
    {
        $query = auth()->user()->tickets()->with('messages');

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by priority
        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('subject', 'like', "%{$request->search}%")
                  ->orWhere('id', $request->search);
            });
        }

        $tickets = $query->latest()->paginate(20);

        $stats = [
            'total' => auth()->user()->tickets()->count(),
            'open' => auth()->user()->tickets()->where('status', 'open')->count(),
            'waiting' => auth()->user()->tickets()->where('status', 'waiting_reply')->count(),
            'closed' => auth()->user()->tickets()->where('status', 'closed')->count()
        ];

        return view('user.tickets.index', compact('tickets', 'stats'));
    }

    /**
     * Show create ticket form
     */
    public function create()
    {
        return view('user.tickets.create');
    }

    /**
     * Store new ticket
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'message' => 'required|string|min:10',
            'priority' => 'required|in:low,medium,high',
            'attachments.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx|max:5120'
        ]);

        // Create ticket
        $ticket = auth()->user()->tickets()->create([
            'subject' => $validated['subject'],
            'priority' => $validated['priority'],
            'status' => 'open'
        ]);

        // Handle file uploads
        $attachmentPaths = [];
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('ticket-attachments', 'public');
                $attachmentPaths[] = [
                    'name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'size' => $file->getSize(),
                    'type' => $file->getMimeType()
                ];
            }
        }

        // Create first message
        $ticket->messages()->create([
            'user_id' => auth()->id(),
            'message' => $validated['message'],
            'attachments' => $attachmentPaths,
            'is_admin' => false
        ]);

        // Create notification for admins
        \App\Models\Admin::where('status', 'active')->each(function($admin) use ($ticket) {
            \App\Models\Notification::create([
                'user_id' => $admin->id,
                'type' => 'new_ticket',
                'title' => 'New Support Ticket',
                'message' => "Ticket #{$ticket->id}: {$ticket->subject}",
                'data' => ['ticket_id' => $ticket->id]
            ]);
        });

        return redirect()
            ->route('user.tickets.show', $ticket)
            ->with('success', 'Ticket created successfully. We will respond as soon as possible.');
    }

    /**
     * Show ticket details
     */
    public function show(Ticket $ticket)
    {
        // Authorization check
        if ($ticket->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access to ticket');
        }

        // Load messages with user/admin info
        $ticket->load(['messages' => function($query) {
            $query->with(['user', 'admin'])->oldest();
        }]);

        // Mark ticket as read by user
        if ($ticket->status === 'answered') {
            $ticket->update(['status' => 'waiting_reply']);
        }

        return view('user.tickets.show', compact('ticket'));
    }

    /**
     * Reply to ticket
     */
    public function reply(Request $request, Ticket $ticket)
    {
        // Authorization check
        if ($ticket->user_id !== auth()->id()) {
            abort(403);
        }

        // Check if ticket is closed
        if ($ticket->status === 'closed') {
            return back()->withErrors(['error' => 'Cannot reply to a closed ticket']);
        }

        $validated = $request->validate([
            'message' => 'required|string|min:1',
            'attachments.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx|max:5120'
        ]);

        // Handle file uploads
        $attachmentPaths = [];
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('ticket-attachments', 'public');
                $attachmentPaths[] = [
                    'name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'size' => $file->getSize(),
                    'type' => $file->getMimeType()
                ];
            }
        }

        // Create reply
        $ticket->messages()->create([
            'user_id' => auth()->id(),
            'message' => $validated['message'],
            'attachments' => $attachmentPaths,
            'is_admin' => false
        ]);

        // Update ticket status
        $ticket->update([
            'status' => 'waiting_reply',
            'last_reply_at' => now()
        ]);

        // Notify assigned admin
        if ($ticket->assigned_to) {
            \App\Models\Notification::create([
                'user_id' => $ticket->assigned_to,
                'type' => 'ticket_reply',
                'title' => 'New Ticket Reply',
                'message' => "User replied to ticket #{$ticket->id}",
                'data' => ['ticket_id' => $ticket->id]
            ]);
        }

        return back()->with('success', 'Reply sent successfully');
    }

    /**
     * Close ticket
     */
    public function close(Ticket $ticket)
    {
        // Authorization check
        if ($ticket->user_id !== auth()->id()) {
            abort(403);
        }

        // Check if already closed
        if ($ticket->status === 'closed') {
            return back()->with('info', 'Ticket is already closed');
        }

        $ticket->update([
            'status' => 'closed',
            'closed_at' => now(),
            'closed_by' => auth()->id()
        ]);

        return back()->with('success', 'Ticket closed successfully');
    }

    /**
     * Reopen ticket
     */
    public function reopen(Ticket $ticket)
    {
        // Authorization check
        if ($ticket->user_id !== auth()->id()) {
            abort(403);
        }

        // Check if already open
        if ($ticket->status !== 'closed') {
            return back()->with('info', 'Ticket is not closed');
        }

        $ticket->update([
            'status' => 'open',
            'closed_at' => null,
            'closed_by' => null
        ]);

        // Add system message
        $ticket->messages()->create([
            'user_id' => auth()->id(),
            'message' => 'Ticket reopened by user',
            'is_admin' => false,
            'is_system' => true
        ]);

        return back()->with('success', 'Ticket reopened successfully');
    }

    /**
     * Download attachment
     */
    public function downloadAttachment(Ticket $ticket, $messageId, $attachmentIndex)
    {
        // Authorization check
        if ($ticket->user_id !== auth()->id()) {
            abort(403);
        }

        $message = $ticket->messages()->findOrFail($messageId);
        
        if (!isset($message->attachments[$attachmentIndex])) {
            abort(404, 'Attachment not found');
        }

        $attachment = $message->attachments[$attachmentIndex];

        if (!Storage::disk('public')->exists($attachment['path'])) {
            abort(404, 'File not found');
        }

        return Storage::disk('public')->download(
            $attachment['path'],
            $attachment['name']
        );
    }
}
