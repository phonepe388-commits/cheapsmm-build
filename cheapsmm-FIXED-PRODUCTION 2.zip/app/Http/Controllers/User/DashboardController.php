<?php
namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
class DashboardController extends Controller {
    public function index() {
        $user = auth()->user();
        $stats = [
            'total_orders' => $user->orders()->count(),
            'pending_orders' => $user->getPendingOrders(),
            'total_spent' => $user->getTotalSpent(),
            'balance' => $user->balance
        ];
        return view('user.dashboard', compact('stats'));
    }
}
