<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class PublicController extends Controller
{
    /**
     * Submit contact form
     */
    public function submitContact(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string|max:5000',
        ]);

        // Send email to support
        Mail::raw(
            "Contact Form Submission\n\n" .
            "Name: {$validated['name']}\n" .
            "Email: {$validated['email']}\n" .
            "Subject: {$validated['subject']}\n\n" .
            "Message:\n{$validated['message']}",
            function($message) use ($validated) {
                $message->to(config('mail.from.address'))
                       ->replyTo($validated['email'])
                       ->subject('Contact Form: ' . $validated['subject']);
            }
        );

        return back()->with('success', 'Thank you! We will get back to you soon.');
    }
}
