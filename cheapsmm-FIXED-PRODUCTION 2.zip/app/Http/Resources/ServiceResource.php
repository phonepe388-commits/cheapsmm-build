<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ServiceResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'service' => $this->id,
            'name' => $this->name,
            'type' => $this->type,
            'category' => $this->category->name ?? null,
            'rate' => number_format($this->price_per_1000, 2),
            'min' => $this->min_quantity,
            'max' => $this->max_quantity,
            'dripfeed' => $this->dripfeed_enabled,
            'refill' => $this->refill_enabled,
            'cancel' => $this->cancel_enabled
        ];
    }
}
