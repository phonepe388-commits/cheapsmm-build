<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'order' => $this->id,
            'charge' => number_format($this->charge, 2),
            'start_count' => $this->start_count ?? 0,
            'status' => $this->status,
            'remains' => $this->remain ?? $this->quantity,
            'currency' => 'USD'
        ];
    }
}
