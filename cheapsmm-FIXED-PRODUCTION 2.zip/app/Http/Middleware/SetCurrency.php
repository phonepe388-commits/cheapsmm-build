<?php

namespace App\Http\Middleware;

use App\Services\CurrencyService;
use Closure;
use Illuminate\Http\Request;

class SetCurrency
{
    protected $currencyService;

    public function __construct(CurrencyService $currencyService)
    {
        $this->currencyService = $currencyService;
    }

    public function handle(Request $request, Closure $next)
    {
        // Auto-detect currency on first visit
        if (!session()->has('currency_detected')) {
            $this->currencyService->autoDetectCurrency($request->ip());
            session(['currency_detected' => true]);
        }

        // Make currency service available in views
        view()->share('currencyService', $this->currencyService);
        view()->share('currentCurrency', $this->currencyService->getCurrentCurrency());

        return $next($request);
    }
}
