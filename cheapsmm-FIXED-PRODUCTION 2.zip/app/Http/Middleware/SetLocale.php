<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    /**
     * Supported locales
     */
    protected $locales = ['en', 'es', 'fr', 'de', 'pt', 'ar', 'hi', 'zh', 'ja', 'ru'];

    /**
     * Handle an incoming request
     */
    public function handle(Request $request, Closure $next)
    {
        // Priority: User preference > Session > Browser > Default
        $locale = $this->determineLocale($request);

        if (in_array($locale, $this->locales)) {
            App::setLocale($locale);
            Session::put('locale', $locale);
        }

        return $next($request);
    }

    /**
     * Determine the locale to use
     */
    private function determineLocale(Request $request): string
    {
        // 1. Check authenticated user preference
        if (auth()->check() && auth()->user()->language) {
            return auth()->user()->language;
        }

        // 2. Check session
        if (Session::has('locale')) {
            return Session::get('locale');
        }

        // 3. Check browser preference
        $browserLocale = $this->getBrowserLocale($request);
        if ($browserLocale && in_array($browserLocale, $this->locales)) {
            return $browserLocale;
        }

        // 4. Default to English
        return config('app.locale', 'en');
    }

    /**
     * Get browser's preferred language
     */
    private function getBrowserLocale(Request $request): ?string
    {
        $acceptLanguage = $request->header('Accept-Language');
        
        if (!$acceptLanguage) {
            return null;
        }

        // Parse Accept-Language header
        $languages = explode(',', $acceptLanguage);
        $primaryLanguage = explode(';', $languages[0])[0];
        $locale = explode('-', $primaryLanguage)[0];

        return strtolower(trim($locale));
    }
}
