<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\ApiClient;

class ApiAuthenticate
{
    public function handle(Request $request, Closure $next)
    {
        $apiKey = $request->header('X-API-Key') ?? $request->get('api_key');

        if (!$apiKey) {
            return response()->json([
                'error' => 'API key required',
                'code' => 'AUTH_REQUIRED'
            ], 401);
        }

        $client = ApiClient::where('api_key', $apiKey)
            ->where('status', 'active')
            ->first();

        if (!$client) {
            return response()->json([
                'error' => 'Invalid API key',
                'code' => 'INVALID_KEY'
            ], 401);
        }

        // Check rate limit
        if ($client->isRateLimited()) {
            return response()->json([
                'error' => 'Rate limit exceeded',
                'code' => 'RATE_LIMIT'
            ], 429);
        }

        // Log API request
        $client->increment('requests_count');
        $client->update(['last_used_at' => now()]);

        $request->merge(['api_client' => $client]);
        $request->setUserResolver(function() use ($client) {
            return $client->user;
        });

        return $next($request);
    }
}
