<?php
namespace App\Http\Middleware;
use Closure;
class CheckUserStatus {
    public function handle($request, Closure $next) {
        if (auth()->check() && auth()->user()->status !== 'active') {
            auth()->logout();
            return redirect('/login')->with('error', 'Your account is ' . auth()->user()->status);
        }
        return $next($request);
    }
}
