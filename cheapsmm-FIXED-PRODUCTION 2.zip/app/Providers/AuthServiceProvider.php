<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use App\Models\ChildPanel;
use App\Policies\ChildPanelPolicy;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings
     */
    protected $policies = [
        ChildPanel::class => ChildPanelPolicy::class,
    ];

    /**
     * Register any authentication / authorization services
     */
    public function boot()
    {
        $this->registerPolicies();
    }
}
