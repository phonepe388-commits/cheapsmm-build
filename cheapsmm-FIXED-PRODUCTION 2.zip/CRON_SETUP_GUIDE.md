# 🤖 Cron Jobs & Automation Setup Guide

## Overview

The CheapSMM panel includes automated background tasks for hands-free operation:

✅ Order status checking (every 5 minutes)  
✅ Dripfeed order processing (every 10 minutes)  
✅ Currency rate updates (every 6 hours)  
✅ Low balance alerts (daily at 9 AM)  
✅ Daily statistics generation (daily at 12:30 AM)  
✅ Inactive user cleanup (weekly on Sunday at 2 AM)

---

## Quick Setup

### 1. Server Cron Configuration

**Add this single line to your crontab:**

```bash
* * * * * cd /path/to/your/project && php artisan schedule:run >> /dev/null 2>&1
```

Replace `/path/to/your/project` with your actual project path.

### 2. Setup Methods by Hosting Type

#### cPanel (Most Common)

1. Log into cPanel
2. Find "Cron Jobs" in Advanced section
3. Add new cron job:
   - **Minute:** `*`
   - **Hour:** `*`
   - **Day:** `*`
   - **Month:** `*`
   - **Weekday:** `*`
   - **Command:** 
     ```
     cd /home/username/public_html && php artisan schedule:run >> /dev/null 2>&1
     ```

#### VPS/Dedicated Server (Linux)

```bash
# Edit crontab
crontab -e

# Add this line
* * * * * cd /var/www/html/your-project && php artisan schedule:run >> /dev/null 2>&1

# Save and exit
```

#### Shared Hosting (Without cPanel)

Contact your hosting provider to set up the cron job for you.

---

## Available Jobs

### 1. Check Order Status
- **Schedule:** Every 5 minutes
- **Purpose:** Update order status from API providers
- **Manual Run:** `php artisan schedule:run-all --job=order-status`

### 2. Process Dripfeed Orders
- **Schedule:** Every 10 minutes
- **Purpose:** Execute dripfeed order batches
- **Manual Run:** `php artisan schedule:run-all --job=dripfeed`

### 3. Update Exchange Rates
- **Schedule:** Every 6 hours
- **Purpose:** Fetch latest currency exchange rates
- **Manual Run:** `php artisan schedule:run-all --job=exchange-rates`

### 4. Send Low Balance Alerts
- **Schedule:** Daily at 9:00 AM
- **Purpose:** Alert users with balance below $10
- **Manual Run:** `php artisan schedule:run-all --job=low-balance`

### 5. Generate Daily Statistics
- **Schedule:** Daily at 12:30 AM
- **Purpose:** Create daily performance reports
- **Manual Run:** `php artisan schedule:run-all --job=statistics`

### 6. Cleanup Inactive Users
- **Schedule:** Weekly (Sunday 2:00 AM)
- **Purpose:** Remove unverified/inactive users
- **Manual Run:** `php artisan schedule:run-all --job=cleanup`

---

## Testing

### Test All Jobs
```bash
php artisan schedule:run-all
```

### Test Specific Job
```bash
php artisan schedule:run-all --job=order-status
```

### Check Logs
```bash
tail -f storage/logs/laravel.log
```

---

## Verification

### 1. Check if Cron is Running

```bash
# View crontab
crontab -l

# Check cron service status (Linux)
systemctl status cron
```

### 2. Monitor Job Execution

- **Admin Panel:** Go to Admin → Automation
- **Log Files:** Check `storage/logs/laravel.log`
- **Database:** Check job execution timestamps

### 3. Test Manually

Run this command and check for any errors:
```bash
php artisan schedule:run
```

---

## Troubleshooting

### Cron Not Running?

**1. Check PHP Path**
```bash
which php
# Use full path in cron: /usr/bin/php instead of php
```

**2. Check Permissions**
```bash
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

**3. Check Log File**
```bash
tail -f storage/logs/laravel.log
```

### Jobs Not Executing?

**1. Verify Queue is Running**
```bash
php artisan queue:work
```

**2. Check Job Classes Exist**
```bash
php artisan list | grep schedule
```

**3. Test Manual Execution**
```bash
php artisan schedule:run-all --job=order-status
```

---

## Advanced Configuration

### Custom Schedule Times

Edit `app/Console/Kernel.php` to modify schedules:

```php
protected function schedule(Schedule $schedule)
{
    // Change order status check to every 15 minutes
    $schedule->job(new CheckOrdersStatusJob())
        ->everyFifteenMinutes();
    
    // Change alerts to 8 AM instead of 9 AM
    $schedule->job(new SendLowBalanceAlerts())
        ->dailyAt('08:00');
}
```

### Disable Specific Jobs

Comment out jobs you don't need in `app/Console/Kernel.php`.

### Add Email Notifications on Failure

```php
$schedule->job(new CheckOrdersStatusJob())
    ->everyFiveMinutes()
    ->emailOutputOnFailure('admin@example.com');
```

---

## Production Checklist

- [ ] Cron job added to server
- [ ] All jobs tested manually
- [ ] Log files monitored for 24 hours
- [ ] Admin automation panel accessible
- [ ] Email alerts configured
- [ ] Queue worker running (if using queues)

---

## Monitoring

### Admin Panel

Access automation dashboard at: `/admin/automation`

Features:
- View all scheduled jobs
- See last execution time
- Run jobs manually
- View recent logs

### Email Reports

Configure daily email reports:
```php
$schedule->command('report:daily')
    ->daily()
    ->sendOutputTo('admin@example.com');
```

---

## Important Notes

⚠️ **DO NOT** run `schedule:run` more frequently than every minute  
⚠️ **ALWAYS** test jobs manually before relying on cron  
⚠️ **MONITOR** logs during first 48 hours after setup  
⚠️ **BACKUP** database before running cleanup jobs  

---

**Setup complete? Test with:** `php artisan schedule:run-all` ✅
