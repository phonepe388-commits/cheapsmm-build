<?php

/**
 * Laravel Application Entry Point - cPanel Optimized
 * 
 * This file is configured for cPanel shared hosting where:
 * - Application files are in: /home/username/cheapsmm/
 * - Public files are in: /home/username/public_html/
 */

define('LARAVEL_START', microtime(true));

// Maintenance Mode Check
if (file_exists($maintenance = __DIR__.'/../cheapsmm/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register Composer Autoloader
require __DIR__.'/../cheapsmm/vendor/autoload.php';

// Bootstrap Laravel Application
$app = require_once __DIR__.'/../cheapsmm/bootstrap/app.php';

// Handle Request
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$response = $kernel->handle(
    $request = Illuminate\Http\Request::capture()
);
$response->send();
$kernel->terminate($request, $response);
