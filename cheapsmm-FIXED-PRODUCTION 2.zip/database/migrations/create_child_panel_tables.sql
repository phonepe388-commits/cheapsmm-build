-- Enhanced child_panels table
ALTER TABLE `child_panels` 
ADD COLUMN IF NOT EXISTS `subdomain` varchar(255) DEFAULT NULL AFTER `domain`,
ADD COLUMN IF NOT EXISTS `favicon` varchar(255) DEFAULT NULL AFTER `logo`,
ADD COLUMN IF NOT EXISTS `secondary_color` varchar(7) DEFAULT NULL AFTER `primary_color`,
ADD COLUMN IF NOT EXISTS `credit_limit` decimal(10,2) DEFAULT '0.00' AFTER `balance`,
ADD COLUMN IF NOT EXISTS `markup_percentage` decimal(5,2) DEFAULT '20.00' AFTER `credit_limit`,
ADD COLUMN IF NOT EXISTS `settings` text DEFAULT NULL AFTER `markup_percentage`,
ADD COLUMN IF NOT EXISTS `custom_css` text DEFAULT NULL AFTER `settings`,
ADD COLUMN IF NOT EXISTS `custom_footer` text DEFAULT NULL AFTER `custom_css`,
ADD COLUMN IF NOT EXISTS `support_email` varchar(255) DEFAULT NULL AFTER `custom_footer`,
ADD COLUMN IF NOT EXISTS `support_phone` varchar(50) DEFAULT NULL AFTER `support_email`,
ADD COLUMN IF NOT EXISTS `currency` varchar(3) DEFAULT 'USD' AFTER `support_phone`,
ADD COLUMN IF NOT EXISTS `language` varchar(5) DEFAULT 'en' AFTER `currency`,
ADD COLUMN IF NOT EXISTS `timezone` varchar(50) DEFAULT 'UTC' AFTER `language`,
ADD COLUMN IF NOT EXISTS `ssl_enabled` tinyint(1) DEFAULT '0' AFTER `timezone`,
ADD COLUMN IF NOT EXISTS `api_enabled` tinyint(1) DEFAULT '1' AFTER `ssl_enabled`;

-- Create child_panel_users table
CREATE TABLE IF NOT EXISTS `child_panel_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `api_key` varchar(100) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `child_panel_users_email_unique` (`child_panel_id`, `email`),
  KEY `child_panel_users_child_panel_id_foreign` (`child_panel_id`),
  CONSTRAINT `child_panel_users_child_panel_id_foreign` FOREIGN KEY (`child_panel_id`) REFERENCES `child_panels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create child_panel_service_pricings table
CREATE TABLE IF NOT EXISTS `child_panel_service_pricings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned NOT NULL,
  `price_per_1000` decimal(10,2) NOT NULL,
  `min_quantity` int DEFAULT NULL,
  `max_quantity` int DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `child_panel_service_unique` (`child_panel_id`, `service_id`),
  KEY `child_panel_service_pricings_child_panel_id_foreign` (`child_panel_id`),
  KEY `child_panel_service_pricings_service_id_foreign` (`service_id`),
  CONSTRAINT `child_panel_service_pricings_child_panel_id_foreign` FOREIGN KEY (`child_panel_id`) REFERENCES `child_panels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `child_panel_service_pricings_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add child panel foreign keys to orders table
ALTER TABLE `orders`
ADD COLUMN IF NOT EXISTS `child_panel_id` bigint unsigned DEFAULT NULL AFTER `user_id`,
ADD COLUMN IF NOT EXISTS `child_panel_user_id` bigint unsigned DEFAULT NULL AFTER `child_panel_id`,
ADD INDEX `orders_child_panel_id_index` (`child_panel_id`),
ADD INDEX `orders_child_panel_user_id_index` (`child_panel_user_id`);
