-- Create campaigns table
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `segment_id` bigint unsigned DEFAULT NULL,
  `sent_count` int DEFAULT '0',
  `status` enum('draft','sent','scheduled') DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaigns_segment_id_foreign` (`segment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create user_tags pivot table
CREATE TABLE IF NOT EXISTS `user_tags` (
  `user_id` bigint unsigned NOT NULL,
  `customer_tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`, `customer_tag_id`),
  KEY `user_tags_customer_tag_id_foreign` (`customer_tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Update customer_segments table
ALTER TABLE `customer_segments` 
ADD COLUMN IF NOT EXISTS `criteria` text DEFAULT NULL AFTER `name`,
ADD COLUMN IF NOT EXISTS `user_count` int DEFAULT '0' AFTER `criteria`;

-- Update customer_tags table structure if needed
ALTER TABLE `customer_tags`
ADD COLUMN IF NOT EXISTS `color` varchar(7) DEFAULT NULL AFTER `name`,
ADD COLUMN IF NOT EXISTS `description` text DEFAULT NULL AFTER `color`;
