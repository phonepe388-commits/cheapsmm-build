-- Add language column to users table
ALTER TABLE `users` 
ADD COLUMN `language` varchar(5) DEFAULT 'en' AFTER `email`;

-- Add index for faster lookups
ALTER TABLE `users` 
ADD INDEX `users_language_index` (`language`);
