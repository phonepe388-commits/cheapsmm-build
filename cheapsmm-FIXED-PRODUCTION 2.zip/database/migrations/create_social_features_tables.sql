-- Update service_reviews table
ALTER TABLE `service_reviews`
ADD COLUMN IF NOT EXISTS `status` enum('pending','approved','rejected') DEFAULT 'pending' AFTER `comment`,
ADD COLUMN IF NOT EXISTS `helpful_count` int DEFAULT '0' AFTER `status`;

-- Ensure achievements table exists with all columns
CREATE TABLE IF NOT EXISTS `achievements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `reward_amount` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `achievements_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ensure daily_rewards table exists
CREATE TABLE IF NOT EXISTS `daily_rewards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `streak_days` int DEFAULT '1',
  `claimed_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `daily_rewards_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
