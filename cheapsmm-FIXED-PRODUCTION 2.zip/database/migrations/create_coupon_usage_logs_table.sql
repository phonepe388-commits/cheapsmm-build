CREATE TABLE IF NOT EXISTS `coupon_usage_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `original_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usage_type` varchar(50) DEFAULT 'order',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_usage_logs_coupon_id_foreign` (`coupon_id`),
  KEY `coupon_usage_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `coupon_usage_logs_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usage_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
