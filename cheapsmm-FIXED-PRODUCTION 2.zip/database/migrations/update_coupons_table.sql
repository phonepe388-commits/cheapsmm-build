-- Update coupons table structure for comprehensive coupon system
ALTER TABLE `coupons` 
ADD COLUMN IF NOT EXISTS `description` varchar(255) DEFAULT NULL AFTER `code`,
ADD COLUMN IF NOT EXISTS `max_discount` decimal(10,2) DEFAULT NULL AFTER `value`,
ADD COLUMN IF NOT EXISTS `max_uses_per_user` int DEFAULT NULL AFTER `max_uses`,
MODIFY COLUMN `min_amount` decimal(10,2) DEFAULT NULL,
MODIFY COLUMN `max_uses` int DEFAULT NULL,
MODIFY COLUMN `uses` int NOT NULL DEFAULT '0';
