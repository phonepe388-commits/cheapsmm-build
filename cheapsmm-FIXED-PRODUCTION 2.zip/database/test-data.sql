-- ============================================================================
-- CHEAPSMM PANEL - TEST DATA
-- Use this to populate database with sample data for testing
-- ============================================================================

-- Add test balance to user
UPDATE users SET balance = 100.00 WHERE id = 1;

-- Add test categories
INSERT INTO categories (name, slug, description, status, display_order) VALUES
('Instagram', 'instagram', 'Instagram services', 'active', 1),
('Facebook', 'facebook', 'Facebook services', 'active', 2),
('YouTube', 'youtube', 'YouTube services', 'active', 3),
('TikTok', 'tiktok', 'TikTok services', 'active', 4),
('Twitter', 'twitter', 'Twitter services', 'active', 5);

-- Add test services
INSERT INTO services (category_id, name, description, type, price, min_quantity, max_quantity, average_time, dripfeed_enabled, status, display_order) VALUES
-- Instagram
(1, 'Instagram Followers - High Quality', 'Real looking followers, high retention', 'default', 2.50, 100, 10000, '1-2 hours', 1, 'active', 1),
(1, 'Instagram Likes', 'Instant likes delivery', 'default', 0.50, 50, 5000, '5-10 minutes', 0, 'active', 2),
(1, 'Instagram Views', 'Video views', 'default', 0.30, 100, 100000, '1 hour', 0, 'active', 3),
(1, 'Instagram Comments', 'Custom comments', 'default', 5.00, 10, 1000, '1-3 hours', 0, 'active', 4),

-- Facebook
(2, 'Facebook Page Likes', 'Real page likes', 'default', 3.00, 100, 10000, '2-4 hours', 1, 'active', 1),
(2, 'Facebook Post Likes', 'Instant post likes', 'default', 0.80, 50, 5000, '10-30 minutes', 0, 'active', 2),
(2, 'Facebook Followers', 'Profile followers', 'default', 2.00, 100, 5000, '1-2 hours', 0, 'active', 3),

-- YouTube
(3, 'YouTube Views', 'High retention views', 'default', 1.50, 1000, 100000, '24-48 hours', 1, 'active', 1),
(3, 'YouTube Likes', 'Real likes', 'default', 4.00, 50, 5000, '1-3 hours', 0, 'active', 2),
(3, 'YouTube Subscribers', 'Permanent subscribers', 'default', 8.00, 50, 2000, '24-72 hours', 1, 'active', 3),

-- TikTok
(4, 'TikTok Followers', 'Real followers', 'default', 3.50, 100, 10000, '1-3 hours', 1, 'active', 1),
(4, 'TikTok Likes', 'Instant likes', 'default', 1.00, 100, 10000, '10-30 minutes', 0, 'active', 2),
(4, 'TikTok Views', 'High quality views', 'default', 0.40, 1000, 100000, '1-2 hours', 0, 'active', 3),

-- Twitter
(5, 'Twitter Followers', 'Real active followers', 'default', 4.00, 50, 5000, '2-6 hours', 1, 'active', 1),
(5, 'Twitter Retweets', 'Instant retweets', 'default', 1.50, 50, 2000, '30-60 minutes', 0, 'active', 2),
(5, 'Twitter Likes', 'Post likes', 'default', 1.00, 50, 5000, '15-30 minutes', 0, 'active', 3);

-- Add a test user (in addition to admin)
INSERT INTO users (name, email, password, balance, status, user_tier_id, currency_id, language_id, email_verified_at)
VALUES ('Test User', 'test@cheapsmm.fun', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 50.00, 'active', 1, 1, 1, NOW());
-- Password: password

-- Add test transaction for the test user
INSERT INTO transactions (user_id, type, amount, currency, balance_before, balance_after, description)
VALUES (LAST_INSERT_ID(), 'credit', 50.00, 'USD', 0.00, 50.00, 'Initial test balance');

-- ============================================================================
-- VERIFICATION QUERIES
-- Run these to verify test data was added correctly
-- ============================================================================

-- Check categories
SELECT COUNT(*) as category_count FROM categories WHERE status = 'active';
-- Should return 5

-- Check services
SELECT COUNT(*) as service_count FROM services WHERE status = 'active';
-- Should return 15

-- Check users
SELECT id, name, email, balance, status FROM users;
-- Should show admin + test user

-- Check service pricing
SELECT 
    c.name as category,
    s.name as service,
    s.price,
    s.min_quantity,
    s.max_quantity,
    s.dripfeed_enabled
FROM services s
JOIN categories c ON s.category_id = c.id
WHERE s.status = 'active'
ORDER BY c.display_order, s.display_order;

-- ============================================================================
-- END OF TEST DATA
-- ============================================================================
