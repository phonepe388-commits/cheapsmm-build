<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaymentMethodSeeder extends Seeder
{
    public function run()
    {
        $methods = [
            [
                'name' => 'Stripe',
                'code' => 'stripe',
                'type' => 'automatic',
                'description' => 'Pay securely with Credit/Debit Card',
                'logo' => '/images/payment-methods/stripe.png',
                'status' => 'active',
                'sort_order' => 1,
                'min_amount' => 10,
                'max_amount' => 10000,
                'fee_type' => 'percentage',
                'fee_value' => 2.9,
                'fee_fixed' => 0.30,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'PayPal',
                'code' => 'paypal',
                'type' => 'automatic',
                'description' => 'Pay with your PayPal account',
                'logo' => '/images/payment-methods/paypal.png',
                'status' => 'active',
                'sort_order' => 2,
                'min_amount' => 10,
                'max_amount' => 10000,
                'fee_type' => 'percentage',
                'fee_value' => 3.5,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Razorpay',
                'code' => 'razorpay',
                'type' => 'automatic',
                'description' => 'UPI, Cards, NetBanking & More',
                'logo' => '/images/payment-methods/razorpay.png',
                'status' => 'active',
                'sort_order' => 3,
                'min_amount' => 10,
                'max_amount' => 10000,
                'fee_type' => 'percentage',
                'fee_value' => 2.0,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Bank Transfer',
                'code' => 'bank_transfer',
                'type' => 'manual',
                'description' => 'Direct bank transfer (requires manual approval)',
                'logo' => '/images/payment-methods/bank.png',
                'status' => 'active',
                'sort_order' => 4,
                'min_amount' => 50,
                'max_amount' => 50000,
                'fee_type' => 'fixed',
                'fee_value' => 0,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Cryptocurrency',
                'code' => 'crypto',
                'type' => 'automatic',
                'description' => 'Pay with Bitcoin, Ethereum, USDT',
                'logo' => '/images/payment-methods/crypto.png',
                'status' => 'inactive',
                'sort_order' => 5,
                'min_amount' => 20,
                'max_amount' => 100000,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Perfect Money',
                'code' => 'perfect_money',
                'type' => 'automatic',
                'description' => 'Pay with Perfect Money',
                'logo' => '/images/payment-methods/perfect-money.png',
                'status' => 'inactive',
                'sort_order' => 6,
                'min_amount' => 10,
                'max_amount' => 10000,
                'created_at' => now(),
                'updated_at' => now()
            ],
        ];

        DB::table('payment_methods')->insert($methods);
    }
}
