<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CurrencySeeder extends Seeder
{
    public function run()
    {
        $currencies = [
            [
                'code' => 'USD',
                'name' => 'US Dollar',
                'symbol' => '$',
                'symbol_position' => 'before',
                'exchange_rate' => 1.00,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 1,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'EUR',
                'name' => 'Euro',
                'symbol' => '€',
                'symbol_position' => 'before',
                'exchange_rate' => 0.92,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 2,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'GBP',
                'name' => 'British Pound',
                'symbol' => '£',
                'symbol_position' => 'before',
                'exchange_rate' => 0.79,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 3,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'INR',
                'name' => 'Indian Rupee',
                'symbol' => '₹',
                'symbol_position' => 'before',
                'exchange_rate' => 83.12,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 4,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'AUD',
                'name' => 'Australian Dollar',
                'symbol' => 'A$',
                'symbol_position' => 'before',
                'exchange_rate' => 1.53,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 5,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'CAD',
                'name' => 'Canadian Dollar',
                'symbol' => 'C$',
                'symbol_position' => 'before',
                'exchange_rate' => 1.35,
                'decimal_places' => 2,
                'is_popular' => true,
                'status' => 'active',
                'sort_order' => 6,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'BRL',
                'name' => 'Brazilian Real',
                'symbol' => 'R$',
                'symbol_position' => 'before',
                'exchange_rate' => 4.97,
                'decimal_places' => 2,
                'is_popular' => false,
                'status' => 'active',
                'sort_order' => 7,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'JPY',
                'name' => 'Japanese Yen',
                'symbol' => '¥',
                'symbol_position' => 'before',
                'exchange_rate' => 149.50,
                'decimal_places' => 0,
                'is_popular' => false,
                'status' => 'active',
                'sort_order' => 8,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'CNY',
                'name' => 'Chinese Yuan',
                'symbol' => '¥',
                'symbol_position' => 'before',
                'exchange_rate' => 7.24,
                'decimal_places' => 2,
                'is_popular' => false,
                'status' => 'active',
                'sort_order' => 9,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
            [
                'code' => 'AED',
                'name' => 'UAE Dirham',
                'symbol' => 'د.إ',
                'symbol_position' => 'before',
                'exchange_rate' => 3.67,
                'decimal_places' => 2,
                'is_popular' => false,
                'status' => 'active',
                'sort_order' => 10,
                'created_at' => now(),
                'updated_at' => now(),
                'last_updated' => now()
            ],
        ];

        DB::table('currencies')->insert($currencies);
    }
}
