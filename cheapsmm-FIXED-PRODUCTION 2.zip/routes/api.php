<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApiController;

/*
|--------------------------------------------------------------------------
| API Routes (v2 - Standard SMM Panel API)
|--------------------------------------------------------------------------
*/

Route::middleware('api.auth')->prefix('v2')->group(function () {
    Route::get('balance', [ApiController::class, 'balance']);
    Route::get('services', [ApiController::class, 'services']);
    Route::post('add', [ApiController::class, 'add']);
    Route::post('status', [ApiController::class, 'status']);
    Route::post('add-multi', [ApiController::class, 'addMulti']);
    Route::post('refill', [ApiController::class, 'refill']);
    Route::post('refill-status', [ApiController::class, 'refillStatus']);
    Route::post('cancel', [ApiController::class, 'cancel']);
    Route::get('orders', [ApiController::class, 'orders']);
});
