<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\User\DashboardController;
use App\Http\Controllers\User\OrderController;
use App\Http\Controllers\User\ServiceController;
use App\Http\Controllers\User\PaymentController;
use App\Http\Controllers\User\TicketController;
use App\Http\Controllers\User\ProfileController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Guest Routes
Route::get('/', function () {
    return view('welcome');
})->name('home');

Route::get('/about', function () {
    return view('pages.about');
})->name('about');

Route::get('/terms', function () {
    return view('pages.terms');
})->name('terms');

Route::get('/privacy', function () {
    return view('pages.privacy');
})->name('privacy');

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);
    
    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RegisterController::class, 'register']);
    
    Route::get('/password/reset', [PasswordResetController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('/password/email', [PasswordResetController::class, 'sendResetLinkEmail'])->name('password.email');
    Route::get('/password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
    Route::post('/password/reset', [PasswordResetController::class, 'reset'])->name('password.update');
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Email Verification
Route::get('/email/verify', [EmailVerificationController::class, 'show'])->name('verification.notice');
Route::get('/email/verify/{id}/{hash}', [EmailVerificationController::class, 'verify'])->name('verification.verify');
Route::post('/email/resend', [EmailVerificationController::class, 'resend'])->name('verification.resend');

/*
|--------------------------------------------------------------------------
| User Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'check.user.status'])->prefix('user')->name('user.')->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Orders
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/new', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
    Route::post('/orders/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel');
    Route::post('/orders/{order}/refill', [OrderController::class, 'refill'])->name('orders.refill');
    
    // AJAX routes for orders
    Route::get('/orders/get-services', [OrderController::class, 'getServices'])->name('orders.get-services');
    Route::get('/orders/calculate-price', [OrderController::class, 'calculatePrice'])->name('orders.calculate-price');
    
    // Services
    Route::get('/services', [ServiceController::class, 'index'])->name('services.index');
    Route::get('/services/{service}', [ServiceController::class, 'show'])->name('services.show');
    Route::get('/services/search', [ServiceController::class, 'search'])->name('services.search');
    
    // Payments
    Route::get('/payments', [PaymentController::class, 'index'])->name('payments.index');
    Route::get('/payments/add-funds', [PaymentController::class, 'create'])->name('payments.add-funds');
    Route::post('/payments', [PaymentController::class, 'store'])->name('payments.store');
    Route::get('/payments/{payment}', [PaymentController::class, 'show'])->name('payments.show');
    
    // Tickets
    Route::get('/tickets', [TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/new', [TicketController::class, 'create'])->name('tickets.create');
    Route::post('/tickets', [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{ticket}', [TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [TicketController::class, 'reply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/close', [TicketController::class, 'close'])->name('tickets.close');
    
    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::post('/profile/avatar', [ProfileController::class, 'uploadAvatar'])->name('profile.avatar');
    
    // 2FA
    Route::get('/profile/2fa', [ProfileController::class, 'twoFactorSettings'])->name('profile.2fa');
    Route::post('/profile/2fa/enable', [ProfileController::class, 'enableTwoFactor'])->name('profile.2fa.enable');
    Route::post('/profile/2fa/disable', [ProfileController::class, 'disableTwoFactor'])->name('profile.2fa.disable');
    
    // API Keys
    Route::get('/api-keys', [ApiKeyController::class, 'index'])->name('api-keys.index');
    Route::post('/api-keys', [ApiKeyController::class, 'store'])->name('api-keys.store');
    Route::delete('/api-keys/{apiClient}', [ApiKeyController::class, 'destroy'])->name('api-keys.destroy');
    
    // Referrals
    Route::get('/referrals', [ReferralController::class, 'index'])->name('referrals.index');
    
    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/{notification}/read', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllAsRead'])->name('notifications.read-all');
});

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [Admin\DashboardController::class, 'index'])->name('dashboard');
    
    // Users
    Route::resource('users', Admin\UserController::class);
    Route::post('/users/{user}/ban', [Admin\UserController::class, 'ban'])->name('users.ban');
    Route::post('/users/{user}/suspend', [Admin\UserController::class, 'suspend'])->name('users.suspend');
    Route::post('/users/{user}/activate', [Admin\UserController::class, 'activate'])->name('users.activate');
    Route::post('/users/{user}/adjust-balance', [Admin\UserController::class, 'adjustBalance'])->name('users.adjust-balance');
    
    // Orders
    Route::resource('orders', Admin\OrderController::class)->only(['index', 'show', 'update']);
    Route::post('/orders/{order}/cancel', [Admin\OrderController::class, 'cancel'])->name('orders.cancel');
    Route::post('/orders/{order}/refund', [Admin\OrderController::class, 'refund'])->name('orders.refund');
    
    // Services
    Route::resource('services', Admin\ServiceController::class);
    Route::post('/services/sync', [Admin\ServiceController::class, 'syncFromAPI'])->name('services.sync');
    
    // Categories
    Route::resource('categories', Admin\CategoryController::class);
    
    // Payments
    Route::get('/payments', [Admin\PaymentController::class, 'index'])->name('payments.index');
    Route::get('/payments/{payment}', [Admin\PaymentController::class, 'show'])->name('payments.show');
    Route::post('/payments/{payment}/approve', [Admin\PaymentController::class, 'approve'])->name('payments.approve');
    Route::post('/payments/{payment}/reject', [Admin\PaymentController::class, 'reject'])->name('payments.reject');
    
    // Payment Methods
    Route::resource('payment-methods', Admin\PaymentMethodController::class);
    
    // Tickets
    Route::get('/tickets', [Admin\TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/{ticket}', [Admin\TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [Admin\TicketController::class, 'reply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/assign', [Admin\TicketController::class, 'assign'])->name('tickets.assign');
    Route::post('/tickets/{ticket}/close', [Admin\TicketController::class, 'close'])->name('tickets.close');
    
    // API Providers
    Route::resource('api-providers', Admin\ApiProviderController::class);
    Route::post('/api-providers/{apiProvider}/test', [Admin\ApiProviderController::class, 'test'])->name('api-providers.test');
    
    // Settings
    Route::get('/settings', [Admin\SettingController::class, 'index'])->name('settings.index');
    Route::put('/settings', [Admin\SettingController::class, 'update'])->name('settings.update');
    
    // Error Logs
    Route::get('/logs/errors', [Admin\ErrorLogController::class, 'index'])->name('logs.errors');
    Route::delete('/logs/errors/{errorLog}', [Admin\ErrorLogController::class, 'destroy'])->name('logs.errors.destroy');
    Route::post('/logs/errors/clear', [Admin\ErrorLogController::class, 'clear'])->name('logs.errors.clear');
    
    // Activity Logs
    Route::get('/logs/activity', [Admin\ActivityLogController::class, 'index'])->name('logs.activity');
    
    // Reports
    Route::get('/reports', [Admin\ReportController::class, 'index'])->name('reports.index');
    Route::get('/reports/revenue', [Admin\ReportController::class, 'revenue'])->name('reports.revenue');
    Route::get('/reports/users', [Admin\ReportController::class, 'users'])->name('reports.users');
    Route::get('/reports/services', [Admin\ReportController::class, 'services'])->name('reports.services');
    
    // Backups
    Route::get('/backups', [Admin\BackupController::class, 'index'])->name('backups.index');
    Route::post('/backups', [Admin\BackupController::class, 'create'])->name('backups.create');
    Route::get('/backups/{backup}/download', [Admin\BackupController::class, 'download'])->name('backups.download');
    Route::delete('/backups/{backup}', [Admin\BackupController::class, 'destroy'])->name('backups.destroy');
});

// Payment Gateway Routes
Route::group(['prefix' => 'user/payments', 'middleware' => 'auth'], function() {
    Route::get('/success', [App\Http\Controllers\User\PaymentController::class, 'successPage'])->name('user.payments.success-page');
    Route::post('/manual/submit', [App\Http\Controllers\User\PaymentController::class, 'submitManualProof'])->name('user.payments.manual.submit');
    Route::get('/paypal/success', [App\Http\Controllers\User\PaymentController::class, 'paypalSuccess'])->name('user.payments.paypal.success');
    Route::post('/razorpay/verify', [App\Http\Controllers\User\PaymentController::class, 'razorpayVerify'])->name('user.payments.razorpay.verify');
});

// Payment Webhooks (no auth required)
Route::post('/webhooks/stripe', [App\Http\Controllers\User\PaymentController::class, 'stripeWebhook'])->name('webhooks.stripe');
Route::post('/webhooks/paypal', [App\Http\Controllers\User\PaymentController::class, 'paypalWebhook'])->name('webhooks.paypal');
Route::post('/webhooks/razorpay', [App\Http\Controllers\User\PaymentController::class, 'razorpayWebhook'])->name('webhooks.razorpay');

// Admin Payment Management
Route::group(['prefix' => 'admin/payments', 'middleware' => 'auth:admin'], function() {
    Route::get('/pending', [App\Http\Controllers\Admin\PaymentController::class, 'pending'])->name('admin.payments.pending');
    Route::post('/{payment}/approve', [App\Http\Controllers\Admin\PaymentController::class, 'approve'])->name('admin.payments.approve');
    Route::post('/{payment}/reject', [App\Http\Controllers\Admin\PaymentController::class, 'reject'])->name('admin.payments.reject');
    Route::post('/{payment}/refund', [App\Http\Controllers\Admin\PaymentController::class, 'refund'])->name('admin.payments.refund');
});

// Currency Routes
Route::post('/currency/set', [App\Http\Controllers\User\CurrencyController::class, 'setCurrency'])->name('user.currency.set');
Route::get('/currency/rate/{currency}', [App\Http\Controllers\User\CurrencyController::class, 'getRate'])->name('user.currency.rate');
Route::get('/currency/list', [App\Http\Controllers\User\CurrencyController::class, 'getCurrencies'])->name('user.currency.list');
Route::post('/currency/convert', [App\Http\Controllers\User\CurrencyController::class, 'convert'])->name('user.currency.convert');

// Admin Currency Management
Route::group(['prefix' => 'admin/currencies', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\CurrencyController::class, 'index'])->name('admin.currencies.index');
    Route::get('/create', [App\Http\Controllers\Admin\CurrencyController::class, 'create'])->name('admin.currencies.create');
    Route::post('/', [App\Http\Controllers\Admin\CurrencyController::class, 'store'])->name('admin.currencies.store');
    Route::get('/{currency}/edit', [App\Http\Controllers\Admin\CurrencyController::class, 'edit'])->name('admin.currencies.edit');
    Route::put('/{currency}', [App\Http\Controllers\Admin\CurrencyController::class, 'update'])->name('admin.currencies.update');
    Route::delete('/{currency}', [App\Http\Controllers\Admin\CurrencyController::class, 'destroy'])->name('admin.currencies.destroy');
    Route::post('/update-rates', [App\Http\Controllers\Admin\CurrencyController::class, 'updateRates'])->name('admin.currencies.update-rates');
    Route::post('/seed-defaults', [App\Http\Controllers\Admin\CurrencyController::class, 'seedDefaults'])->name('admin.currencies.seed-defaults');
    Route::post('/{currency}/toggle-status', [App\Http\Controllers\Admin\CurrencyController::class, 'toggleStatus'])->name('admin.currencies.toggle-status');
});

// Currency Switching
Route::post('/currency/switch', [App\Http\Controllers\CurrencyController::class, 'switch'])->name('currency.switch');
Route::get('/currencies', [App\Http\Controllers\CurrencyController::class, 'index'])->name('currencies.index');

// Admin Currency Management
Route::group(['prefix' => 'admin/currencies', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\CurrencyController::class, 'index'])->name('admin.currencies.index');
    Route::get('/create', [App\Http\Controllers\Admin\CurrencyController::class, 'create'])->name('admin.currencies.create');
    Route::post('/', [App\Http\Controllers\Admin\CurrencyController::class, 'store'])->name('admin.currencies.store');
    Route::get('/{currency}/edit', [App\Http\Controllers\Admin\CurrencyController::class, 'edit'])->name('admin.currencies.edit');
    Route::put('/{currency}', [App\Http\Controllers\Admin\CurrencyController::class, 'update'])->name('admin.currencies.update');
    Route::delete('/{currency}', [App\Http\Controllers\Admin\CurrencyController::class, 'destroy'])->name('admin.currencies.destroy');
    Route::post('/update-rates', [App\Http\Controllers\Admin\CurrencyController::class, 'updateRates'])->name('admin.currencies.update-rates');
});

// Mass Order System
Route::group(['prefix' => 'user/orders/mass', 'middleware' => 'auth'], function() {
    Route::get('/create', [App\Http\Controllers\User\MassOrderController::class, 'create'])->name('user.orders.mass.create');
    Route::post('/validate', [App\Http\Controllers\User\MassOrderController::class, 'validate'])->name('user.orders.mass.validate');
    Route::post('/process', [App\Http\Controllers\User\MassOrderController::class, 'process'])->name('user.orders.mass.process');
    Route::post('/cancel', [App\Http\Controllers\User\MassOrderController::class, 'cancel'])->name('user.orders.mass.cancel');
    Route::get('/template', [App\Http\Controllers\User\MassOrderController::class, 'downloadTemplate'])->name('user.orders.mass.template');
    Route::get('/results/download', [App\Http\Controllers\User\MassOrderController::class, 'downloadResults'])->name('user.orders.mass.results.download');
});

// Export Routes
Route::group(['middleware' => 'auth'], function() {
    // User exports
    Route::get('/user/orders/export', [App\Http\Controllers\User\OrderController::class, 'export'])->name('user.orders.export');
});

Route::group(['middleware' => 'auth:admin'], function() {
    // Admin exports
    Route::get('/admin/orders/export', [App\Http\Controllers\Admin\OrderController::class, 'export'])->name('admin.orders.export');
    Route::get('/admin/payments/export', [App\Http\Controllers\Admin\PaymentController::class, 'export'])->name('admin.payments.export');
    Route::get('/admin/users/export', [App\Http\Controllers\Admin\UserController::class, 'export'])->name('admin.users.export');
    
    // Reports
    Route::get('/admin/reports', [App\Http\Controllers\Admin\ReportsController::class, 'index'])->name('admin.reports.index');
    Route::get('/admin/reports/summary', [App\Http\Controllers\Admin\ReportsController::class, 'summary'])->name('admin.reports.summary');
});

// Referral Routes
Route::middleware('auth')->group(function() {
    Route::get('/referrals', [App\Http\Controllers\User\ReferralController::class, 'index'])->name('user.referrals.index');
    Route::post('/referrals/withdraw', [App\Http\Controllers\User\ReferralController::class, 'withdraw'])->name('user.referrals.withdraw');
});

// Marketing & Coupons (Admin)
Route::middleware('auth:admin')->group(function() {
    Route::get('/admin/coupons', [App\Http\Controllers\Admin\CouponController::class, 'index'])->name('admin.coupons.index');
    Route::post('/admin/coupons', [App\Http\Controllers\Admin\CouponController::class, 'store'])->name('admin.coupons.store');
});

// Child Panels (Admin)
Route::middleware('auth:admin')->group(function() {
    Route::get('/admin/child-panels', [App\Http\Controllers\Admin\ChildPanelController::class, 'index'])->name('admin.child-panels.index');
    Route::post('/admin/child-panels', [App\Http\Controllers\Admin\ChildPanelController::class, 'store'])->name('admin.child-panels.store');
});

// CRM (Admin)
Route::middleware('auth:admin')->group(function() {
    Route::get('/admin/crm/segments', [App\Http\Controllers\Admin\CrmController::class, 'segments'])->name('admin.crm.segments');
    Route::post('/admin/crm/segments', [App\Http\Controllers\Admin\CrmController::class, 'createSegment'])->name('admin.crm.segments.store');
    Route::get('/admin/crm/campaigns', [App\Http\Controllers\Admin\CrmController::class, 'campaigns'])->name('admin.crm.campaigns');
});

// Tools (Admin)
Route::middleware('auth:admin')->group(function() {
    Route::post('/admin/tools/bulk-user-update', [App\Http\Controllers\Admin\ToolsController::class, 'bulkUserUpdate'])->name('admin.tools.bulk-user');
    Route::post('/admin/tools/cleanup', [App\Http\Controllers\Admin\ToolsController::class, 'dataCleanup'])->name('admin.tools.cleanup');
});

// Blog (Public)
Route::get('/blog', [App\Http\Controllers\BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{slug}', [App\Http\Controllers\BlogController::class, 'show'])->name('blog.show');

// Blog (Admin)
Route::middleware('auth:admin')->group(function() {
    Route::get('/admin/blog', [App\Http\Controllers\Admin\BlogController::class, 'index'])->name('admin.blog.index');
    Route::post('/admin/blog', [App\Http\Controllers\Admin\BlogController::class, 'store'])->name('admin.blog.store');
});

// Reviews (User)
Route::middleware('auth')->group(function() {
    Route::post('/reviews', [App\Http\Controllers\User\ReviewController::class, 'store'])->name('reviews.store');
});

// Language Switcher
Route::post('/language/switch', function(\Illuminate\Http\Request $request) {
    app(\App\Services\LanguageService::class)->setLanguage($request->language);
    return back();
})->name('language.switch');

// API Management Routes
Route::group(['prefix' => 'user/api', 'middleware' => 'auth'], function() {
    Route::get('/docs', [App\Http\Controllers\User\ApiKeyController::class, 'documentation'])->name('user.api.docs');
    Route::post('/generate', [App\Http\Controllers\User\ApiKeyController::class, 'generate'])->name('user.api.generate');
    Route::post('/regenerate', [App\Http\Controllers\User\ApiKeyController::class, 'regenerate'])->name('user.api.regenerate');
    Route::post('/deactivate', [App\Http\Controllers\User\ApiKeyController::class, 'deactivate'])->name('user.api.deactivate');
});

// Referral System Routes
Route::group(['prefix' => 'user/referrals', 'middleware' => 'auth'], function() {
    Route::get('/', [App\Http\Controllers\User\ReferralController::class, 'index'])->name('user.referrals.index');
    Route::post('/withdraw', [App\Http\Controllers\User\ReferralController::class, 'withdraw'])->name('user.referrals.withdraw');
});

// Coupon Management Routes
Route::group(['prefix' => 'admin/coupons', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\CouponController::class, 'index'])->name('admin.coupons.index');
    Route::get('/create', [App\Http\Controllers\Admin\CouponController::class, 'create'])->name('admin.coupons.create');
    Route::post('/', [App\Http\Controllers\Admin\CouponController::class, 'store'])->name('admin.coupons.store');
    Route::get('/{coupon}/edit', [App\Http\Controllers\Admin\CouponController::class, 'edit'])->name('admin.coupons.edit');
    Route::put('/{coupon}', [App\Http\Controllers\Admin\CouponController::class, 'update'])->name('admin.coupons.update');
    Route::delete('/{coupon}', [App\Http\Controllers\Admin\CouponController::class, 'destroy'])->name('admin.coupons.destroy');
    Route::get('/generate', [App\Http\Controllers\Admin\CouponController::class, 'generate'])->name('admin.coupons.generate');
});

// User coupon validation API
Route::post('/api/validate-coupon', [App\Http\Controllers\User\PaymentController::class, 'validateCoupon'])
    ->name('api.validate-coupon')
    ->middleware('auth');

// Language Switching Routes
Route::post('/language/switch', [App\Http\Controllers\LanguageController::class, 'switch'])->name('language.switch');
Route::get('/languages', [App\Http\Controllers\LanguageController::class, 'index'])->name('languages.index');

// Automation & Scheduled Jobs (Admin)
Route::group(['prefix' => 'admin/automation', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\AutomationController::class, 'index'])->name('admin.automation.index');
    Route::post('/run', [App\Http\Controllers\Admin\AutomationController::class, 'runJob'])->name('admin.automation.run');
});

// User Child Panel Routes
Route::group(['prefix' => 'child-panels', 'middleware' => 'auth'], function() {
    Route::get('/', [App\Http\Controllers\User\ChildPanelController::class, 'index'])->name('user.child-panels.index');
    Route::get('/create', [App\Http\Controllers\User\ChildPanelController::class, 'create'])->name('user.child-panels.create');
    Route::post('/', [App\Http\Controllers\User\ChildPanelController::class, 'store'])->name('user.child-panels.store');
    Route::get('/{childPanel}', [App\Http\Controllers\User\ChildPanelController::class, 'show'])->name('user.child-panels.show');
    Route::get('/{childPanel}/edit', [App\Http\Controllers\User\ChildPanelController::class, 'edit'])->name('user.child-panels.edit');
    Route::put('/{childPanel}', [App\Http\Controllers\User\ChildPanelController::class, 'update'])->name('user.child-panels.update');
    Route::delete('/{childPanel}', [App\Http\Controllers\User\ChildPanelController::class, 'destroy'])->name('user.child-panels.destroy');
    Route::get('/{childPanel}/pricing', [App\Http\Controllers\User\ChildPanelController::class, 'pricing'])->name('user.child-panels.pricing');
    Route::post('/{childPanel}/pricing', [App\Http\Controllers\User\ChildPanelController::class, 'updatePricing'])->name('user.child-panels.update-pricing');
    Route::post('/{childPanel}/add-funds', [App\Http\Controllers\User\ChildPanelController::class, 'addFunds'])->name('user.child-panels.add-funds');
});

// Admin Child Panel Routes
Route::group(['prefix' => 'admin/child-panels', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\ChildPanelController::class, 'index'])->name('admin.child-panels.index');
    Route::get('/{childPanel}', [App\Http\Controllers\Admin\ChildPanelController::class, 'show'])->name('admin.child-panels.show');
    Route::post('/{childPanel}/status', [App\Http\Controllers\Admin\ChildPanelController::class, 'updateStatus'])->name('admin.child-panels.update-status');
    Route::post('/{childPanel}/balance', [App\Http\Controllers\Admin\ChildPanelController::class, 'adjustBalance'])->name('admin.child-panels.adjust-balance');
    Route::delete('/{childPanel}', [App\Http\Controllers\Admin\ChildPanelController::class, 'destroy'])->name('admin.child-panels.destroy');
});

// Admin CRM Routes
Route::group(['prefix' => 'admin/crm', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\CrmController::class, 'index'])->name('admin.crm.index');
    Route::get('/segments', [App\Http\Controllers\Admin\CrmController::class, 'segments'])->name('admin.crm.segments');
    Route::post('/segments', [App\Http\Controllers\Admin\CrmController::class, 'createSegment'])->name('admin.crm.create-segment');
    Route::get('/tags', [App\Http\Controllers\Admin\CrmController::class, 'tags'])->name('admin.crm.tags');
    Route::post('/tags', [App\Http\Controllers\Admin\CrmController::class, 'tagUser'])->name('admin.crm.tag-user');
    Route::get('/customer/{user}', [App\Http\Controllers\Admin\CrmController::class, 'customerInsights'])->name('admin.crm.customer-insights');
    Route::get('/campaigns', [App\Http\Controllers\Admin\CrmController::class, 'campaigns'])->name('admin.crm.campaigns');
    Route::post('/campaigns', [App\Http\Controllers\Admin\CrmController::class, 'createCampaign'])->name('admin.crm.create-campaign');
    Route::post('/campaigns/{campaign}/send', [App\Http\Controllers\Admin\CrmController::class, 'sendCampaign'])->name('admin.crm.send-campaign');
});

// User Social Features
Route::group(['prefix' => 'social', 'middleware' => 'auth'], function() {
    Route::get('/leaderboard', [App\Http\Controllers\User\SocialController::class, 'leaderboard'])->name('user.social.leaderboard');
    Route::get('/achievements', [App\Http\Controllers\User\SocialController::class, 'achievements'])->name('user.social.achievements');
    Route::post('/daily-reward', [App\Http\Controllers\User\SocialController::class, 'dailyReward'])->name('user.social.daily-reward');
    Route::post('/review', [App\Http\Controllers\User\SocialController::class, 'submitReview'])->name('user.social.submit-review');
});

// Admin Backup Routes
Route::group(['prefix' => 'admin/backups', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\BackupController::class, 'index'])->name('admin.backups.index');
    Route::post('/database', [App\Http\Controllers\Admin\BackupController::class, 'createDatabaseBackup'])->name('admin.backups.create-database');
    Route::post('/files', [App\Http\Controllers\Admin\BackupController::class, 'createFilesBackup'])->name('admin.backups.create-files');
    Route::get('/{backup}/download', [App\Http\Controllers\Admin\BackupController::class, 'download'])->name('admin.backups.download');
    Route::post('/{backup}/restore', [App\Http\Controllers\Admin\BackupController::class, 'restore'])->name('admin.backups.restore');
    Route::delete('/{backup}', [App\Http\Controllers\Admin\BackupController::class, 'destroy'])->name('admin.backups.destroy');
});

// Public Blog Routes
Route::get('/blog', [App\Http\Controllers\BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{blog:slug}', [App\Http\Controllers\BlogController::class, 'show'])->name('blog.show');
Route::get('/page/{page:slug}', [App\Http\Controllers\BlogController::class, 'page'])->name('page.show');
Route::get('/faqs', [App\Http\Controllers\BlogController::class, 'faqs'])->name('faqs');

// Admin Blog Routes
Route::group(['prefix' => 'admin/blog', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\BlogController::class, 'index'])->name('admin.blog.index');
    Route::get('/create', [App\Http\Controllers\Admin\BlogController::class, 'create'])->name('admin.blog.create');
    Route::post('/', [App\Http\Controllers\Admin\BlogController::class, 'store'])->name('admin.blog.store');
    Route::get('/{blog}/edit', [App\Http\Controllers\Admin\BlogController::class, 'edit'])->name('admin.blog.edit');
    Route::put('/{blog}', [App\Http\Controllers\Admin\BlogController::class, 'update'])->name('admin.blog.update');
    Route::delete('/{blog}', [App\Http\Controllers\Admin\BlogController::class, 'destroy'])->name('admin.blog.destroy');
    Route::get('/pages', [App\Http\Controllers\Admin\BlogController::class, 'pages'])->name('admin.blog.pages');
    Route::post('/pages', [App\Http\Controllers\Admin\BlogController::class, 'storePage'])->name('admin.blog.store-page');
    Route::get('/faqs', [App\Http\Controllers\Admin\BlogController::class, 'faqs'])->name('admin.blog.faqs');
    Route::post('/faqs', [App\Http\Controllers\Admin\BlogController::class, 'storeFAQ'])->name('admin.blog.store-faq');
});

// Admin Webhook Routes
Route::group(['prefix' => 'admin/webhooks', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\WebhookController::class, 'index'])->name('admin.webhooks.index');
    Route::post('/', [App\Http\Controllers\Admin\WebhookController::class, 'store'])->name('admin.webhooks.store');
    Route::post('/{webhook}/test', [App\Http\Controllers\Admin\WebhookController::class, 'test'])->name('admin.webhooks.test');
    Route::delete('/{webhook}', [App\Http\Controllers\Admin\WebhookController::class, 'destroy'])->name('admin.webhooks.destroy');
});

// Admin AI Features
Route::group(['prefix' => 'admin/ai', 'middleware' => 'auth:admin'], function() {
    Route::get('/', [App\Http\Controllers\Admin\AIController::class, 'dashboard'])->name('admin.ai.dashboard');
});

// Crypto Payment Routes
Route::group(['prefix' => 'crypto', 'middleware' => 'auth'], function() {
    Route::get('/payment', [App\Http\Controllers\User\CryptoPaymentController::class, 'create'])->name('crypto.payment');
    Route::post('/payment', [App\Http\Controllers\User\CryptoPaymentController::class, 'store'])->name('crypto.payment.store');
});

// Invoice & Advanced Export Routes
Route::group(['middleware' => 'auth'], function() {
    Route::get('/invoice/{payment}', function(App\Models\Payment $payment) {
        $service = app(App\Services\InvoiceService::class);
        $path = $service->generateInvoice($payment);
        return response()->download($path);
    })->name('invoice.download');
});

Route::group(['prefix' => 'admin/export', 'middleware' => 'auth:admin'], function() {
    Route::post('/advanced', function(Illuminate\Http\Request $request) {
        $service = app(App\Services\AdvancedExportService::class);
        $path = $service->export(
            $request->input('type'),
            $request->input('filters', []),
            $request->input('format', 'csv')
        );
        return response()->download($path);
    })->name('admin.export.advanced');
});

// Public Pages
Route::get('/', function() { return view('public.home'); })->name('home');
Route::get('/about', function() { return view('public.about'); })->name('public.about');
Route::get('/pricing', function() { return view('public.pricing'); })->name('public.pricing');
Route::get('/contact', function() { return view('public.contact'); })->name('public.contact');
Route::post('/contact', [App\Http\Controllers\PublicController::class, 'submitContact'])->name('public.contact.submit');
Route::get('/terms', function() { return view('public.terms'); })->name('public.terms');
Route::get('/privacy', function() { return view('public.privacy'); })->name('public.privacy');
Route::get('/refund', function() { return view('public.refund'); })->name('public.refund');

// API Documentation
Route::get('/api/documentation', function() { return view('api.documentation'); })->name('api.documentation');
